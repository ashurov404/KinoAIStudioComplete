(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const c of document.querySelectorAll('link[rel="modulepreload"]'))r(c);new MutationObserver(c=>{for(const f of c)if(f.type==="childList")for(const h of f.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&r(h)}).observe(document,{childList:!0,subtree:!0});function a(c){const f={};return c.integrity&&(f.integrity=c.integrity),c.referrerPolicy&&(f.referrerPolicy=c.referrerPolicy),c.crossOrigin==="use-credentials"?f.credentials="include":c.crossOrigin==="anonymous"?f.credentials="omit":f.credentials="same-origin",f}function r(c){if(c.ep)return;c.ep=!0;const f=a(c);fetch(c.href,f)}})();var nd={exports:{}},nl={};var J_;function BM(){if(J_)return nl;J_=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function a(r,c,f){var h=null;if(f!==void 0&&(h=""+f),c.key!==void 0&&(h=""+c.key),"key"in c){f={};for(var d in c)d!=="key"&&(f[d]=c[d])}else f=c;return c=f.ref,{$$typeof:o,type:r,key:h,ref:c!==void 0?c:null,props:f}}return nl.Fragment=e,nl.jsx=a,nl.jsxs=a,nl}var $_;function FM(){return $_||($_=1,nd.exports=BM()),nd.exports}var R=FM(),id={exports:{}},le={};var tv;function HM(){if(tv)return le;tv=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),a=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),c=Symbol.for("react.profiler"),f=Symbol.for("react.consumer"),h=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),_=Symbol.for("react.suspense"),m=Symbol.for("react.memo"),x=Symbol.for("react.lazy"),p=Symbol.for("react.activity"),y=Symbol.for("react.view_transition"),M=Symbol.iterator;function b(B){return B===null||typeof B!="object"?null:(B=M&&B[M]||B["@@iterator"],typeof B=="function"?B:null)}var D={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},S=Object.assign,v={};function L(B,ft,$){this.props=B,this.context=ft,this.refs=v,this.updater=$||D}L.prototype.isReactComponent={},L.prototype.setState=function(B,ft){if(typeof B!="object"&&typeof B!="function"&&B!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,B,ft,"setState")},L.prototype.forceUpdate=function(B){this.updater.enqueueForceUpdate(this,B,"forceUpdate")};function z(){}z.prototype=L.prototype;function N(B,ft,$){this.props=B,this.context=ft,this.refs=v,this.updater=$||D}var H=N.prototype=new z;H.constructor=N,S(H,L.prototype),H.isPureReactComponent=!0;var F=Array.isArray;function P(){}var k={H:null,A:null,T:null,S:null},C=Object.prototype.hasOwnProperty;function w(B,ft,$){var st=$.ref;return{$$typeof:o,type:B,key:ft,ref:st!==void 0?st:null,props:$}}function G(B,ft){return w(B.type,ft,B.props)}function it(B){return typeof B=="object"&&B!==null&&B.$$typeof===o}function ct(B){var ft={"=":"=0",":":"=2"};return"$"+B.replace(/[=:]/g,function($){return ft[$]})}var gt=/\/+/g;function ut(B,ft){return typeof B=="object"&&B!==null&&B.key!=null?ct(""+B.key):ft.toString(36)}function W(B){switch(B.status){case"fulfilled":return B.value;case"rejected":throw B.reason;default:switch(typeof B.status=="string"?B.then(P,P):(B.status="pending",B.then(function(ft){B.status==="pending"&&(B.status="fulfilled",B.value=ft)},function(ft){B.status==="pending"&&(B.status="rejected",B.reason=ft)})),B.status){case"fulfilled":return B.value;case"rejected":throw B.reason}}throw B}function rt(B,ft,$,st,Mt){var Ut=typeof B;(Ut==="undefined"||Ut==="boolean")&&(B=null);var Rt=!1;if(B===null)Rt=!0;else switch(Ut){case"bigint":case"string":case"number":Rt=!0;break;case"object":switch(B.$$typeof){case o:case e:Rt=!0;break;case x:return Rt=B._init,rt(Rt(B._payload),ft,$,st,Mt)}}if(Rt)return Mt=Mt(B),Rt=st===""?"."+ut(B,0):st,F(Mt)?($="",Rt!=null&&($=Rt.replace(gt,"$&/")+"/"),rt(Mt,ft,$,"",function(I){return I})):Mt!=null&&(it(Mt)&&(Mt=G(Mt,$+(Mt.key==null||B&&B.key===Mt.key?"":(""+Mt.key).replace(gt,"$&/")+"/")+Rt)),ft.push(Mt)),1;Rt=0;var Et=st===""?".":st+":";if(F(B))for(var qt=0;qt<B.length;qt++)st=B[qt],Ut=Et+ut(st,qt),Rt+=rt(st,ft,$,Ut,Mt);else if(qt=b(B),typeof qt=="function")for(B=qt.call(B),qt=0;!(st=B.next()).done;)st=st.value,Ut=Et+ut(st,qt++),Rt+=rt(st,ft,$,Ut,Mt);else if(Ut==="object"){if(typeof B.then=="function")return rt(W(B),ft,$,st,Mt);throw ft=String(B),Error("Objects are not valid as a React child (found: "+(ft==="[object Object]"?"object with keys {"+Object.keys(B).join(", ")+"}":ft)+"). If you meant to render a collection of children, use an array instead.")}return Rt}function K(B,ft,$){if(B==null)return B;var st=[],Mt=0;return rt(B,st,"","",function(Ut){return ft.call($,Ut,Mt++)}),st}function vt(B){if(B._status===-1){var ft=B._result,$=ft();$.then(function(st){(B._status===0||B._status===-1)&&(B._status=1,B._result=st,$.status===void 0&&($.status="fulfilled",$.value=st))},function(st){(B._status===0||B._status===-1)&&(B._status=2,B._result=st,$.status===void 0&&($.status="rejected",$.reason=st))}),B._status===-1&&(B._status=0,B._result=$)}if(B._status===1)return B._result.default;throw B._result}var yt=typeof reportError=="function"?reportError:function(B){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var ft=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof B=="object"&&B!==null&&typeof B.message=="string"?String(B.message):String(B),error:B});if(!window.dispatchEvent(ft))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",B);return}console.error(B)};function Gt(B){var ft=k.T,$={};$.types=ft!==null?ft.types:null,k.T=$;try{var st=B(),Mt=k.S;Mt!==null&&Mt($,st),typeof st=="object"&&st!==null&&typeof st.then=="function"&&st.then(P,yt)}catch(Ut){yt(Ut)}finally{ft!==null&&$.types!==null&&(ft.types=$.types),k.T=ft}}function re(B){var ft=k.T;if(ft!==null){var $=ft.types;$===null?ft.types=[B]:$.indexOf(B)===-1&&$.push(B)}else Gt(re.bind(null,B))}var Ae={map:K,forEach:function(B,ft,$){K(B,function(){ft.apply(this,arguments)},$)},count:function(B){var ft=0;return K(B,function(){ft++}),ft},toArray:function(B){return K(B,function(ft){return ft})||[]},only:function(B){if(!it(B))throw Error("React.Children.only expected to receive a single React element child.");return B}};return le.Activity=p,le.Children=Ae,le.Component=L,le.Fragment=a,le.Profiler=c,le.PureComponent=N,le.StrictMode=r,le.Suspense=_,le.ViewTransition=y,le.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=k,le.__COMPILER_RUNTIME={__proto__:null,c:function(B){return k.H.useMemoCache(B)}},le.addTransitionType=re,le.cache=function(B){return function(){return B.apply(null,arguments)}},le.cacheSignal=function(){return null},le.cloneElement=function(B,ft,$){if(B==null)throw Error("The argument must be a React element, but you passed "+B+".");var st=S({},B.props),Mt=B.key;if(ft!=null)for(Ut in ft.key!==void 0&&(Mt=""+ft.key),ft)!C.call(ft,Ut)||Ut==="key"||Ut==="__self"||Ut==="__source"||Ut==="ref"&&ft.ref===void 0||(st[Ut]=ft[Ut]);var Ut=arguments.length-2;if(Ut===1)st.children=$;else if(1<Ut){for(var Rt=Array(Ut),Et=0;Et<Ut;Et++)Rt[Et]=arguments[Et+2];st.children=Rt}return w(B.type,Mt,st)},le.createContext=function(B){return B={$$typeof:h,_currentValue:B,_currentValue2:B,_threadCount:0,Provider:null,Consumer:null},B.Provider=B,B.Consumer={$$typeof:f,_context:B},B},le.createElement=function(B,ft,$){var st,Mt={},Ut=null;if(ft!=null)for(st in ft.key!==void 0&&(Ut=""+ft.key),ft)C.call(ft,st)&&st!=="key"&&st!=="__self"&&st!=="__source"&&(Mt[st]=ft[st]);var Rt=arguments.length-2;if(Rt===1)Mt.children=$;else if(1<Rt){for(var Et=Array(Rt),qt=0;qt<Rt;qt++)Et[qt]=arguments[qt+2];Mt.children=Et}if(B&&B.defaultProps)for(st in Rt=B.defaultProps,Rt)Mt[st]===void 0&&(Mt[st]=Rt[st]);return w(B,Ut,Mt)},le.createRef=function(){return{current:null}},le.forwardRef=function(B){return{$$typeof:d,render:B}},le.isValidElement=it,le.lazy=function(B){return{$$typeof:x,_payload:{_status:-1,_result:B},_init:vt}},le.memo=function(B,ft){return{$$typeof:m,type:B,compare:ft===void 0?null:ft}},le.startTransition=Gt,le.unstable_useCacheRefresh=function(){return k.H.useCacheRefresh()},le.use=function(B){return k.H.use(B)},le.useActionState=function(B,ft,$){return k.H.useActionState(B,ft,$)},le.useCallback=function(B,ft){return k.H.useCallback(B,ft)},le.useContext=function(B){return k.H.useContext(B)},le.useDebugValue=function(){},le.useDeferredValue=function(B,ft){return k.H.useDeferredValue(B,ft)},le.useEffect=function(B,ft){return k.H.useEffect(B,ft)},le.useEffectEvent=function(B){return k.H.useEffectEvent(B)},le.useId=function(){return k.H.useId()},le.useImperativeHandle=function(B,ft,$){return k.H.useImperativeHandle(B,ft,$)},le.useInsertionEffect=function(B,ft){return k.H.useInsertionEffect(B,ft)},le.useLayoutEffect=function(B,ft){return k.H.useLayoutEffect(B,ft)},le.useMemo=function(B,ft){return k.H.useMemo(B,ft)},le.useOptimistic=function(B,ft){return k.H.useOptimistic(B,ft)},le.useReducer=function(B,ft,$){return k.H.useReducer(B,ft,$)},le.useRef=function(B){return k.H.useRef(B)},le.useState=function(B){return k.H.useState(B)},le.useSyncExternalStore=function(B,ft,$){return k.H.useSyncExternalStore(B,ft,$)},le.useTransition=function(){return k.H.useTransition()},le.version="19.3.0",le}var ev;function Up(){return ev||(ev=1,id.exports=HM()),id.exports}var an=Up(),ad={exports:{}},il={},sd={exports:{}},rd={};var nv;function GM(){return nv||(nv=1,(function(o){function e(W,rt){var K=W.length;W.push(rt);t:for(;0<K;){var vt=K-1>>>1,yt=W[vt];if(0<c(yt,rt))W[vt]=rt,W[K]=yt,K=vt;else break t}}function a(W){return W.length===0?null:W[0]}function r(W){if(W.length===0)return null;var rt=W[0],K=W.pop();if(K!==rt){W[0]=K;t:for(var vt=0,yt=W.length,Gt=yt>>>1;vt<Gt;){var re=2*(vt+1)-1,Ae=W[re],B=re+1,ft=W[B];if(0>c(Ae,K))B<yt&&0>c(ft,Ae)?(W[vt]=ft,W[B]=K,vt=B):(W[vt]=Ae,W[re]=K,vt=re);else if(B<yt&&0>c(ft,K))W[vt]=ft,W[B]=K,vt=B;else break t}}return rt}function c(W,rt){var K=W.sortIndex-rt.sortIndex;return K!==0?K:W.id-rt.id}if(o.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var f=performance;o.unstable_now=function(){return f.now()}}else{var h=Date,d=h.now();o.unstable_now=function(){return h.now()-d}}var _=[],m=[],x=1,p=null,y=3,M=!1,b=!1,D=!1,S=!1,v=typeof setTimeout=="function"?setTimeout:null,L=typeof clearTimeout=="function"?clearTimeout:null,z=typeof setImmediate<"u"?setImmediate:null;function N(W){for(var rt=a(m);rt!==null;){if(rt.callback===null)r(m);else if(rt.startTime<=W)r(m),rt.sortIndex=rt.expirationTime,e(_,rt);else break;rt=a(m)}}function H(W){if(D=!1,N(W),!b)if(a(_)!==null)b=!0,F||(F=!0,it());else{var rt=a(m);rt!==null&&ut(H,rt.startTime-W)}}var F=!1,P=-1,k=5,C=-1;function w(){return S?!0:!(o.unstable_now()-C<k)}function G(){if(S=!1,F){var W=o.unstable_now();C=W;var rt=!0;try{t:{b=!1,D&&(D=!1,L(P),P=-1),M=!0;var K=y;try{e:{for(N(W),p=a(_);p!==null&&!(p.expirationTime>W&&w());){var vt=p.callback;if(typeof vt=="function"){p.callback=null,y=p.priorityLevel;var yt=vt(p.expirationTime<=W);if(W=o.unstable_now(),typeof yt=="function"){p.callback=yt,N(W),rt=!0;break e}p===a(_)&&r(_),N(W)}else r(_);p=a(_)}if(p!==null)rt=!0;else{var Gt=a(m);Gt!==null&&ut(H,Gt.startTime-W),rt=!1}}break t}finally{p=null,y=K,M=!1}rt=void 0}}finally{rt?it():F=!1}}}var it;if(typeof z=="function")it=function(){z(G)};else if(typeof MessageChannel<"u"){var ct=new MessageChannel,gt=ct.port2;ct.port1.onmessage=G,it=function(){gt.postMessage(null)}}else it=function(){v(G,0)};function ut(W,rt){P=v(function(){W(o.unstable_now())},rt)}o.unstable_IdlePriority=5,o.unstable_ImmediatePriority=1,o.unstable_LowPriority=4,o.unstable_NormalPriority=3,o.unstable_Profiling=null,o.unstable_UserBlockingPriority=2,o.unstable_cancelCallback=function(W){W.callback=null},o.unstable_forceFrameRate=function(W){0>W||125<W?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):k=0<W?Math.floor(1e3/W):5},o.unstable_getCurrentPriorityLevel=function(){return y},o.unstable_next=function(W){switch(y){case 1:case 2:case 3:var rt=3;break;default:rt=y}var K=y;y=rt;try{return W()}finally{y=K}},o.unstable_requestPaint=function(){S=!0},o.unstable_runWithPriority=function(W,rt){switch(W){case 1:case 2:case 3:case 4:case 5:break;default:W=3}var K=y;y=W;try{return rt()}finally{y=K}},o.unstable_scheduleCallback=function(W,rt,K){var vt=o.unstable_now();switch(typeof K=="object"&&K!==null?(K=K.delay,K=typeof K=="number"&&0<K?vt+K:vt):K=vt,W){case 1:var yt=-1;break;case 2:yt=250;break;case 5:yt=1073741823;break;case 4:yt=1e4;break;default:yt=5e3}return yt=K+yt,W={id:x++,callback:rt,priorityLevel:W,startTime:K,expirationTime:yt,sortIndex:-1},K>vt?(W.sortIndex=K,e(m,W),a(_)===null&&W===a(m)&&(D?(L(P),P=-1):D=!0,ut(H,K-vt))):(W.sortIndex=yt,e(_,W),b||M||(b=!0,F||(F=!0,it()))),W},o.unstable_shouldYield=w,o.unstable_wrapCallback=function(W){var rt=y;return function(){var K=y;y=rt;try{return W.apply(this,arguments)}finally{y=K}}}})(rd)),rd}var iv;function VM(){return iv||(iv=1,sd.exports=GM()),sd.exports}var od={exports:{}},Nn={};var av;function kM(){if(av)return Nn;av=1;var o=Up();function e(x){var p="https://react.dev/errors/"+x;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var y=2;y<arguments.length;y++)p+="&args[]="+encodeURIComponent(arguments[y])}return"Minified React error #"+x+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function a(){}var r={d:{f:a,r:function(){throw Error(e(522))},D:a,C:a,L:a,m:a,X:a,S:a,M:a},p:0,findDOMNode:null},c=Symbol.for("react.portal"),f=Symbol.for("react.recoverable"),h=Symbol.for("react.optimistic_key");function d(x,p,y){var M=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:c,key:M==null?null:M===h?h:""+M,children:x,containerInfo:p,implementation:y}}var _=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function m(x,p){if(x==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return Nn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=r,Nn.browser=function(x){return{$$typeof:f,_reason:x}},Nn.createPortal=function(x,p){var y=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(e(299));return d(x,p,null,y)},Nn.flushSync=function(x){var p=_.T,y=r.p;try{if(_.T=null,r.p=2,x)return x()}finally{_.T=p,r.p=y,r.d.f()}},Nn.preconnect=function(x,p){typeof x=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,r.d.C(x,p))},Nn.prefetchDNS=function(x){typeof x=="string"&&r.d.D(x)},Nn.preinit=function(x,p){if(typeof x=="string"&&p&&typeof p.as=="string"){var y=p.as,M=m(y,p.crossOrigin),b=typeof p.integrity=="string"?p.integrity:void 0,D=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;y==="style"?r.d.S(x,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:M,integrity:b,fetchPriority:D}):y==="script"&&r.d.X(x,{crossOrigin:M,integrity:b,fetchPriority:D,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},Nn.preinitModule=function(x,p){if(typeof x=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var y=m(p.as,p.crossOrigin);r.d.M(x,{crossOrigin:y,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0})}}else p==null&&r.d.M(x)},Nn.preload=function(x,p){if(typeof x=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var y=p.as,M=m(y,p.crossOrigin);r.d.L(x,y,{crossOrigin:M,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},Nn.preloadModule=function(x,p){if(typeof x=="string")if(p){var y=m(p.as,p.crossOrigin);r.d.m(x,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:y,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0})}else r.d.m(x)},Nn.requestFormReset=function(x){r.d.r(x)},Nn.unstable_batchedUpdates=function(x,p){return x(p)},Nn.useFormState=function(x,p,y){return _.H.useFormState(x,p,y)},Nn.useFormStatus=function(){return _.H.useHostTransitionStatus()},Nn.version="19.3.0",Nn}var sv;function XM(){if(sv)return od.exports;sv=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),od.exports=kM(),od.exports}var rv;function jM(){if(rv)return il;rv=1;var o=VM(),e=Up(),a=XM();function r(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var i=2;i<arguments.length;i++)n+="&args[]="+encodeURIComponent(arguments[i])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function c(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function f(t){for(var n=t,i=n;i&&!i.alternate;)n=i,(n.flags&4098)!==0&&(t=n.return),i=n.return;for(;n.return;)n=n.return;return n.tag===3?t:null}function h(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function d(t){if(t.tag===31){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function _(t){if(f(t)!==t)throw Error(r(188))}function m(t){var n=t.alternate;if(!n){if(n=f(t),n===null)throw Error(r(188));return n!==t?null:t}for(var i=t,s=n;;){var l=i.return;if(l===null)break;var u=l.alternate;if(u===null){if(s=l.return,s!==null){i=s;continue}break}if(l.child===u.child){for(u=l.child;u;){if(u===i)return _(l),t;if(u===s)return _(l),n;u=u.sibling}throw Error(r(188))}if(i.return!==s.return)i=l,s=u;else{for(var g=!1,E=l.child;E;){if(E===i){g=!0,i=l,s=u;break}if(E===s){g=!0,s=l,i=u;break}E=E.sibling}if(!g){for(E=u.child;E;){if(E===i){g=!0,i=u,s=l;break}if(E===s){g=!0,s=u,i=l;break}E=E.sibling}if(!g)throw Error(r(189))}}if(i.alternate!==s)throw Error(r(190))}if(i.tag!==3)throw Error(r(188));return i.stateNode.current===i?t:n}function x(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=x(t),n!==null)return n;t=t.sibling}return null}function p(t,n,i,s,l,u){for(;t!==null;){if((t.tag===5||t.tag===27||t.tag===6)&&i(t,s,l,u)||(t.tag!==22||t.memoizedState===null)&&(n||t.tag!==5&&t.tag!==27)&&p(t.child,n,i,s,l,u))return!0;t=t.sibling}return!1}function y(t){for(t=t.return;t!==null;){if(t.tag===3||t.tag===5||t.tag===27)return t;t=t.return}return null}function M(t){var n=!1;for(t=t.return;t!==null&&(t.tag===4&&(n=!0),!(t.tag===3||t.tag===5||t.tag===27));)t=t.return;return n}function b(t){var n=[null,null],i=y(t);return i===null||D(n,t,i.child,{foundSelf:!1}),n}function D(t,n,i,s){for(;i!==null;){if(i===n)s.foundSelf=!0;else if(i.tag===5||i.tag===27||i.tag===6){if(s.foundSelf)return t[1]=i,!0;t[0]=i}else if((i.tag!==22||i.memoizedState===null)&&D(t,n,i.child,s))return!0;i=i.sibling}return!1}function S(t){switch(t.tag){case 5:case 27:case 6:return t.stateNode;case 3:return t.stateNode.containerInfo;default:throw Error(r(559))}}var v=null,L=null;function z(t,n,i){return t===i?!0:t===n?(v=t,!0):!1}function N(t,n,i){return t===i?(L=t,!1):t===n?(L!==null&&(v=t),!0):!1}function H(t){if(t===null)return null;do t=t===null?null:t.return;while(t&&t.tag!==5&&t.tag!==27&&t.tag!==3);return t||null}function F(t,n,i){for(var s=0,l=t;l;l=i(l))s++;l=0;for(var u=n;u;u=i(u))l++;for(;0<s-l;)t=i(t),s--;for(;0<l-s;)n=i(n),l--;for(;s--;){if(t===n||n!==null&&t===n.alternate)return t;t=i(t),n=i(n)}return null}var P=Object.assign,k=Symbol.for("react.element"),C=Symbol.for("react.transitional.element"),w=Symbol.for("react.portal"),G=Symbol.for("react.fragment"),it=Symbol.for("react.strict_mode"),ct=Symbol.for("react.profiler"),gt=Symbol.for("react.consumer"),ut=Symbol.for("react.context"),W=Symbol.for("react.forward_ref"),rt=Symbol.for("react.suspense"),K=Symbol.for("react.suspense_list"),vt=Symbol.for("react.memo"),yt=Symbol.for("react.lazy"),Gt=Symbol.for("react.activity"),re=Symbol.for("react.legacy_hidden"),Ae=Symbol.for("react.memo_cache_sentinel"),B=Symbol.for("react.view_transition"),ft=Symbol.for("react.recoverable"),$=Symbol.iterator;function st(t){return t===null||typeof t!="object"?null:(t=$&&t[$]||t["@@iterator"],typeof t=="function"?t:null)}var Mt=Symbol.for("react.client.reference");function Ut(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===Mt?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case G:return"Fragment";case ct:return"Profiler";case it:return"StrictMode";case rt:return"Suspense";case K:return"SuspenseList";case Gt:return"Activity";case B:return"ViewTransition"}if(typeof t=="object")switch(t.$$typeof){case w:return"Portal";case ut:return t.displayName||"Context";case gt:return(t._context.displayName||"Context")+".Consumer";case W:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case vt:return n=t.displayName||null,n!==null?n:Ut(t.type)||"Memo";case yt:n=t._payload,t=t._init;try{return Ut(t(n))}catch{}}return null}var Rt=Array.isArray,Et=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,qt=a.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,I={pending:!1,data:null,method:null,action:null},Ge=[],se=-1;function Qt(t){return{current:t}}function Lt(t){0>se||(t.current=Ge[se],Ge[se]=null,se--)}function ie(t,n){se++,Ge[se]=t.current,t.current=n}var Ft=Qt(null),oe=Qt(null),qe=Qt(null),We=Qt(null);function U(t,n){switch(ie(qe,n),ie(oe,t),ie(Ft,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?o_(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=o_(n),t=l_(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Lt(Ft),ie(Ft,t)}function T(){Lt(Ft),Lt(oe),Lt(qe)}function nt(t){var n=t.memoizedState;n!==null&&(zr._currentValue=n.memoizedState,ie(We,t)),n=Ft.current;var i=l_(n,t.type);n!==i&&(ie(oe,t),ie(Ft,i))}function pt(t){oe.current===t&&(Lt(Ft),Lt(oe)),We.current===t&&(Lt(We),zr._currentValue=I)}var xt,ht;function kt(t){if(xt===void 0)try{throw Error()}catch(i){var n=i.stack.trim().match(/\n( *(at )?)/);xt=n&&n[1]||"",ht=-1<i.stack.indexOf(`
    at`)?" (<anonymous>)":-1<i.stack.indexOf("@")?"@unknown:0:0":""}return`
`+xt+t+ht}var Ct=!1;function Wt(t,n){if(!t||Ct)return"";Ct=!0;var i=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var s={DetermineComponentFrameRoot:function(){try{if(n){var mt=function(){throw Error()};if(Object.defineProperty(mt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(mt,[])}catch(Nt){var j=Nt}Reflect.construct(t,[],mt)}else{try{mt.call()}catch(Nt){j=Nt}mt=!1;try{var tt=Object.getOwnPropertyDescriptor(t.prototype,"props");Object.defineProperty(t.prototype,"props",{configurable:!0,set:function(){throw Error()}}),mt=!0,new t}finally{mt&&(tt!==void 0?Object.defineProperty(t.prototype,"props",tt):delete t.prototype.props)}}}else{try{throw Error()}catch(Nt){j=Nt}(mt=t())&&typeof mt.catch=="function"&&mt.catch(function(){})}}catch(Nt){if(Nt&&j&&typeof Nt.stack=="string")return[Nt.stack,j.stack]}return[null,null]}};s.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var l=Object.getOwnPropertyDescriptor(s.DetermineComponentFrameRoot,"name");l&&l.configurable&&Object.defineProperty(s.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var u=s.DetermineComponentFrameRoot(),g=u[0],E=u[1];if(g&&E){var O=g.split(`
`),Y=E.split(`
`);for(l=s=0;s<O.length&&!O[s].includes("DetermineComponentFrameRoot");)s++;for(;l<Y.length&&!Y[l].includes("DetermineComponentFrameRoot");)l++;if(s===O.length||l===Y.length)for(s=O.length-1,l=Y.length-1;1<=s&&0<=l&&O[s]!==Y[l];)l--;for(;1<=s&&0<=l;s--,l--)if(O[s]!==Y[l]){if(s!==1||l!==1)do if(s--,l--,0>l||O[s]!==Y[l]){var at=`
`+O[s].replace(" at new "," at ");return t.displayName&&at.includes("<anonymous>")&&(at=at.replace("<anonymous>",t.displayName)),at}while(1<=s&&0<=l);break}}}finally{Ct=!1,Error.prepareStackTrace=i}return(i=t?t.displayName||t.name:"")?kt(i):""}function Kt(t,n){switch(t.tag){case 26:case 27:case 5:return kt(t.type);case 16:return kt("Lazy");case 13:return t.child!==n&&n!==null?kt("Suspense Fallback"):kt("Suspense");case 19:return kt("SuspenseList");case 0:case 15:return Wt(t.type,!1);case 11:return Wt(t.type.render,!1);case 1:return Wt(t.type,!0);case 31:return kt("Activity");case 30:return kt("ViewTransition");default:return""}}function bt(t){try{var n="",i=null;do n+=Kt(t,i),i=t,t=t.return;while(t);return n}catch(s){return`
Error generating stack: `+s.message+`
`+s.stack}}var Ot=Object.prototype.hasOwnProperty,ne=o.unstable_scheduleCallback,Zt=o.unstable_cancelCallback,zt=o.unstable_shouldYield,ue=o.unstable_requestPaint,X=o.unstable_now,At=o.unstable_getCurrentPriorityLevel,Dt=o.unstable_ImmediatePriority,Vt=o.unstable_UserBlockingPriority,St=o.unstable_NormalPriority,_t=o.unstable_LowPriority,Yt=o.unstable_IdlePriority,ce=o.log,Ve=o.unstable_setDisableYieldValue,Se=null,en=null;function gn(t){if(typeof ce=="function"&&Ve(t),en&&typeof en.setStrictMode=="function")try{en.setStrictMode(Se,t)}catch{}}var Un=Math.clz32?Math.clz32:Sl,ta=Math.log,fo=Math.LN2;function Sl(t){return t>>>=0,t===0?32:31-(ta(t)/fo|0)|0}var fs=256,ea=262144,hs=4194304;function fi(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&-t;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function ds(t,n,i){var s=t.pendingLanes;if(s===0)return 0;var l=0,u=t.suspendedLanes,g=t.pingedLanes;t=t.warmLanes;var E=s&134217727;return E!==0?(s=E&~u,s!==0?l=fi(s):(g&=E,g!==0?l=fi(g):i||(i=E&~t,i!==0&&(l=fi(i))))):(E=s&~u,E!==0?l=fi(E):g!==0?l=fi(g):i||(i=s&~t,i!==0&&(l=fi(i)))),l===0?0:n!==0&&n!==l&&(n&u)===0&&(u=l&-l,i=n&-n,u>=i||u===32&&(i&4194048)!==0)?n:l}function ba(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function Ml(t,n){(n&8)!==0&&(n|=n&32);var i=t.entangledLanes;if(i!==0)for(t=t.entanglements,i&=n;0<i;){var s=31-Un(i),l=1<<s;n|=t[s],i&=~l}return n}function wu(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function El(){var t=hs;return hs<<=1,(hs&62914560)===0&&(hs=4194304),t}function ho(t){for(var n=[],i=0;31>i;i++)n.push(t);return n}function ps(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function Du(t,n,i,s,l,u){var g=t.pendingLanes;t.pendingLanes=i,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=i,t.entangledLanes&=i,t.errorRecoveryDisabledLanes&=i,t.shellSuspendCounter=0;var E=t.entanglements,O=t.expirationTimes,Y=t.hiddenUpdates;for(i=g&~i;0<i;){var at=31-Un(i),mt=1<<at;E[at]=0,O[at]=-1;var j=Y[at];if(j!==null)for(Y[at]=null,at=0;at<j.length;at++){var tt=j[at];tt!==null&&(tt.lane&=-536870913)}i&=~mt}s!==0&&A(t,s,0),u!==0&&l===0&&t.tag!==0&&(t.suspendedLanes|=u&~(g&~n))}function A(t,n,i){t.pendingLanes|=n,t.suspendedLanes&=~n;var s=31-Un(n);t.entangledLanes|=n,t.entanglements[s]=t.entanglements[s]|1073741824|i&261930}function Z(t,n){var i=t.entangledLanes|=n;for(t=t.entanglements;i;){var s=31-Un(i),l=1<<s;l&n|t[s]&n&&(t[s]|=n),i&=~l}}function ot(t,n){var i=n&-n;return i=(i&42)!==0?1:lt(i),(i&(t.suspendedLanes|n))!==0?0:i}function lt(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function Q(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function Tt(){var t=qt.p;return t!==0?t:(t=window.event,t===void 0?32:j_(t.type))}function Pt(t,n){var i=qt.p;try{return qt.p=t,n()}finally{qt.p=i}}var Bt=Math.random().toString(36).slice(2),wt="__reactFiber$"+Bt,Xt="__reactProps$"+Bt,ee="__reactContainer$"+Bt,$t="__reactEvents$"+Bt,_e="__reactListeners$"+Bt,Pe="__reactHandles$"+Bt,Je="__reactResources$"+Bt,Le="__reactMarker$"+Bt,Ce="__reactLoad$"+Bt;function te(t){delete t[wt],delete t[Xt],delete t[_e],delete t[Pe]}function Oe(t){var n;if(n=t[wt])return n;for(var i=t.parentNode;i;){if(n=i[ee]||i[wt]){if(i=n.alternate,n.child!==null||i!==null&&i.child!==null)for(t=b_(t);t!==null;){if(i=t[wt])return i;t=b_(t)}return n}t=i,i=t.parentNode}return null}function me(t){if(t=t[wt]||t[ee]){var n=t.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return t}return null}function _n(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(r(33))}function Jn(t){var n=t[Je];return n||(n=t[Je]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function we(t){t[Le]=!0}function Aa(t){t[Ce]=void 0}var Ze=new Set,In={};function un(t,n){rn(t,n),rn(t+"Capture",n)}function rn(t,n){for(In[t]=n,t=0;t<n.length;t++)Ze.add(n[t])}var Ln=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Js={},Ii={};function iy(t){return Ot.call(Ii,t)?!0:Ot.call(Js,t)?!1:Ln.test(t)?Ii[t]=!0:(Js[t]=!0,!1)}var De=!1;function Yp(){var t=De;return De=!1,t}function Tl(t,n,i){if(iy(n))if(i===null)t.removeAttribute(n);else{switch(typeof i){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var s=n.toLowerCase().slice(0,5);if(s!=="data-"&&s!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,i)}}function bl(t,n,i){if(i===null)t.removeAttribute(n);else{switch(typeof i){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,i)}}function na(t,n,i,s){if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(i);return}t.setAttributeNS(n,i,s)}}function $n(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function Wp(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function ay(t,n,i){var s=Object.getOwnPropertyDescriptor(t.constructor.prototype,n);if(!t.hasOwnProperty(n)&&typeof s<"u"&&typeof s.get=="function"&&typeof s.set=="function"){var l=s.get,u=s.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return l.call(this)},set:function(g){i=""+g,u.call(this,g)}}),Object.defineProperty(t,n,{enumerable:s.enumerable}),{getValue:function(){return i},setValue:function(g){i=""+g},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function Nu(t){if(!t._valueTracker){var n=Wp(t)?"checked":"value";t._valueTracker=ay(t,n,""+t[n])}}function Zp(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var i=n.getValue(),s="";return t&&(s=Wp(t)?t.checked?"true":"false":t.value),t=s,t!==i?(n.setValue(t),!0):!1}var sy=/[\n"\\]/g;function hi(t){return t.replace(sy,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function Uu(t,n,i,s,l,u,g,E){t.name="",g!=null&&typeof g!="function"&&typeof g!="symbol"&&typeof g!="boolean"?t.type=g:t.removeAttribute("type"),n!=null?g==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+$n(n)):t.value!==""+$n(n)&&(t.value=""+$n(n)):g!=="submit"&&g!=="reset"||t.removeAttribute("value"),n!=null?g==="number"&&t.value==n?Lu(t,$n(t.value)):Lu(t,$n(n)):i!=null?Lu(t,$n(i)):s!=null&&t.removeAttribute("value"),l==null&&u!=null&&(t.defaultChecked=!!u),l!=null&&(t.checked=l&&typeof l!="function"&&typeof l!="symbol"),E!=null&&typeof E!="function"&&typeof E!="symbol"&&typeof E!="boolean"?t.name=""+$n(E):t.removeAttribute("name")}function Kp(t,n,i,s,l,u,g,E){if(u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"&&(t.type=u),n!=null||i!=null){if(!(u!=="submit"&&u!=="reset"||n!=null)){Nu(t);return}i=i!=null?""+$n(i):"",n=n!=null?""+$n(n):i,E||n===t.value||(t.value=n),t.defaultValue=n}s=s??l,s=typeof s!="function"&&typeof s!="symbol"&&!!s,t.checked=E?t.checked:!!s,t.defaultChecked=!!s,g!=null&&typeof g!="function"&&typeof g!="symbol"&&typeof g!="boolean"&&(t.name=g),Nu(t)}function Lu(t,n){t.defaultValue!==""+n&&(t.defaultValue=""+n)}function $s(t,n,i,s){if(t=t.options,n){n={};for(var l=0;l<i.length;l++)n["$"+i[l]]=!0;for(i=0;i<t.length;i++)l=n.hasOwnProperty("$"+t[i].value),t[i].selected!==l&&(t[i].selected=l),l&&s&&(t[i].defaultSelected=!0)}else{for(i=""+$n(i),n=null,l=0;l<t.length;l++){if(t[l].value===i){t[l].selected=!0,s&&(t[l].defaultSelected=!0);return}n!==null||t[l].disabled||(n=t[l])}n!==null&&(n.selected=!0)}}function Qp(t,n,i){if(n!=null&&(n=""+$n(n),n!==t.value&&(t.value=n),i==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=i!=null?""+$n(i):""}function Jp(t,n,i,s){if(n==null){if(s!=null){if(i!=null)throw Error(r(92));if(Rt(s)){if(1<s.length)throw Error(r(93));s=s[0]}i=s}i==null&&(i=""),n=i}i=$n(n),t.defaultValue=i,s=t.textContent,s===i&&s!==""&&s!==null&&(t.value=s),Nu(t)}function tr(t,n){if(n){var i=t.firstChild;if(i&&i===t.lastChild&&i.nodeType===3){i.nodeValue=n;return}}t.textContent=n}var ry=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function $p(t,n,i){var s=n.indexOf("--")===0;i==null||typeof i=="boolean"||i===""?s?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":s?t.setProperty(n,i):typeof i!="number"||i===0||ry.has(n)?n==="float"?t.cssFloat=i:t[n]=(""+i).trim():t[n]=i+"px"}function tm(t,n,i){if(n!=null&&typeof n!="object")throw Error(r(62));if(t=t.style,i!=null){for(var s in i)!i.hasOwnProperty(s)||n!=null&&n.hasOwnProperty(s)||(s.indexOf("--")===0?t.setProperty(s,""):s==="float"?t.cssFloat="":t[s]="",De=!0);for(var l in n)s=n[l],n.hasOwnProperty(l)&&i[l]!==s&&($p(t,l,s),De=!0)}else for(var u in n)n.hasOwnProperty(u)&&$p(t,u,n[u])}function Ou(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var oy=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),ly=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Al(t){return ly.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function Bi(){}var zu=null;function Pu(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var er=null,nr=null;function em(t){var n=me(t);if(n&&(t=n.stateNode)){var i=t[Xt]||null;t:switch(t=n.stateNode,n.type){case"input":if(Uu(t,i.value,i.defaultValue,i.defaultValue,i.checked,i.defaultChecked,i.type,i.name),n=i.name,i.type==="radio"&&n!=null){for(i=t;i.parentNode;)i=i.parentNode;for(i=i.querySelectorAll('input[name="'+hi(""+n)+'"][type="radio"]'),n=0;n<i.length;n++){var s=i[n];if(s!==t&&s.form===t.form){var l=s[Xt]||null;if(!l)throw Error(r(90));Uu(s,l.value,l.defaultValue,l.defaultValue,l.checked,l.defaultChecked,l.type,l.name)}}for(n=0;n<i.length;n++)s=i[n],s.form===t.form&&Zp(s)}break t;case"textarea":Qp(t,i.value,i.defaultValue);break t;case"select":n=i.value,n!=null&&$s(t,!!i.multiple,n,!1)}}}var Iu=!1;function nm(t,n,i){if(Iu)return t(n,i);Iu=!0;try{var s=t(n);return s}finally{if(Iu=!1,(er!==null||nr!==null)&&(Ac(),er&&(n=er,t=nr,nr=er=null,em(n),t)))for(n=0;n<t.length;n++)em(t[n])}}function po(t,n){var i=t.stateNode;if(i===null)return null;var s=i[Xt]||null;if(s===null)return null;i=s[n];t:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(s=!s.disabled)||(t=t.type,s=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!s;break t;default:t=!1}if(t)return null;if(i&&typeof i!="function")throw Error(r(231,n,typeof i));return i}var ia=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Bu=!1;if(ia)try{var mo={};Object.defineProperty(mo,"passive",{get:function(){Bu=!0}}),window.addEventListener("test",mo,mo),window.removeEventListener("test",mo,mo)}catch{Bu=!1}var Ra=null,Fu=null,Rl=null;function im(){if(Rl)return Rl;var t,n=Fu,i=n.length,s,l="value"in Ra?Ra.value:Ra.textContent,u=l.length;for(t=0;t<i&&n[t]===l[t];t++);var g=i-t;for(s=1;s<=g&&n[i-s]===l[u-s];s++);return Rl=l.slice(t,1<s?1-s:void 0)}function Cl(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function wl(){return!0}function am(){return!1}function Bn(t){function n(i,s,l,u,g){this._reactName=i,this._targetInst=l,this.type=s,this.nativeEvent=u,this.target=g,this.currentTarget=null;for(var E in t)t.hasOwnProperty(E)&&(i=t[E],this[E]=i?i(u):u[E]);return this.isDefaultPrevented=(u.defaultPrevented!=null?u.defaultPrevented:u.returnValue===!1)?wl:am,this.isPropagationStopped=am,this}return P(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var i=this.nativeEvent;i&&(i.preventDefault?i.preventDefault():typeof i.returnValue!="unknown"&&(i.returnValue=!1),this.isDefaultPrevented=wl)},stopPropagation:function(){var i=this.nativeEvent;i&&(i.stopPropagation?i.stopPropagation():typeof i.cancelBubble!="unknown"&&(i.cancelBubble=!0),this.isPropagationStopped=wl)},persist:function(){},isPersistent:wl}),n}var Ca={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Dl=Bn(Ca),go=P({},Ca,{view:0,detail:0}),cy=Bn(go),Hu,Gu,_o,Nl=P({},go,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ku,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==_o&&(_o&&t.type==="mousemove"?(Hu=t.screenX-_o.screenX,Gu=t.screenY-_o.screenY):Gu=Hu=0,_o=t),Hu)},movementY:function(t){return"movementY"in t?t.movementY:Gu}}),sm=Bn(Nl),uy=P({},Nl,{dataTransfer:0}),fy=Bn(uy),hy=P({},go,{relatedTarget:0}),Vu=Bn(hy),dy=P({},Ca,{animationName:0,elapsedTime:0,pseudoElement:0}),py=Bn(dy),my=P({},Ca,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),gy=Bn(my),_y=P({},Ca,{data:0}),rm=Bn(_y),vy={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},xy={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},yy={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Sy(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=yy[t])?!!n[t]:!1}function ku(){return Sy}var My=P({},go,{key:function(t){if(t.key){var n=vy[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=Cl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?xy[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ku,charCode:function(t){return t.type==="keypress"?Cl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Cl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),Ey=Bn(My),Ty=P({},Nl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),om=Bn(Ty),by=P({},Ca,{submitter:0}),Ay=Bn(by),Ry=P({},go,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ku}),Cy=Bn(Ry),wy=P({},Ca,{propertyName:0,elapsedTime:0,pseudoElement:0}),Dy=Bn(wy),Ny=P({},Nl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),Uy=Bn(Ny),Ly=P({},Ca,{newState:0,oldState:0,source:0}),Oy=Bn(Ly),zy=[9,13,27,32],Xu=ia&&"CompositionEvent"in window,vo=null;ia&&"documentMode"in document&&(vo=document.documentMode);var Py=ia&&"TextEvent"in window&&!vo,lm=ia&&(!Xu||vo&&8<vo&&11>=vo),cm=" ",um=!1;function fm(t,n){switch(t){case"keyup":return zy.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function hm(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var ir=!1;function Iy(t,n){switch(t){case"compositionend":return hm(n);case"keypress":return n.which!==32?null:(um=!0,cm);case"textInput":return t=n.data,t===cm&&um?null:t;default:return null}}function By(t,n){if(ir)return t==="compositionend"||!Xu&&fm(t,n)?(t=im(),Rl=Fu=Ra=null,ir=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return lm&&n.locale!=="ko"?null:n.data;default:return null}}var Fy={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function dm(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!Fy[t.type]:n==="textarea"}function pm(t,n,i,s){er?nr?nr.push(s):nr=[s]:er=s,n=Uc(n,"onChange"),0<n.length&&(i=new Dl("onChange","change",null,i,s),t.push({event:i,listeners:n}))}var xo=null,yo=null;function Hy(t){e_(t,0)}function Ul(t){var n=_n(t);if(Zp(n))return t}function mm(t,n){if(t==="change")return n}var gm=!1;if(ia){var ju;if(ia){var qu="oninput"in document;if(!qu){var _m=document.createElement("div");_m.setAttribute("oninput","return;"),qu=typeof _m.oninput=="function"}ju=qu}else ju=!1;gm=ju&&(!document.documentMode||9<document.documentMode)}function vm(){xo&&(xo.detachEvent("onpropertychange",xm),yo=xo=null)}function xm(t){if(t.propertyName==="value"&&Ul(yo)){var n=[];pm(n,yo,t,Pu(t)),nm(Hy,n)}}function Gy(t,n,i){t==="focusin"?(vm(),xo=n,yo=i,xo.attachEvent("onpropertychange",xm)):t==="focusout"&&vm()}function Vy(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return Ul(yo)}function ky(t,n){if(t==="click")return Ul(n)}function Xy(t,n){if(t==="input"||t==="change")return Ul(n)}function jy(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var ti=typeof Object.is=="function"?Object.is:jy;function So(t,n){if(ti(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var i=Object.keys(t),s=Object.keys(n);if(i.length!==s.length)return!1;for(s=0;s<i.length;s++){var l=i[s];if(!Ot.call(n,l)||!ti(t[l],n[l]))return!1}return!0}function Yu(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}function ym(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function Sm(t,n){var i=ym(t);t=0;for(var s;i;){if(i.nodeType===3){if(s=t+i.textContent.length,t<=n&&s>=n)return{node:i,offset:n-t};t=s}t:{for(;i;){if(i.nextSibling){i=i.nextSibling;break t}i=i.parentNode}i=void 0}i=ym(i)}}function Mm(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?Mm(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function Em(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=Yu(t.document);n instanceof t.HTMLIFrameElement;){try{var i=typeof n.contentWindow.location.href=="string"}catch{i=!1}if(i)t=n.contentWindow;else break;n=Yu(t.document)}return n}function Wu(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var qy=ia&&"documentMode"in document&&11>=document.documentMode,ar=null,Zu=null,Mo=null,Ku=!1;function Tm(t,n,i){var s=i.window===i?i.document:i.nodeType===9?i:i.ownerDocument;Ku||ar==null||ar!==Yu(s)||(s=ar,"selectionStart"in s&&Wu(s)?s={start:s.selectionStart,end:s.selectionEnd}:(s=(s.ownerDocument&&s.ownerDocument.defaultView||window).getSelection(),s={anchorNode:s.anchorNode,anchorOffset:s.anchorOffset,focusNode:s.focusNode,focusOffset:s.focusOffset}),Mo&&So(Mo,s)||(Mo=s,s=Uc(Zu,"onSelect"),0<s.length&&(n=new Dl("onSelect","select",null,n,i),t.push({event:n,listeners:s}),n.target=ar)))}function ms(t,n){var i={};return i[t.toLowerCase()]=n.toLowerCase(),i["Webkit"+t]="webkit"+n,i["Moz"+t]="moz"+n,i}var sr={animationend:ms("Animation","AnimationEnd"),animationiteration:ms("Animation","AnimationIteration"),animationstart:ms("Animation","AnimationStart"),transitionrun:ms("Transition","TransitionRun"),transitionstart:ms("Transition","TransitionStart"),transitioncancel:ms("Transition","TransitionCancel"),transitionend:ms("Transition","TransitionEnd")},Qu={},bm={};ia&&(bm=document.createElement("div").style,"AnimationEvent"in window||(delete sr.animationend.animation,delete sr.animationiteration.animation,delete sr.animationstart.animation),"TransitionEvent"in window||delete sr.transitionend.transition);function gs(t){if(Qu[t])return Qu[t];if(!sr[t])return t;var n=sr[t],i;for(i in n)if(n.hasOwnProperty(i)&&i in bm)return Qu[t]=n[i];return t}var Am=gs("animationend"),Rm=gs("animationiteration"),Cm=gs("animationstart"),Yy=gs("transitionrun"),Wy=gs("transitionstart"),Zy=gs("transitioncancel"),wm=gs("transitionend"),Dm=new Map,Ju="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Ju.push("scrollEnd");function Ei(t,n){Dm.set(t,n),un(n,[t])}var Ky=0;function aa(t,n){if(t.name!=null&&t.name!=="auto")return t.name;if(n.autoName!==null)return n.autoName;t=Ri.identifierPrefix;var i=Ky++;return t="_"+t+"t_"+i.toString(32)+"_",n.autoName=t}function Nm(t){if(t==null||typeof t=="string")return t;var n=null,i=br;if(i!==null)for(var s=0;s<i.length;s++){var l=t[i[s]];if(l!=null){if(l==="none")return"none";n=n==null?l:n+(" "+l)}}return n??t.default}function sa(t,n){return t=Nm(t),n=Nm(n),n==null?t==="auto"?null:t:n==="auto"?null:n}var Ll=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},di=[],rr=0,$u=0;function Ol(){for(var t=rr,n=$u=rr=0;n<t;){var i=di[n];di[n++]=null;var s=di[n];di[n++]=null;var l=di[n];di[n++]=null;var u=di[n];if(di[n++]=null,s!==null&&l!==null){var g=s.pending;g===null?l.next=l:(l.next=g.next,g.next=l),s.pending=l}u!==0&&Um(i,l,u)}}function zl(t,n,i,s){di[rr++]=t,di[rr++]=n,di[rr++]=i,di[rr++]=s,$u|=s,t.lanes|=s,t=t.alternate,t!==null&&(t.lanes|=s)}function tf(t,n,i,s){return zl(t,n,i,s),Pl(t)}function _s(t,n){return zl(t,null,null,n),Pl(t)}function Um(t,n,i){t.lanes|=i;var s=t.alternate;s!==null&&(s.lanes|=i);for(var l=!1,u=t.return;u!==null;)u.childLanes|=i,s=u.alternate,s!==null&&(s.childLanes|=i),u.tag===22&&(t=u.stateNode,t===null||t._visibility&1||(l=!0)),t=u,u=u.return;return t.tag===3?(u=t.stateNode,l&&n!==null&&(l=31-Un(i),t=u.hiddenUpdates,s=t[l],s===null?t[l]=[n]:s.push(n),n.lane=i|536870912),u):null}function Pl(t){if(50<Xo)throw Xo=0,bc=null,Error(r(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var or={};function Qy(t,n,i,s){this.tag=t,this.key=i,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=s,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function kn(t,n,i,s){return new Qy(t,n,i,s)}function ef(t){return t=t.prototype,!(!t||!t.isReactComponent)}function ra(t,n){var i=t.alternate;return i===null?(i=kn(t.tag,n,t.key,t.mode),i.elementType=t.elementType,i.type=t.type,i.stateNode=t.stateNode,i.alternate=t,t.alternate=i):(i.pendingProps=n,i.type=t.type,i.flags=0,i.subtreeFlags=0,i.deletions=null),i.flags=t.flags&1206910976,i.childLanes=t.childLanes,i.lanes=t.lanes,i.child=t.child,i.memoizedProps=t.memoizedProps,i.memoizedState=t.memoizedState,i.updateQueue=t.updateQueue,n=t.dependencies,i.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},i.sibling=t.sibling,i.index=t.index,i.ref=t.ref,i.refCleanup=t.refCleanup,i}function Lm(t,n){t.flags&=1206910978;var i=t.alternate;return i===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=i.childLanes,t.lanes=i.lanes,t.child=i.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=i.memoizedProps,t.memoizedState=i.memoizedState,t.updateQueue=i.updateQueue,t.type=i.type,n=i.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function Il(t,n,i,s,l,u){var g=0;if(s=t,typeof s=="function")ef(s)&&(g=1);else if(typeof s=="string")g=bM(t,i,Ft.current)?26:t==="html"||t==="head"||t==="body"?27:5;else t:switch(s){case Gt:return t=kn(31,i,n,l),t.elementType=Gt,t.lanes=u,t;case G:return vs(i.children,l,u,n);case it:g=8,l|=24;break;case ct:return t=kn(12,i,n,l|2),t.elementType=ct,t.lanes=u,t;case rt:return t=kn(13,i,n,l),t.elementType=rt,t.lanes=u,t;case K:return t=kn(19,i,n,l),t.elementType=K,t.lanes=u,t;case re:case B:return t=l|32,t=kn(30,i,n,t),t.elementType=B,t.lanes=u,t.stateNode={autoName:null,paired:null,clones:null,ref:null},t;default:if(typeof s=="object"&&s!==null)switch(s.$$typeof){case ut:g=10;break t;case gt:g=9;break t;case W:g=11;break t;case vt:g=14;break t;case yt:g=16,s=null;break t}g=29,i=Error(r(130,t===null?"null":typeof t,"")),s=null}return n=kn(g,i,n,l),n.elementType=t,n.type=s,n.lanes=u,n}function vs(t,n,i,s){return t=kn(7,t,s,n),t.lanes=i,t}function nf(t,n,i){return t=kn(6,t,null,n),t.lanes=i,t}function Om(t){var n=kn(18,null,null,0);return n.stateNode=t,n}function af(t,n,i){return n=kn(4,t.children!==null?t.children:[],t.key,n),n.lanes=i,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var zm=new WeakMap;function pi(t,n){if(typeof t=="object"&&t!==null){var i=zm.get(t);return i!==void 0?i:(n={value:t,source:n,stack:bt(n)},zm.set(t,n),n)}return{value:t,source:n,stack:bt(n)}}var lr=[],cr=0,Bl=null,Eo=0,mi=[],gi=0,wa=null,Fi=1,Hi="";function oa(t,n){lr[cr++]=Eo,lr[cr++]=Bl,Bl=t,Eo=n}function Pm(t,n,i){mi[gi++]=Fi,mi[gi++]=Hi,mi[gi++]=wa,wa=t;var s=Fi;t=Hi;var l=32-Un(s)-1;s&=~(1<<l),i+=1;var u=32-Un(n)+l;if(30<u){var g=l-l%5;u=(s&(1<<g)-1).toString(32),s>>=g,l-=g,Fi=1<<32-Un(n)+l|i<<l|s,Hi=u+t}else Fi=1<<u|i<<l|s,Hi=t}function Fl(t){t.return!==null&&(oa(t,1),Pm(t,1,0))}function sf(t){for(;t===Bl;)Bl=lr[--cr],lr[cr]=null,Eo=lr[--cr],lr[cr]=null;for(;t===wa;)wa=mi[--gi],mi[gi]=null,Hi=mi[--gi],mi[gi]=null,Fi=mi[--gi],mi[gi]=null}function Im(t,n){mi[gi++]=Fi,mi[gi++]=Hi,mi[gi++]=wa,Fi=n.id,Hi=n.overflow,wa=t}var Sn=null,Ke=null,ge=!1,Da=null,_i=!1,rf=Error(r(519));function Na(t){var n=Error(r(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw To(pi(n,t)),rf}function Bm(t){var n=t.stateNode,i=t.type,s=t.memoizedProps;switch(n[wt]=t,n[Xt]=s,i){case"dialog":ye("cancel",n),ye("close",n);break;case"iframe":case"object":case"embed":ye("load",n);break;case"video":case"audio":for(i=0;i<qo.length;i++)ye(qo[i],n);break;case"source":ye("error",n);break;case"img":case"image":case"link":ye("error",n),ye("load",n);break;case"details":ye("toggle",n);break;case"input":ye("invalid",n),Kp(n,s.value,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name,!0);break;case"select":ye("invalid",n);break;case"textarea":ye("invalid",n),Jp(n,s.value,s.defaultValue,s.children)}i=s.children,typeof i!="string"&&typeof i!="number"&&typeof i!="bigint"||n.textContent===""+i||s.suppressHydrationWarning===!0||s_(n.textContent,i)?(s.popover!=null&&(ye("beforetoggle",n),ye("toggle",n)),s.onScroll!=null&&ye("scroll",n),s.onScrollEnd!=null&&ye("scrollend",n),s.onClick!=null&&(n.onclick=Bi),n=!0):n=!1,n||Na(t,!0)}function Hl(t){for(Sn=t.return;Sn;)switch(Sn.tag){case 5:case 31:case 13:_i=!1;return;case 27:case 3:_i=!0;return;default:Sn=Sn.return}}function ur(t){if(t!==Sn)return!1;if(!ge)return Hl(t),ge=!0,!1;var n=t.tag,i;if((i=n!==3&&n!==27)&&((i=n===5)&&(i=t.type,i=!(i!=="form"&&i!=="button")||Ph(t.type,t.memoizedProps)),i=!i),i&&Ke&&Na(t),Hl(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(317));Ke=T_(t)}else if(n===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(317));Ke=T_(t)}else n===27?(n=Ke,Ya(t.type)?(t=jh,jh=null,Ke=t):Ke=n):Ke=Sn?xi(t.stateNode.nextSibling):null;return!0}function xs(){Ke=Sn=null,ge=!1}function of(){var t=Da;return t!==null&&(qn===null?qn=t:qn.push.apply(qn,t),Da=null),t}function To(t){Da===null?Da=[t]:Da.push(t)}var lf=Qt(null),ys=null,la=null;function Ua(t,n,i){ie(lf,n._currentValue),n._currentValue=i}function ca(t){t._currentValue=lf.current,Lt(lf)}function Gl(t,n,i){for(;t!==null;){var s=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,s!==null&&(s.childLanes|=n)):s!==null&&(s.childLanes&n)!==n&&(s.childLanes|=n),t===i)break;t=t.return}}function cf(t,n,i,s){var l=t.child;for(l!==null&&(l.return=t);l!==null;){var u=l.dependencies;if(u!==null){var g=l.child;u=u.firstContext;t:for(;u!==null;){var E=u;u=l;for(var O=0;O<n.length;O++)if(E.context===n[O]){u.lanes|=i,E=u.alternate,E!==null&&(E.lanes|=i),Gl(u.return,i,t),s||(g=null);break t}u=E.next}}else if(l.tag===18){if(g=l.return,g===null)throw Error(r(341));g.lanes|=i,u=g.alternate,u!==null&&(u.lanes|=i),Gl(g,i,t),g=null}else l.tag===13&&l.memoizedState!==null&&l.memoizedState.dehydrated===null?(l.lanes|=i,g=l.alternate,g!==null&&(g.lanes|=i),Gl(l.return,i,t),g=l.child,g=g!==null?g.sibling:null):g=l.child;if(g!==null)g.return=l;else for(g=l;g!==null;){if(g===t){g=null;break}if(l=g.sibling,l!==null){l.return=g.return,g=l;break}g=g.return}l=g}}function Ss(t,n,i,s){t=null;for(var l=n,u=!1;l!==null;){if(!u){if((l.flags&524288)!==0)u=!0;else if((l.flags&262144)!==0)break}if(l.tag===10){var g=l.alternate;if(g===null)throw Error(r(387));if(g=g.memoizedProps,g!==null){var E=l.type;ti(l.pendingProps.value,g.value)||(t!==null?t.push(E):t=[E])}}else if(l===We.current){if(g=l.alternate,g===null)throw Error(r(387));g.memoizedState.memoizedState!==l.memoizedState.memoizedState&&(t!==null?t.push(zr):t=[zr])}l=l.return}return t!==null&&cf(n,t,i,s),n.flags|=262144,t!==null}function Vl(t){for(t=t.firstContext;t!==null;){if(!ti(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function Ms(t){ys=t,la=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function An(t){return Fm(ys,t)}function kl(t,n){return ys===null&&Ms(t),Fm(t,n)}function Fm(t,n){var i=n._currentValue;if(n={context:n,memoizedValue:i,next:null},la===null){if(t===null)throw Error(r(308));la=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else la=la.next=n;return i}var Jy=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(i,s){t.push(s)}};this.abort=function(){n.aborted=!0,t.forEach(function(i){return i()})}},$y=o.unstable_scheduleCallback,tS=o.unstable_NormalPriority,fn={$$typeof:ut,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function uf(){return{controller:new Jy,data:new Map,refCount:0}}function bo(t){t.refCount--,t.refCount===0&&$y(tS,function(){t.controller.abort()})}function Hm(t,n){if((t.pendingLanes&4194048)!==0){var i=t.transitionTypes;for(i===null&&(i=t.transitionTypes=[]),t=0;t<n.length;t++){var s=n[t];i.indexOf(s)===-1&&i.push(s)}}}var Ao=null;function eS(t){var n=t.transitionTypes;return t.transitionTypes=null,n}var Ro=null,ff=0,Es=0,fr=null;function nS(t,n){if(Ro===null){var i=Ro=[];ff=0,Es=Rh(),fr={status:"pending",value:void 0,then:function(s){i.push(s)}}}return ff++,n.then(Gm,Gm),n}function Gm(){if(--ff===0&&(Ao=null,Ro!==null)){fr!==null&&(fr.status="fulfilled");var t=Ro;Ro=null,Es=0,fr=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function iS(t,n){var i=[],s={status:"pending",value:null,reason:null,then:function(l){i.push(l)}};return t.then(function(){s.status="fulfilled",s.value=n;for(var l=0;l<i.length;l++)(0,i[l])(n)},function(l){for(s.status="rejected",s.reason=l,l=0;l<i.length;l++)(0,i[l])(void 0)}),s}var Vm=Et.S;Et.S=function(t,n){if(O0=X(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&nS(t,n),Ao!==null)for(var i=wr;i!==null;)Hm(i,Ao),i=i.next;if(i=t.types,i!==null){for(var s=wr;s!==null;)Hm(s,i),s=s.next;if(Es!==0){s=Ao,s===null&&(s=Ao=[]);for(var l=0;l<i.length;l++){var u=i[l];s.indexOf(u)===-1&&s.push(u)}}}Vm!==null&&Vm(t,n)};var Ts=Qt(null);function hf(){var t=Ts.current;return t!==null?t:Ye.pooledCache}function Xl(t,n){n===null?ie(Ts,Ts.current):ie(Ts,n.pool)}function km(){var t=hf();return t===null?null:{parent:fn._currentValue,pool:t}}var hr=Error(r(460)),df=Error(r(474)),jl=Error(r(542)),ql={then:function(){}};function Xm(t){return t=t.status,t==="fulfilled"||t==="rejected"}function jm(t,n,i){switch(i=t[i],i===void 0?t.push(n):i!==n&&(n.then(Bi,Bi),n=i),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Ym(t),t===void 0&&!("reason"in n)?Error(r(600)):t;default:if(typeof n.status=="string")n.then(Bi,Bi);else{if(t=Ye,t!==null&&100<t.shellSuspendCounter)throw Error(r(482));t=n,t.status="pending",t.then(function(s){if(n.status==="pending"){var l=n;l.status="fulfilled",l.value=s}},function(s){if(n.status==="pending"){var l=n;l.status="rejected",l.reason=s}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Ym(t),t}throw As=n,hr}}function bs(t){try{var n=t._init;return n(t._payload)}catch(i){throw i!==null&&typeof i=="object"&&typeof i.then=="function"?(As=i,hr):i}}var As=null;function qm(){if(As===null)throw Error(r(459));var t=As;return As=null,t}function Ym(t){if(t===hr||t===jl)throw Error(r(483))}var dr=null,Co=0;function Yl(t){var n=Co;return Co+=1,dr===null&&(dr=[]),jm(dr,t,n)}function La(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function Wl(t,n){throw n.$$typeof===k?Error(r(525)):(t=Object.prototype.toString.call(n),Error(r(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function Wm(t){function n(q,V){if(t){var J=q.deletions;J===null?(q.deletions=[V],q.flags|=16):J.push(V)}}function i(q,V){if(!t)return null;for(;V!==null;)n(q,V),V=V.sibling;return null}function s(q){for(var V=new Map;q!==null;)q.key===null?V.set(q.index,q):V.set(q.key,q),q=q.sibling;return V}function l(q,V){return q=ra(q,V),q.index=0,q.sibling=null,q}function u(q,V,J){return q.index=J,t?(J=q.alternate,J!==null?(J=J.index,J<V?(q.flags|=2,V):J):(q.flags|=134217730,V)):(q.flags|=1048576,V)}function g(q){return t&&q.alternate===null&&(q.flags|=134217730),q}function E(q,V,J,dt){return V===null||V.tag!==6?(V=nf(J,q.mode,dt),V.return=q,V):(V=l(V,J),V.return=q,V)}function O(q,V,J,dt){var Ht=J.type;return Ht===G?(q=at(q,V,J.props.children,dt,J.key),La(q,J),q):V!==null&&(V.elementType===Ht||typeof Ht=="object"&&Ht!==null&&Ht.$$typeof===yt&&bs(Ht)===V.type)?(V=l(V,J.props),La(V,J),V.return=q,V):(V=Il(J.type,J.key,J.props,null,q.mode,dt),La(V,J),V.return=q,V)}function Y(q,V,J,dt){return V===null||V.tag!==4||V.stateNode.containerInfo!==J.containerInfo||V.stateNode.implementation!==J.implementation?(V=af(J,q.mode,dt),V.return=q,V):(V=l(V,J.children||[]),V.return=q,V)}function at(q,V,J,dt,Ht){return V===null||V.tag!==7?(V=vs(J,q.mode,dt,Ht),V.return=q,V):(V=l(V,J),V.return=q,V)}function mt(q,V,J){if(typeof V=="string"&&V!==""||typeof V=="number"||typeof V=="bigint")return V=nf(""+V,q.mode,J),V.return=q,V;if(typeof V=="object"&&V!==null){switch(V.$$typeof){case C:return J=Il(V.type,V.key,V.props,null,q.mode,J),La(J,V),J.return=q,J;case w:return V=af(V,q.mode,J),V.return=q,V;case yt:return V=bs(V),mt(q,V,J)}if(Rt(V)||st(V))return V=vs(V,q.mode,J,null),V.return=q,V;if(typeof V.then=="function")return mt(q,Yl(V),J);if(V.$$typeof===ut)return mt(q,kl(q,V),J);Wl(q,V)}return null}function j(q,V,J,dt){var Ht=V!==null?V.key:null;if(typeof J=="string"&&J!==""||typeof J=="number"||typeof J=="bigint")return Ht!==null?null:E(q,V,""+J,dt);if(typeof J=="object"&&J!==null){switch(J.$$typeof){case C:return J.key===Ht?O(q,V,J,dt):null;case w:return J.key===Ht?Y(q,V,J,dt):null;case yt:return J=bs(J),j(q,V,J,dt)}if(Rt(J)||st(J))return Ht!==null?null:at(q,V,J,dt,null);if(typeof J.then=="function")return j(q,V,Yl(J),dt);if(J.$$typeof===ut)return j(q,V,kl(q,J),dt);Wl(q,J)}return null}function tt(q,V,J,dt,Ht){if(typeof dt=="string"&&dt!==""||typeof dt=="number"||typeof dt=="bigint")return q=q.get(J)||null,E(V,q,""+dt,Ht);if(typeof dt=="object"&&dt!==null){switch(dt.$$typeof){case C:return q=q.get(dt.key===null?J:dt.key)||null,O(V,q,dt,Ht);case w:return q=q.get(dt.key===null?J:dt.key)||null,Y(V,q,dt,Ht);case yt:return dt=bs(dt),tt(q,V,J,dt,Ht)}if(Rt(dt)||st(dt))return q=q.get(J)||null,at(V,q,dt,Ht,null);if(typeof dt.then=="function")return tt(q,V,J,Yl(dt),Ht);if(dt.$$typeof===ut)return tt(q,V,J,kl(V,dt),Ht);Wl(V,dt)}return null}function Nt(q,V,J,dt){for(var Ht=null,Ee=null,Jt=V,ae=V=0,pn=null;Jt!==null&&ae<J.length;ae++){Jt.index>ae?(pn=Jt,Jt=null):pn=Jt.sibling;var Re=j(q,Jt,J[ae],dt);if(Re===null){Jt===null&&(Jt=pn);break}t&&Jt&&Re.alternate===null&&n(q,Jt),V=u(Re,V,ae),Ee===null?Ht=Re:Ee.sibling=Re,Ee=Re,Jt=pn}if(ae===J.length)return i(q,Jt),ge&&oa(q,ae),Ht;if(Jt===null){for(;ae<J.length;ae++)Jt=mt(q,J[ae],dt),Jt!==null&&(V=u(Jt,V,ae),Ee===null?Ht=Jt:Ee.sibling=Jt,Ee=Jt);return ge&&oa(q,ae),Ht}for(Jt=s(Jt);ae<J.length;ae++)pn=tt(Jt,q,ae,J[ae],dt),pn!==null&&(t&&(Re=pn.alternate,Re!==null&&Jt.delete(Re.key===null?ae:Re.key)),V=u(pn,V,ae),Ee===null?Ht=pn:Ee.sibling=pn,Ee=pn);return t&&Jt.forEach(function(Ja){return n(q,Ja)}),ge&&oa(q,ae),Ht}function jt(q,V,J,dt){if(J==null)throw Error(r(151));for(var Ht=null,Ee=null,Jt=V,ae=V=0,pn=null,Re=J.next();Jt!==null&&!Re.done;ae++,Re=J.next()){Jt.index>ae?(pn=Jt,Jt=null):pn=Jt.sibling;var Ja=j(q,Jt,Re.value,dt);if(Ja===null){Jt===null&&(Jt=pn);break}t&&Jt&&Ja.alternate===null&&n(q,Jt),V=u(Ja,V,ae),Ee===null?Ht=Ja:Ee.sibling=Ja,Ee=Ja,Jt=pn}if(Re.done)return i(q,Jt),ge&&oa(q,ae),Ht;if(Jt===null){for(;!Re.done;ae++,Re=J.next())Re=mt(q,Re.value,dt),Re!==null&&(V=u(Re,V,ae),Ee===null?Ht=Re:Ee.sibling=Re,Ee=Re);return ge&&oa(q,ae),Ht}for(Jt=s(Jt);!Re.done;ae++,Re=J.next())Re=tt(Jt,q,ae,Re.value,dt),Re!==null&&(t&&(pn=Re.alternate,pn!==null&&Jt.delete(pn.key===null?ae:pn.key)),V=u(Re,V,ae),Ee===null?Ht=Re:Ee.sibling=Re,Ee=Re);return t&&Jt.forEach(function(IM){return n(q,IM)}),ge&&oa(q,ae),Ht}function he(q,V,J,dt){if(typeof J=="object"&&J!==null&&J.type===G&&J.key===null&&J.props.ref===void 0&&(J=J.props.children),typeof J=="object"&&J!==null){switch(J.$$typeof){case C:t:{for(var Ht=J.key;V!==null;){if(V.key===Ht){if(Ht=J.type,Ht===G){if(V.tag===7){i(q,V.sibling),dt=l(V,J.props.children),La(dt,J),dt.return=q,q=dt;break t}}else if(V.elementType===Ht||typeof Ht=="object"&&Ht!==null&&Ht.$$typeof===yt&&bs(Ht)===V.type){i(q,V.sibling),dt=l(V,J.props),La(dt,J),dt.return=q,q=dt;break t}i(q,V);break}else n(q,V);V=V.sibling}J.type===G?(dt=vs(J.props.children,q.mode,dt,J.key),La(dt,J),dt.return=q,q=dt):(dt=Il(J.type,J.key,J.props,null,q.mode,dt),La(dt,J),dt.return=q,q=dt)}return g(q);case w:t:{for(Ht=J.key;V!==null;){if(V.key===Ht)if(V.tag===4&&V.stateNode.containerInfo===J.containerInfo&&V.stateNode.implementation===J.implementation){i(q,V.sibling),dt=l(V,J.children||[]),dt.return=q,q=dt;break t}else{i(q,V);break}else n(q,V);V=V.sibling}dt=af(J,q.mode,dt),dt.return=q,q=dt}return g(q);case yt:return J=bs(J),he(q,V,J,dt)}if(Rt(J))return Nt(q,V,J,dt);if(st(J)){if(Ht=st(J),typeof Ht!="function")throw Error(r(150));return J=Ht.call(J),jt(q,V,J,dt)}if(typeof J.then=="function")return he(q,V,Yl(J),dt);if(J.$$typeof===ut)return he(q,V,kl(q,J),dt);Wl(q,J)}return typeof J=="string"&&J!==""||typeof J=="number"||typeof J=="bigint"?(J=""+J,V!==null&&V.tag===6?(i(q,V.sibling),dt=l(V,J),dt.return=q,q=dt):(i(q,V),dt=nf(J,q.mode,dt),dt.return=q,q=dt),g(q)):i(q,V)}return function(q,V,J,dt){try{Co=0;var Ht=he(q,V,J,dt);return dr=null,Ht}catch(Jt){if(Jt===hr||Jt===jl)throw Jt;var Ee=kn(29,Jt,null,q.mode);return Ee.lanes=dt,Ee.return=q,Ee}}}var Rs=Wm(!0),Zm=Wm(!1),Oa=!1;function pf(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function mf(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function za(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function Pa(t,n,i){var s=t.updateQueue;if(s===null)return null;if(s=s.shared,(ze&2)!==0){var l=s.pending;return l===null?n.next=n:(n.next=l.next,l.next=n),s.pending=n,n=Pl(t),Um(t,null,i),n}return zl(t,s,n,i),Pl(t)}function wo(t,n,i){if(n=n.updateQueue,n!==null&&(n=n.shared,(i&4194048)!==0)){var s=n.lanes;s&=t.pendingLanes,i|=s,n.lanes=i,Z(t,i)}}function gf(t,n){var i=t.updateQueue,s=t.alternate;if(s!==null&&(s=s.updateQueue,i===s)){var l=null,u=null;if(i=i.firstBaseUpdate,i!==null){do{var g={lane:i.lane,tag:i.tag,payload:i.payload,callback:null,next:null};u===null?l=u=g:u=u.next=g,i=i.next}while(i!==null);u===null?l=u=n:u=u.next=n}else l=u=n;i={baseState:s.baseState,firstBaseUpdate:l,lastBaseUpdate:u,shared:s.shared,callbacks:s.callbacks},t.updateQueue=i;return}t=i.lastBaseUpdate,t===null?i.firstBaseUpdate=n:t.next=n,i.lastBaseUpdate=n}var _f=!1;function Do(){if(_f){var t=fr;if(t!==null)throw t}}function No(t,n,i,s){_f=!1;var l=t.updateQueue;Oa=!1;var u=l.firstBaseUpdate,g=l.lastBaseUpdate,E=l.shared.pending;if(E!==null){l.shared.pending=null;var O=E,Y=O.next;O.next=null,g===null?u=Y:g.next=Y,g=O;var at=t.alternate;at!==null&&(at=at.updateQueue,E=at.lastBaseUpdate,E!==g&&(E===null?at.firstBaseUpdate=Y:E.next=Y,at.lastBaseUpdate=O))}if(u!==null){var mt=l.baseState;g=0,at=Y=O=null,E=u;do{var j=E.lane&-536870913,tt=j!==E.lane;if(tt?(Me&j)===j:(s&j)===j){j!==0&&j===Es&&(_f=!0),at!==null&&(at=at.next={lane:0,tag:E.tag,payload:E.payload,callback:null,next:null});t:{var Nt=t,jt=E;j=n;var he=i;switch(jt.tag){case 1:if(Nt=jt.payload,typeof Nt=="function"){mt=Nt.call(he,mt,j);break t}mt=Nt;break t;case 3:Nt.flags=Nt.flags&-65537|128;case 0:if(Nt=jt.payload,j=typeof Nt=="function"?Nt.call(he,mt,j):Nt,j==null)break t;mt=P({},mt,j);break t;case 2:Oa=!0}}j=E.callback,j!==null&&(t.flags|=64,tt&&(t.flags|=8192),tt=l.callbacks,tt===null?l.callbacks=[j]:tt.push(j))}else tt={lane:j,tag:E.tag,payload:E.payload,callback:E.callback,next:null},at===null?(Y=at=tt,O=mt):at=at.next=tt,g|=j;if(E=E.next,E===null){if(E=l.shared.pending,E===null)break;tt=E,E=tt.next,tt.next=null,l.lastBaseUpdate=tt,l.shared.pending=null}}while(!0);at===null&&(O=mt),l.baseState=O,l.firstBaseUpdate=Y,l.lastBaseUpdate=at,u===null&&(l.shared.lanes=0),ka|=g,t.lanes=g,t.memoizedState=mt}}function Km(t,n){if(typeof t!="function")throw Error(r(191,t));t.call(n)}function Qm(t,n){var i=t.callbacks;if(i!==null)for(t.callbacks=null,t=0;t<i.length;t++)Km(i[t],n)}var Ia=Qt(null),Zl=Qt(0);function Jm(t,n){t=pa,ie(Zl,t),ie(Ia,n),pa=t|n.baseLanes}function vf(){ie(Zl,pa),ie(Ia,Ia.current)}function xf(){pa=Zl.current,Lt(Ia),Lt(Zl)}var Rn=Qt(null),On=null;function Ba(t){var n=t.alternate;ie(Cn,Cn.current&1),ie(Rn,t),On===null&&(n===null||Ia.current!==null||n.memoizedState!==null)&&(On=t)}function yf(t){ie(Cn,Cn.current),ie(Rn,t),On===null&&(On=t)}function $m(t){t.tag===22?(ie(Cn,Cn.current),ie(Rn,t),On===null&&(On=t)):Fa()}function Fa(){ie(Cn,Cn.current),ie(Rn,Rn.current)}function ei(t){Lt(Rn),On===t&&(On=null),Lt(Cn)}var Cn=Qt(0);function Uo(t,n){ie(Rn,Rn.current),ie(Cn,n)}function Sf(t){Lt(Cn),Lt(Rn),On===t&&(On=null)}function Kl(t){for(var n=t;n!==null;){if(n.tag===13){var i=n.memoizedState;if(i!==null&&(i=i.dehydrated,i===null||kh(i)||Xh(i)))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!=="independent"){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var ua=0,fe=null,ke=null,hn=null,Ql=!1,pr=!1,Cs=!1,Jl=0,Lo=0,mr=null,aS=0;function on(){throw Error(r(321))}function Mf(t,n){if(n===null)return!1;for(var i=0;i<n.length&&i<t.length;i++)if(!ti(t[i],n[i]))return!1;return!0}function Ef(t,n,i,s,l,u){return ua=u,fe=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,Et.H=t===null||t.memoizedState===null?Pg:Ig,Cs=!1,u=i(s,l),Cs=!1,pr&&(u=eg(n,i,s,l)),tg(t),u}function tg(t){Et.H=sc;var n=ke!==null&&ke.next!==null;if(ua=0,hn=ke=fe=null,Ql=!1,Lo=0,mr=null,n)throw Error(r(300));t===null||dn||(t=t.dependencies,t!==null&&Vl(t)&&(dn=!0))}function eg(t,n,i,s){fe=t;var l=0;do{if(pr&&(mr=null),Lo=0,pr=!1,25<=l)throw Error(r(301));if(l+=1,hn=ke=null,t.updateQueue!=null){var u=t.updateQueue;u.lastEffect=null,u.events=null,u.stores=null,u.memoCache!=null&&(u.memoCache.index=0)}Et.H=hS,u=n(i,s)}while(pr);return u}function sS(){var t=Et.H,n=t.useState()[0];return n=typeof n.then=="function"?Oo(n):n,t=t.useState()[0],(ke!==null?ke.memoizedState:null)!==t&&(fe.flags|=1024),n}function Tf(){var t=Jl!==0;return Jl=0,t}function bf(t,n,i){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~i}function Af(t){if(Ql){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}Ql=!1}ua=0,hn=ke=fe=null,pr=!1,Lo=Jl=0,mr=null}function Fn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return hn===null?fe.memoizedState=hn=t:hn=hn.next=t,hn}function cn(){if(ke===null){var t=fe.alternate;t=t!==null?t.memoizedState:null}else t=ke.next;var n=hn===null?fe.memoizedState:hn.next;if(n!==null)hn=n,ke=t;else{if(t===null)throw fe.alternate===null?Error(r(467)):Error(r(310));ke=t,t={memoizedState:ke.memoizedState,baseState:ke.baseState,baseQueue:ke.baseQueue,queue:ke.queue,next:null},hn===null?fe.memoizedState=hn=t:hn=hn.next=t}return hn}function $l(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Oo(t){var n=Lo;return Lo+=1,mr===null&&(mr=[]),t=jm(mr,t,n),n=fe,(hn===null?n.memoizedState:hn.next)===null&&(n=n.alternate,Et.H=n===null||n.memoizedState===null?Pg:Ig),t}function tc(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Oo(t);if(t.$$typeof===ft)return;if(t.$$typeof===ut)return An(t)}throw Error(r(438,String(t)))}function Rf(t){var n=null,i=fe.updateQueue;if(i!==null&&(n=i.memoCache),n==null){var s=fe.alternate;s!==null&&(s=s.updateQueue,s!==null&&(s=s.memoCache,s!=null&&(n={data:s.data.map(function(l){return l.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),i===null&&(i=$l(),fe.updateQueue=i),i.memoCache=n,i=n.data[n.index],i===void 0)for(i=n.data[n.index]=Array(t),s=0;s<t;s++)i[s]=Ae;return n.index++,i}function fa(t,n){return typeof n=="function"?n(t):n}function ec(t){var n=cn();return Cf(n,ke,t)}function Cf(t,n,i){var s=t.queue;if(s===null)throw Error(r(311));s.lastRenderedReducer=i;var l=t.baseQueue,u=s.pending;if(u!==null){if(l!==null){var g=l.next;l.next=u.next,u.next=g}n.baseQueue=l=u,s.pending=null}if(u=t.baseState,l===null)t.memoizedState=u;else{n=l.next;var E=g=null,O=null,Y=n,at=!1;do{var mt=Y.lane&-536870913;if(mt!==Y.lane?(Me&mt)===mt:(ua&mt)===mt){var j=Y.revertLane;if(j===0)O!==null&&(O=O.next={lane:0,revertLane:0,gesture:null,action:Y.action,hasEagerState:Y.hasEagerState,eagerState:Y.eagerState,next:null}),mt===Es&&(at=!0);else if((ua&j)===j){Y=Y.next,j===Es&&(at=!0);continue}else mt={lane:0,revertLane:Y.revertLane,gesture:null,action:Y.action,hasEagerState:Y.hasEagerState,eagerState:Y.eagerState,next:null},O===null?(E=O=mt,g=u):O=O.next=mt,fe.lanes|=j,ka|=j;mt=Y.action,Cs&&i(u,mt),u=Y.hasEagerState?Y.eagerState:i(u,mt)}else j={lane:mt,revertLane:Y.revertLane,gesture:Y.gesture,action:Y.action,hasEagerState:Y.hasEagerState,eagerState:Y.eagerState,next:null},O===null?(E=O=j,g=u):O=O.next=j,fe.lanes|=mt,ka|=mt;Y=Y.next}while(Y!==null&&Y!==n);if(O===null?g=u:O.next=E,!ti(u,t.memoizedState)&&(dn=!0,at&&(i=fr,i!==null)))throw i;t.memoizedState=u,t.baseState=g,t.baseQueue=O,s.lastRenderedState=u}return l===null&&(s.lanes=0),[t.memoizedState,s.dispatch]}function wf(t){var n=cn(),i=n.queue;if(i===null)throw Error(r(311));i.lastRenderedReducer=t;var s=i.dispatch,l=i.pending,u=n.memoizedState;if(l!==null){i.pending=null;var g=l=l.next;do u=t(u,g.action),g=g.next;while(g!==l);ti(u,n.memoizedState)||(dn=!0),n.memoizedState=u,n.baseQueue===null&&(n.baseState=u),i.lastRenderedState=u}return[u,s]}function ng(t,n,i){var s=fe,l=cn(),u=ge;if(u){if(i===void 0)throw Error(r(407));i=i()}else i=n();var g=!ti((ke||l).memoizedState,i);if(g&&(l.memoizedState=i,dn=!0),l=l.queue,Uf(sg.bind(null,s,l,t),[t]),t=l.getSnapshot!==n||g||hn!==null&&(hn.memoizedState.tag&1)!==0,gr(t?9:8,{destroy:void 0},ag.bind(null,s,l,i,n),null),t){if(s.flags|=2048,Ye===null)throw Error(r(349));u||(ua&127)!==0||ig(s,n,i)}return i}function ig(t,n,i){t.flags|=16384,t={getSnapshot:n,value:i},n=fe.updateQueue,n===null?(n=$l(),fe.updateQueue=n,n.stores=[t]):(i=n.stores,i===null?n.stores=[t]:i.push(t))}function ag(t,n,i,s){n.value=i,n.getSnapshot=s,rg(n)&&og(t)}function sg(t,n,i){return i(function(){rg(n)&&og(t)})}function rg(t){var n=t.getSnapshot;t=t.value;try{var i=n();return!ti(t,i)}catch{return!0}}function og(t){var n=_s(t,2);n!==null&&Yn(n,t,2)}function Df(t){var n=Fn();if(typeof t=="function"){var i=t;if(t=i(),Cs){gn(!0);try{i()}finally{gn(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:t},n}function lg(t,n,i,s){return t.baseState=i,Cf(t,ke,typeof s=="function"?s:fa)}function rS(t,n,i,s,l){if(ac(t))throw Error(r(485));if(t=n.action,t!==null){var u={payload:l,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(g){u.listeners.push(g)}};Et.T!==null?i(!0):u.isTransition=!1,s(u),i=n.pending,i===null?(u.next=n.pending=u,cg(n,u)):(u.next=i.next,n.pending=i.next=u)}}function cg(t,n){var i=n.action,s=n.payload,l=t.state;if(n.isTransition){var u=Et.T,g={};g.types=u!==null?u.types:null,Et.T=g;try{var E=i(l,s),O=Et.S;O!==null&&O(g,E),ug(t,n,E)}catch(Y){Nf(t,n,Y)}finally{u!==null&&g.types!==null&&(u.types=g.types),Et.T=u}}else try{u=i(l,s),ug(t,n,u)}catch(Y){Nf(t,n,Y)}}function ug(t,n,i){i!==null&&typeof i=="object"&&typeof i.then=="function"?i.then(function(s){fg(t,n,s)},function(s){return Nf(t,n,s)}):fg(t,n,i)}function fg(t,n,i){n.status="fulfilled",n.value=i,hg(n),t.state=i,n=t.pending,n!==null&&(i=n.next,i===n?t.pending=null:(i=i.next,n.next=i,cg(t,i)))}function Nf(t,n,i){var s=t.pending;if(t.pending=null,s!==null){s=s.next;do n.status="rejected",n.reason=i,hg(n),n=n.next;while(n!==s)}t.action=null}function hg(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function dg(t,n){return n}function pg(t,n){if(ge){var i=Ye.formState;if(i!==null){t:{var s=fe;if(ge){if(Ke){e:{for(var l=Ke,u=_i;l.nodeType!==8;){if(!u){l=null;break e}if(l=xi(l.nextSibling),l===null){l=null;break e}}u=l.data,l=u==="F!"||u==="F"?l:null}if(l){Ke=xi(l.nextSibling),s=l.data==="F!";break t}}Na(s)}s=!1}s&&(n=i[0])}}return i=Fn(),i.memoizedState=i.baseState=n,s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:dg,lastRenderedState:n},i.queue=s,i=Lg.bind(null,fe,s),s.dispatch=i,s=Df(!1),u=If.bind(null,fe,!1,s.queue),s=Fn(),l={state:n,dispatch:null,action:t,pending:null},s.queue=l,i=rS.bind(null,fe,l,u,i),l.dispatch=i,s.memoizedState=t,[n,i,!1]}function mg(t){var n=cn();return gg(n,ke,t)}function gg(t,n,i){if(n=Cf(t,n,dg)[0],t=ec(fa)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var s=Oo(n)}catch(g){throw g===hr?jl:g}else s=n;n=cn();var l=n.queue,u=l.dispatch;return i!==n.memoizedState&&(fe.flags|=2048,gr(9,{destroy:void 0},oS.bind(null,l,i),null)),[s,u,t]}function oS(t,n){t.action=n}function _g(t){var n=cn(),i=ke;if(i!==null)return gg(n,i,t);cn(),n=n.memoizedState,i=cn();var s=i.queue.dispatch;return i.memoizedState=t,[n,s,!1]}function gr(t,n,i,s){return t={tag:t,create:i,deps:s,inst:n,next:null},n=fe.updateQueue,n===null&&(n=$l(),fe.updateQueue=n),i=n.lastEffect,i===null?n.lastEffect=t.next=t:(s=i.next,i.next=t,t.next=s,n.lastEffect=t),t}function vg(){return cn().memoizedState}function nc(t,n,i,s){var l=Fn();fe.flags|=t,l.memoizedState=gr(1|n,{destroy:void 0},i,s===void 0?null:s)}function ic(t,n,i,s){var l=cn();s=s===void 0?null:s;var u=l.memoizedState.inst;ke!==null&&s!==null&&Mf(s,ke.memoizedState.deps)?l.memoizedState=gr(n,u,i,s):(fe.flags|=t,l.memoizedState=gr(1|n,u,i,s))}function xg(t,n){nc(8390656,8,t,n)}function Uf(t,n){ic(2048,8,t,n)}function lS(t){fe.flags|=4;var n=fe.updateQueue;if(n===null)n=$l(),fe.updateQueue=n,n.events=[t];else{var i=n.events;i===null?n.events=[t]:i.push(t)}}function yg(t){var n=cn().memoizedState;return lS({ref:n,nextImpl:t}),function(){if((ze&2)!==0)throw Error(r(440));return n.impl.apply(void 0,arguments)}}function Sg(t,n){return ic(4,2,t,n)}function Mg(t,n){return ic(4,4,t,n)}function Eg(t,n){if(typeof n=="function"){t=t();var i=n(t);return function(){typeof i=="function"?i():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function Tg(t,n,i){i=i!=null?i.concat([t]):null,ic(4,4,Eg.bind(null,n,t),i)}function Lf(){}function bg(t,n){var i=cn();n=n===void 0?null:n;var s=i.memoizedState;return n!==null&&Mf(n,s[1])?s[0]:(i.memoizedState=[t,n],t)}function Ag(t,n){var i=cn();n=n===void 0?null:n;var s=i.memoizedState;if(n!==null&&Mf(n,s[1]))return s[0];if(s=t(),Cs){gn(!0);try{t()}finally{gn(!1)}}return i.memoizedState=[s,n],s}function Of(t,n,i){return i===void 0||(ua&1073741824)!==0&&(Me&261930)===0?t.memoizedState=n:(t.memoizedState=i,t=P0(),fe.lanes|=t,ka|=t,i)}function Rg(t,n,i,s){return ti(i,n)?i:Ia.current!==null?(t=Of(t,i,s),ti(t,n)||(dn=!0),t):(ua&106)===0||(ua&1073741824)!==0&&(Me&261930)===0?(dn=!0,t.memoizedState=i):(t=P0(),fe.lanes|=t,ka|=t,n)}function Cg(t,n,i,s,l){var u=qt.p;qt.p=u!==0&&8>u?u:8;var g=Et.T,E={};E.types=g!==null?g.types:null,Et.T=E,If(t,!1,n,i);try{var O=l(),Y=Et.S;if(Y!==null&&Y(E,O),O!==null&&typeof O=="object"&&typeof O.then=="function"){var at=iS(O,s);zo(t,n,at,si(t))}else zo(t,n,s,si(t))}catch(mt){zo(t,n,{then:function(){},status:"rejected",reason:mt},si())}finally{qt.p=u,g!==null&&E.types!==null&&(g.types=E.types),Et.T=g}}function cS(){}function zf(t,n,i,s){if(t.tag!==5)throw Error(r(476));var l=wg(t).queue;Cg(t,l,n,I,i===null?cS:function(){return Dg(t),i(s)})}function wg(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:I,baseState:I,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:I},next:null};var i={};return n.next={memoizedState:i,baseState:i,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:i},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function Dg(t){var n=wg(t);n.next===null&&(n=t.alternate.memoizedState),zo(t,n.next.queue,{},si())}function Pf(){return An(zr)}function Ng(){return cn().memoizedState}function Ug(){return cn().memoizedState}function uS(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var i=si();t=za(i);var s=Pa(n,t,i);s!==null&&(Yn(s,n,i),wo(s,n,i)),n={cache:uf()},t.payload=n;return}n=n.return}}function fS(t,n,i){var s=si();i={lane:s,revertLane:0,gesture:null,action:i,hasEagerState:!1,eagerState:null,next:null},ac(t)?Og(n,i):(i=tf(t,n,i,s),i!==null&&(Yn(i,t,s),zg(i,n,s)))}function Lg(t,n,i){var s=si();zo(t,n,i,s)}function zo(t,n,i,s){var l={lane:s,revertLane:0,gesture:null,action:i,hasEagerState:!1,eagerState:null,next:null};if(ac(t))Og(n,l);else{var u=t.alternate;if(t.lanes===0&&(u===null||u.lanes===0)&&(u=n.lastRenderedReducer,u!==null))try{var g=n.lastRenderedState,E=u(g,i);if(l.hasEagerState=!0,l.eagerState=E,ti(E,g))return zl(t,n,l,0),Ye===null&&Ol(),!1}catch{}if(i=tf(t,n,l,s),i!==null)return Yn(i,t,s),zg(i,n,s),!0}return!1}function If(t,n,i,s){if(s={lane:2,revertLane:Rh(),gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},ac(t)){if(n)throw Error(r(479))}else n=tf(t,i,s,2),n!==null&&Yn(n,t,2)}function ac(t){var n=t.alternate;return t===fe||n!==null&&n===fe}function Og(t,n){pr=Ql=!0;var i=t.pending;i===null?n.next=n:(n.next=i.next,i.next=n),t.pending=n}function zg(t,n,i){if((i&4194048)!==0){var s=n.lanes;s&=t.pendingLanes,i|=s,n.lanes=i,Z(t,i)}}var sc={readContext:An,use:tc,useCallback:on,useContext:on,useEffect:on,useImperativeHandle:on,useLayoutEffect:on,useInsertionEffect:on,useMemo:on,useReducer:on,useRef:on,useState:on,useDebugValue:on,useDeferredValue:on,useTransition:on,useSyncExternalStore:on,useId:on,useHostTransitionStatus:on,useFormState:on,useActionState:on,useOptimistic:on,useMemoCache:on,useCacheRefresh:on,useEffectEvent:on},Pg={readContext:An,use:tc,useCallback:function(t,n){return Fn().memoizedState=[t,n===void 0?null:n],t},useContext:An,useEffect:xg,useImperativeHandle:function(t,n,i){i=i!=null?i.concat([t]):null,nc(4194308,4,Eg.bind(null,n,t),i)},useLayoutEffect:function(t,n){return nc(4194308,4,t,n)},useInsertionEffect:function(t,n){nc(4,2,t,n)},useMemo:function(t,n){var i=Fn();n=n===void 0?null:n;var s=t();if(Cs){gn(!0);try{t()}finally{gn(!1)}}return i.memoizedState=[s,n],s},useReducer:function(t,n,i){var s=Fn();if(i!==void 0){var l=i(n);if(Cs){gn(!0);try{i(n)}finally{gn(!1)}}}else l=n;return s.memoizedState=s.baseState=l,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:l},s.queue=t,t=t.dispatch=fS.bind(null,fe,t),[s.memoizedState,t]},useRef:function(t){var n=Fn();return t={current:t},n.memoizedState=t},useState:function(t){t=Df(t);var n=t.queue,i=Lg.bind(null,fe,n);return n.dispatch=i,[t.memoizedState,i]},useDebugValue:Lf,useDeferredValue:function(t,n){var i=Fn();return Of(i,t,n)},useTransition:function(){var t=Df(!1);return t=Cg.bind(null,fe,t.queue,!0,!1),Fn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,i){var s=fe,l=Fn();if(ge){if(i===void 0)throw Error(r(407));i=i()}else{if(i=n(),Ye===null)throw Error(r(349));(Me&127)!==0||ig(s,n,i)}l.memoizedState=i;var u={value:i,getSnapshot:n};return l.queue=u,xg(sg.bind(null,s,u,t),[t]),s.flags|=2048,gr(9,{destroy:void 0},ag.bind(null,s,u,i,n),null),i},useId:function(){var t=Fn(),n=Ye.identifierPrefix;if(ge){var i=Hi,s=Fi;i=(s&~(1<<32-Un(s)-1)).toString(32)+i,n="_"+n+"R_"+i,i=Jl++,0<i&&(n+="H"+i.toString(32)),n+="_"}else i=aS++,n="_"+n+"r_"+i.toString(32)+"_";return t.memoizedState=n},useHostTransitionStatus:Pf,useFormState:pg,useActionState:pg,useOptimistic:function(t){var n=Fn();n.memoizedState=n.baseState=t;var i={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=i,n=If.bind(null,fe,!0,i),i.dispatch=n,[t,n]},useMemoCache:Rf,useCacheRefresh:function(){return Fn().memoizedState=uS.bind(null,fe)},useEffectEvent:function(t){var n=Fn(),i={impl:t};return n.memoizedState=i,function(){if((ze&2)!==0)throw Error(r(440));return i.impl.apply(void 0,arguments)}}},Ig={readContext:An,use:tc,useCallback:bg,useContext:An,useEffect:Uf,useImperativeHandle:Tg,useInsertionEffect:Sg,useLayoutEffect:Mg,useMemo:Ag,useReducer:ec,useRef:vg,useState:function(){return ec(fa)},useDebugValue:Lf,useDeferredValue:function(t,n){var i=cn();return Rg(i,ke.memoizedState,t,n)},useTransition:function(){var t=ec(fa)[0],n=cn().memoizedState;return[typeof t=="boolean"?t:Oo(t),n]},useSyncExternalStore:ng,useId:Ng,useHostTransitionStatus:Pf,useFormState:mg,useActionState:mg,useOptimistic:function(t,n){var i=cn();return lg(i,ke,t,n)},useMemoCache:Rf,useCacheRefresh:Ug,useEffectEvent:yg},hS={readContext:An,use:tc,useCallback:bg,useContext:An,useEffect:Uf,useImperativeHandle:Tg,useInsertionEffect:Sg,useLayoutEffect:Mg,useMemo:Ag,useReducer:wf,useRef:vg,useState:function(){return wf(fa)},useDebugValue:Lf,useDeferredValue:function(t,n){var i=cn();return ke===null?Of(i,t,n):Rg(i,ke.memoizedState,t,n)},useTransition:function(){var t=wf(fa)[0],n=cn().memoizedState;return[typeof t=="boolean"?t:Oo(t),n]},useSyncExternalStore:ng,useId:Ng,useHostTransitionStatus:Pf,useFormState:_g,useActionState:_g,useOptimistic:function(t,n){var i=cn();return ke!==null?lg(i,ke,t,n):(i.baseState=t,[t,i.queue.dispatch])},useMemoCache:Rf,useCacheRefresh:Ug,useEffectEvent:yg};function Bf(t,n,i,s){n=t.memoizedState,i=i(s,n),i=i==null?n:P({},n,i),t.memoizedState=i,t.lanes===0&&(t.updateQueue.baseState=i)}var Ff={enqueueSetState:function(t,n,i){t=t._reactInternals;var s=si(),l=za(s);l.payload=n,i!=null&&(l.callback=i),n=Pa(t,l,s),n!==null&&(Yn(n,t,s),wo(n,t,s))},enqueueReplaceState:function(t,n,i){t=t._reactInternals;var s=si(),l=za(s);l.tag=1,l.payload=n,i!=null&&(l.callback=i),n=Pa(t,l,s),n!==null&&(Yn(n,t,s),wo(n,t,s))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var i=si(),s=za(i);s.tag=2,n!=null&&(s.callback=n),n=Pa(t,s,i),n!==null&&(Yn(n,t,i),wo(n,t,i))}};function Bg(t,n,i,s,l,u,g){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(s,u,g):n.prototype&&n.prototype.isPureReactComponent?!So(i,s)||!So(l,u):!0}function Fg(t,n,i,s){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(i,s),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(i,s),n.state!==t&&Ff.enqueueReplaceState(n,n.state,null)}function ws(t,n){var i=n;if("ref"in n){i={};for(var s in n)s!=="ref"&&(i[s]=n[s])}if(t=t.defaultProps){i===n&&(i=P({},i));for(var l in t)i[l]===void 0&&(i[l]=t[l])}return i}function Hg(t){Ll(t)}function Gg(t){console.error(t)}function Vg(t){Ll(t)}function rc(t,n){try{var i=t.onUncaughtError;i(n.value,{componentStack:n.stack})}catch(s){setTimeout(function(){throw s})}}function kg(t,n,i){try{var s=t.onCaughtError;s(i.value,{componentStack:i.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(l){setTimeout(function(){throw l})}}function Hf(t,n,i){return i=za(i),i.tag=3,i.payload={element:null},i.callback=function(){rc(t,n)},i}function Xg(t){return t=za(t),t.tag=3,t}function jg(t,n,i,s){var l=i.type.getDerivedStateFromError;if(typeof l=="function"){var u=s.value;t.payload=function(){return l(u)},t.callback=function(){kg(n,i,s)}}var g=i.stateNode;g!==null&&typeof g.componentDidCatch=="function"&&(t.callback=function(){kg(n,i,s),typeof l!="function"&&(Xa===null?Xa=new Set([this]):Xa.add(this));var E=s.stack;this.componentDidCatch(s.value,{componentStack:E!==null?E:""})})}function dS(t,n,i,s,l){if(i.flags|=32768,s!==null&&typeof s=="object"&&typeof s.then=="function"){if(n=i.alternate,n!==null&&Ss(n,i,l,!0),i=Rn.current,i!==null){switch(i.tag){case 31:case 13:case 19:return On===null?Rc():i.alternate===null&&ln===0&&(ln=3),i.flags&=-257,i.flags|=65536,i.lanes=l,s===ql?i.flags|=16384:(n=i.updateQueue,n===null?i.updateQueue=new Set([s]):n.add(s),Th(t,s,l)),!1;case 22:return i.flags|=65536,s===ql?i.flags|=16384:(n=i.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([s])},i.updateQueue=n):(i=n.retryQueue,i===null?n.retryQueue=new Set([s]):i.add(s)),Th(t,s,l)),!1}throw Error(r(435,i.tag))}return Th(t,s,l),Rc(),!1}if(ge)return n=Rn.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=l,s!==rf&&(t=Error(r(422),{cause:s}),To(pi(t,i)))):(s!==rf&&(n=Error(r(423),{cause:s}),To(pi(n,i))),t=t.current.alternate,t.flags|=65536,l&=-l,t.lanes|=l,s=pi(s,i),l=Hf(t.stateNode,s,l),gf(t,l),ln!==4&&(ln=2)),!1;var u=Error(r(520),{cause:s});if(u=pi(u,i),ko===null?ko=[u]:ko.push(u),ln!==4&&(ln=2),n===null)return!0;s=pi(s,i),i=n;do{switch(i.tag){case 3:return i.flags|=65536,t=l&-l,i.lanes|=t,t=Hf(i.stateNode,s,t),gf(i,t),!1;case 1:if(n=i.type,u=i.stateNode,(i.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||u!==null&&typeof u.componentDidCatch=="function"&&(Xa===null||!Xa.has(u))))return i.flags|=65536,l&=-l,i.lanes|=l,l=Xg(l),jg(l,t,i,s),gf(i,l),!1;break;case 22:if(i.memoizedState!==null)return i.flags|=65536,!1}i=i.return}while(i!==null);return!1}var Gf=Error(r(461)),dn=!1;function vn(t,n,i,s){n.child=t===null?Zm(n,null,i,s):Rs(n,t.child,i,s)}function qg(t,n,i,s,l){i=i.render;var u=n.ref;if("ref"in s){var g={};for(var E in s)E!=="ref"&&(g[E]=s[E])}else g=s;return Ms(n),s=Ef(t,n,i,g,u,l),E=Tf(),t!==null&&!dn?(bf(t,n,l),ha(t,n,l)):(ge&&E&&Fl(n),n.flags|=1,vn(t,n,s,l),n.child)}function Yg(t,n,i,s,l){if(t===null){var u=i.type;return typeof u=="function"&&!ef(u)&&u.defaultProps===void 0&&i.compare===null?(n.tag=15,n.type=u,Wg(t,n,u,s,l)):(t=Il(i.type,null,s,n,n.mode,l),t.ref=n.ref,t.return=n,n.child=t)}if(u=t.child,!Zf(t,l)){var g=u.memoizedProps;if(i=i.compare,i=i!==null?i:So,i(g,s)&&t.ref===n.ref)return ha(t,n,l)}return n.flags|=1,t=ra(u,s),t.ref=n.ref,t.return=n,n.child=t}function Wg(t,n,i,s,l){if(t!==null){var u=t.memoizedProps;if(So(u,s)&&t.ref===n.ref)if(dn=!1,n.pendingProps=s=u,Zf(t,l))(t.flags&131072)!==0&&(dn=!0);else return n.lanes=t.lanes,ha(t,n,l)}return Vf(t,n,i,s,l)}function Zg(t,n,i,s){var l=s.children,u=t!==null?t.memoizedState:null;if(t===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),s.mode==="hidden"){if((n.flags&128)!==0){if(u=u!==null?u.baseLanes|i:i,t!==null){for(s=n.child=t.child,l=0;s!==null;)l=l|s.lanes|s.childLanes,s=s.sibling;s=l&~u}else s=0,n.child=null;return Kg(t,n,u,i,s)}if((i&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&Xl(n,u!==null?u.cachePool:null),u!==null?Jm(n,u):vf(),$m(n);else return s=n.lanes=536870912,Kg(t,n,u!==null?u.baseLanes|i:i,i,s)}else u!==null?(Xl(n,u.cachePool),Jm(n,u),Fa(),n.memoizedState=null):(t!==null&&Xl(n,null),vf(),Fa());return vn(t,n,l,i),n.child}function Po(t,n){return t!==null&&t.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function Kg(t,n,i,s,l){var u=hf();return u=u===null?null:{parent:fn._currentValue,pool:u},n.memoizedState={baseLanes:i,cachePool:u},t!==null&&Xl(n,null),vf(),$m(n),t!==null&&Ss(t,n,s,!0),n.childLanes=l,null}function oc(t,n){return n=lc({mode:n.mode,children:n.children},t.mode),n.ref=t.ref,t.child=n,n.return=t,n}function Qg(t,n,i){return Rs(n,t.child,null,i),t=oc(n,n.pendingProps),t.flags|=2,ei(n),n.memoizedState=null,t}function pS(t,n,i){var s=n.pendingProps,l=(n.flags&128)!==0;if(n.flags&=-129,t===null){if(ge){if(s.mode==="hidden")return t=oc(n,s),n.lanes=536870912,t.memoizedState={baseLanes:0,cachePool:null},Po(null,t);if(yf(n),(t=Ke)?(t=E_(t,_i),t=t!==null&&t.data==="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:wa!==null?{id:Fi,overflow:Hi}:null,retryLane:536870912,hydrationErrors:null},i=Om(t),i.return=n,n.child=i,Sn=n,Ke=null)):t=null,t===null)throw Na(n);return n.lanes=536870912,null}return oc(n,s)}var u=t.memoizedState;if(u!==null){var g=u.dehydrated;if(yf(n),l)if(n.flags&256)n.flags&=-257,n=Qg(t,n,i);else if(n.memoizedState!==null)n.child=t.child,n.flags|=128,n=null;else throw Error(r(558));else if(dn||Ss(t,n,i,!1),l=(i&t.childLanes)!==0,dn||l){if(Ia.current===null){if(s=Ye,s!==null&&(g=ot(s,i),g!==0&&g!==u.retryLane))throw u.retryLane=g,_s(t,g),Yn(s,t,g),Gf;Rc()}n=Qg(t,n,i)}else t=u.treeContext,Ke=xi(g.nextSibling),Sn=n,ge=!0,Da=null,_i=!1,t!==null&&Im(n,t),n=oc(n,s),n.flags|=134221824;return n}return t=ra(t.child,{mode:s.mode,children:s.children}),t.ref=n.ref,n.child=t,t.return=n,t}function _r(t,n){var i=n.ref;if(i===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof i!="function"&&typeof i!="object")throw Error(r(284));(t===null||t.ref!==i)&&(n.flags|=4194816)}}function Vf(t,n,i,s,l){return Ms(n),i=Ef(t,n,i,s,void 0,l),s=Tf(),t!==null&&!dn?(bf(t,n,l),ha(t,n,l)):(ge&&s&&Fl(n),n.flags|=1,vn(t,n,i,l),n.child)}function Jg(t,n,i,s,l,u){return Ms(n),n.updateQueue=null,i=eg(n,s,i,l),tg(t),s=Tf(),t!==null&&!dn?(bf(t,n,u),ha(t,n,u)):(ge&&s&&Fl(n),n.flags|=1,vn(t,n,i,u),n.child)}function $g(t,n,i,s,l){if(Ms(n),n.stateNode===null){var u=or,g=i.contextType;typeof g=="object"&&g!==null&&(u=An(g)),u=new i(s,u),n.memoizedState=u.state!==null&&u.state!==void 0?u.state:null,u.updater=Ff,n.stateNode=u,u._reactInternals=n,u=n.stateNode,u.props=s,u.state=n.memoizedState,u.refs={},pf(n),g=i.contextType,u.context=typeof g=="object"&&g!==null?An(g):or,u.state=n.memoizedState,g=i.getDerivedStateFromProps,typeof g=="function"&&(Bf(n,i,g,s),u.state=n.memoizedState),typeof i.getDerivedStateFromProps=="function"||typeof u.getSnapshotBeforeUpdate=="function"||typeof u.UNSAFE_componentWillMount!="function"&&typeof u.componentWillMount!="function"||(g=u.state,typeof u.componentWillMount=="function"&&u.componentWillMount(),typeof u.UNSAFE_componentWillMount=="function"&&u.UNSAFE_componentWillMount(),g!==u.state&&Ff.enqueueReplaceState(u,u.state,null),No(n,s,u,l),Do(),u.state=n.memoizedState),typeof u.componentDidMount=="function"&&(n.flags|=4194308),s=!0}else if(t===null){u=n.stateNode;var E=n.memoizedProps,O=ws(i,E);u.props=O;var Y=u.context,at=i.contextType;g=or,typeof at=="object"&&at!==null&&(g=An(at));var mt=i.getDerivedStateFromProps;at=typeof mt=="function"||typeof u.getSnapshotBeforeUpdate=="function",E=n.pendingProps!==E,at||typeof u.UNSAFE_componentWillReceiveProps!="function"&&typeof u.componentWillReceiveProps!="function"||(E||Y!==g)&&Fg(n,u,s,g),Oa=!1;var j=n.memoizedState;u.state=j,No(n,s,u,l),Do(),Y=n.memoizedState,E||j!==Y||Oa?(typeof mt=="function"&&(Bf(n,i,mt,s),Y=n.memoizedState),(O=Oa||Bg(n,i,O,s,j,Y,g))?(at||typeof u.UNSAFE_componentWillMount!="function"&&typeof u.componentWillMount!="function"||(typeof u.componentWillMount=="function"&&u.componentWillMount(),typeof u.UNSAFE_componentWillMount=="function"&&u.UNSAFE_componentWillMount()),typeof u.componentDidMount=="function"&&(n.flags|=4194308)):(typeof u.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=s,n.memoizedState=Y),u.props=s,u.state=Y,u.context=g,s=O):(typeof u.componentDidMount=="function"&&(n.flags|=4194308),s=!1)}else{u=n.stateNode,mf(t,n),g=n.memoizedProps,at=ws(i,g),u.props=at,mt=n.pendingProps,j=u.context,Y=i.contextType,O=or,typeof Y=="object"&&Y!==null&&(O=An(Y)),E=i.getDerivedStateFromProps,(Y=typeof E=="function"||typeof u.getSnapshotBeforeUpdate=="function")||typeof u.UNSAFE_componentWillReceiveProps!="function"&&typeof u.componentWillReceiveProps!="function"||(g!==mt||j!==O)&&Fg(n,u,s,O),Oa=!1,j=n.memoizedState,u.state=j,No(n,s,u,l),Do();var tt=n.memoizedState;g!==mt||j!==tt||Oa||t!==null&&t.dependencies!==null&&Vl(t.dependencies)?(typeof E=="function"&&(Bf(n,i,E,s),tt=n.memoizedState),(at=Oa||Bg(n,i,at,s,j,tt,O)||t!==null&&t.dependencies!==null&&Vl(t.dependencies))?(Y||typeof u.UNSAFE_componentWillUpdate!="function"&&typeof u.componentWillUpdate!="function"||(typeof u.componentWillUpdate=="function"&&u.componentWillUpdate(s,tt,O),typeof u.UNSAFE_componentWillUpdate=="function"&&u.UNSAFE_componentWillUpdate(s,tt,O)),typeof u.componentDidUpdate=="function"&&(n.flags|=4),typeof u.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof u.componentDidUpdate!="function"||g===t.memoizedProps&&j===t.memoizedState||(n.flags|=4),typeof u.getSnapshotBeforeUpdate!="function"||g===t.memoizedProps&&j===t.memoizedState||(n.flags|=1024),n.memoizedProps=s,n.memoizedState=tt),u.props=s,u.state=tt,u.context=O,s=at):(typeof u.componentDidUpdate!="function"||g===t.memoizedProps&&j===t.memoizedState||(n.flags|=4),typeof u.getSnapshotBeforeUpdate!="function"||g===t.memoizedProps&&j===t.memoizedState||(n.flags|=1024),s=!1)}return u=s,_r(t,n),s=(n.flags&128)!==0,u||s?(u=n.stateNode,i=s&&typeof i.getDerivedStateFromError!="function"?null:u.render(),n.flags|=1,t!==null&&s?(n.child=Rs(n,t.child,null,l),n.child=Rs(n,null,i,l)):vn(t,n,i,l),n.memoizedState=u.state,t=n.child):t=ha(t,n,l),t}function t0(t,n,i,s){return xs(),n.flags|=256,vn(t,n,i,s),n.child}var kf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Xf(t){return{baseLanes:t,cachePool:km()}}function jf(t,n,i){return t=t!==null?t.childLanes&~i:0,n&&(t|=ai),t}function e0(t,n,i){var s=n.pendingProps,l=!1,u=(n.flags&128)!==0,g;if((g=u)||(g=t!==null&&t.memoizedState===null?!1:(Cn.current&2)!==0),g&&(l=!0,n.flags&=-129),g=(n.flags&32)!==0,n.flags&=-33,t===null){if(ge){if(l?Ba(n):Fa(),(t=Ke)?(t=E_(t,_i),t=t!==null&&t.data!=="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:wa!==null?{id:Fi,overflow:Hi}:null,retryLane:536870912,hydrationErrors:null},i=Om(t),i.return=n,n.child=i,Sn=n,Ke=null)):t=null,t===null)throw Na(n);return Xh(t)?n.lanes=32:n.lanes=536870912,null}return u=s.children,s=s.fallback,l?(Fa(),l=n.mode,u=lc({mode:"hidden",children:u},l),s=vs(s,l,i,null),u.return=n,s.return=n,u.sibling=s,n.child=u,s=n.child,s.memoizedState=Xf(i),s.childLanes=jf(t,g,i),n.memoizedState=kf,Po(null,s)):(Ba(n),qf(n,u))}var E=t.memoizedState;if(E!==null){var O=E.dehydrated;if(O!==null)return mS(t,n,u,g,s,O,E,i)}return l?(Fa(),l=s.fallback,u=n.mode,E=t.child,O=E.sibling,s=ra(E,{mode:"hidden",children:s.children}),s.subtreeFlags=E.subtreeFlags&1206910976,O!==null?l=ra(O,l):(l=vs(l,u,i,null),l.flags|=2),l.return=n,s.return=n,s.sibling=l,n.child=s,Po(null,s),s=n.child,l=t.child.memoizedState,l===null?l=Xf(i):(u=l.cachePool,u!==null?(E=fn._currentValue,u=u.parent!==E?{parent:E,pool:E}:u):u=km(),l={baseLanes:l.baseLanes|i,cachePool:u}),s.memoizedState=l,s.childLanes=jf(t,g,i),n.memoizedState=kf,Po(t.child,s)):(Ba(n),i=t.child,t=i.sibling,i=ra(i,{mode:"visible",children:s.children}),i.return=n,i.sibling=null,t!==null&&(g=n.deletions,g===null?(n.deletions=[t],n.flags|=16):g.push(t)),n.child=i,n.memoizedState=null,i)}function qf(t,n){return n=lc({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function lc(t,n){return t=kn(22,t,null,n),t.lanes=0,t}function cc(t,n,i){return Rs(n,t.child,null,i),t=qf(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function mS(t,n,i,s,l,u,g,E){if(i)return n.flags&256?(Ba(n),n.flags&=-257,cc(t,n,E)):n.memoizedState!==null?(Fa(),n.child=t.child,n.flags|=128,null):(Fa(),u=l.fallback,g=n.mode,l=lc({mode:"visible",children:l.children},g),u=vs(u,g,E,null),u.flags|=2,l.return=n,u.return=n,l.sibling=u,n.child=l,Rs(n,t.child,null,E),l=n.child,l.memoizedState=Xf(E),l.childLanes=jf(t,s,E),n.memoizedState=kf,Po(null,l));if(Ba(n),Xh(u)){if(s=u.nextSibling&&u.nextSibling.dataset,s)var O=s.dgst;return s=O,s!==""&&(l=Error(r(419)),l.stack="",l.digest=s,To({value:l,source:null,stack:null})),cc(t,n,E)}if(dn||Ss(t,n,E,!1),s=(E&t.childLanes)!==0,dn||s){if(Ia.current!==null)return cc(t,n,E);if(s=Ye,s!==null&&(l=ot(s,E),l!==0&&l!==g.retryLane))throw g.retryLane=l,_s(t,l),Yn(s,t,l),Gf;return kh(u)||Rc(),cc(t,n,E)}return kh(u)?(n.flags|=192,n.child=t.child,null):(t=g.treeContext,Ke=xi(u.nextSibling),Sn=n,ge=!0,Da=null,_i=!1,t!==null&&Im(n,t),n=qf(n,l.children),n.flags|=134221824,n)}function n0(t,n,i){t.lanes|=n;var s=t.alternate;s!==null&&(s.lanes|=n),Gl(t.return,n,i)}function i0(t){for(var n=null;t!==null;){var i=t.alternate;i!==null&&Kl(i)===null&&(n=t),t=t.sibling}return n}function uc(t,n,i,s,l,u){var g=t.memoizedState;g===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:s,tail:i,tailMode:l,treeForkCount:u}:(g.isBackwards=n,g.rendering=null,g.renderingStartTime=0,g.last=s,g.tail=i,g.tailMode=l,g.treeForkCount=u)}function Yf(t){var n=t.child;for(t.child=null;n!==null;){var i=n.sibling;n.sibling=t.child,t.child=n,n=i}}function Wf(t,n,i){var s=n.pendingProps,l=s.revealOrder,u=s.tail;s=s.children;var g=Cn.current;if(n.flags&128)return Uo(n,g),null;var E=(g&2)!==0;if(E?(g=g&1|2,n.flags|=128):g&=1,Uo(n,g),l==="backwards"&&t!==null?(Yf(t),vn(t,n,s,i),Yf(t)):vn(t,n,s,i),s=ge?Eo:0,!E&&t!==null&&(t.flags&128)!==0)t:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&n0(t,i,n);else if(t.tag===19)n0(t,i,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break t;for(;t.sibling===null;){if(t.return===null||t.return===n)break t;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(l){case"backwards":i=i0(n.child),i===null?(l=n.child,n.child=null):(l=i.sibling,i.sibling=null,Yf(n)),uc(n,!0,l,null,u,s);break;case"unstable_legacy-backwards":for(i=null,l=n.child,n.child=null;l!==null;){if(t=l.alternate,t!==null&&Kl(t)===null){n.child=l;break}t=l.sibling,l.sibling=i,i=l,l=t}uc(n,!0,i,null,u,s);break;case"together":uc(n,!1,null,null,void 0,s);break;case"independent":n.memoizedState=null;break;default:i=i0(n.child),i===null?(l=n.child,n.child=null):(l=i.sibling,i.sibling=null),uc(n,!1,l,i,u,s)}return n.child}function a0(t,n,i){var s=n.pendingProps;return Ua(n,n.type,s.value),vn(t,n,s.children,i),n.child}function ha(t,n,i){if(t!==null&&(n.dependencies=t.dependencies),ka|=n.lanes,(i&n.childLanes)===0)if(t!==null){if(Ss(t,n,i,!1),(i&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(r(153));if(n.child!==null){for(t=n.child,i=ra(t,t.pendingProps),n.child=i,i.return=n;t.sibling!==null;)t=t.sibling,i=i.sibling=ra(t,t.pendingProps),i.return=n;i.sibling=null}return n.child}function Zf(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&Vl(t)))}function gS(t,n,i){switch(n.tag){case 3:U(n,n.stateNode.containerInfo),Ua(n,fn,t.memoizedState.cache),xs();break;case 27:case 5:nt(n);break;case 4:U(n,n.stateNode.containerInfo);break;case 10:Ua(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,yf(n),null;break;case 13:var s=n.memoizedState;if(s!==null){if(s.dehydrated!==null)return Ba(n),n.flags|=128,null;s=Ss(t,n,i,!1);var l=n.child.childLanes;return s||(i&l)!==0?e0(t,n,i):(Ba(n),t=ha(t,n,i),t!==null?t.sibling:null)}Ba(n);break;case 19:if(n.flags&128)return Wf(t,n,i);if(l=(t.flags&128)!==0,s=(i&n.childLanes)!==0,s||(Ss(t,n,i,!1),s=(i&n.childLanes)!==0),l){if(s)return Wf(t,n,i);n.flags|=128}if(l=n.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),Uo(n,Cn.current),s)break;return null;case 22:return n.lanes=0,Zg(t,n,i,n.pendingProps);case 24:Ua(n,fn,t.memoizedState.cache)}return ha(t,n,i)}function s0(t,n,i){if(t!==null)if(t.memoizedProps!==n.pendingProps)dn=!0;else{if(!Zf(t,i)&&(n.flags&128)===0)return dn=!1,gS(t,n,i);dn=(t.flags&131072)!==0}else dn=!1,ge&&(n.flags&1048576)!==0&&Pm(n,Eo,n.index);switch(n.lanes=0,n.tag){case 16:t:{var s=n.pendingProps;if(t=bs(n.elementType),n.type=t,typeof t=="function")ef(t)?(s=ws(t,s),n.tag=1,n=$g(null,n,t,s,i)):(n.tag=0,n=Vf(null,n,t,s,i));else{if(t!=null){var l=t.$$typeof;if(l===W){n.tag=11,n=qg(null,n,t,s,i);break t}else if(l===vt){n.tag=14,n=Yg(null,n,t,s,i);break t}else if(l===ut){n.tag=10,n.type=t,n=a0(null,n,i);break t}}throw n=Ut(t)||t,Error(r(306,n,""))}}return n;case 0:return Vf(t,n,n.type,n.pendingProps,i);case 1:return s=n.type,l=ws(s,n.pendingProps),$g(t,n,s,l,i);case 3:t:{if(U(n,n.stateNode.containerInfo),t===null)throw Error(r(387));s=n.pendingProps;var u=n.memoizedState;l=u.element,mf(t,n),No(n,s,null,i);var g=n.memoizedState;if(s=g.cache,Ua(n,fn,s),s!==u.cache&&cf(n,[fn],i,!0),Do(),s=g.element,u.isDehydrated)if(u={element:s,isDehydrated:!1,cache:g.cache},n.updateQueue.baseState=u,n.memoizedState=u,n.flags&256){n=t0(t,n,s,i);break t}else if(s!==l){l=pi(Error(r(424)),n),To(l),n=t0(t,n,s,i);break t}else for(t=n.stateNode.containerInfo,t.nodeType===9?t=t.body:t=t.nodeName==="HTML"?t.ownerDocument.body:t,Ke=xi(t.firstChild),Sn=n,ge=!0,Da=null,_i=!0,i=Zm(n,null,s,i),n.child=i;i;)i.flags=i.flags&-3|134221824,i=i.sibling;else{if(xs(),s===l){n=ha(t,n,i);break t}vn(t,n,s,i)}n=n.child}return n;case 26:return _r(t,n),t===null?(i=D_(n.type,null,n.pendingProps,null))?n.memoizedState=i:ge||(n.stateNode=c_(n.type,n.pendingProps,qe.current,n)):n.memoizedState=D_(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return nt(n),t===null&&ge&&(s=n.stateNode=A_(n.type,n.pendingProps,qe.current),Sn=n,_i=!0,l=Ke,Ya(n.type)?(jh=l,Ke=xi(s.firstChild)):Ke=l),vn(t,n,n.pendingProps.children,i),_r(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&ge&&((l=s=Ke)&&(s=uM(s,n.type,n.pendingProps,_i),s!==null?(n.stateNode=s,Sn=n,Ke=xi(s.firstChild),_i=!1,l=!0):l=!1),l||Na(n)),nt(n),l=n.type,u=n.pendingProps,g=t!==null?t.memoizedProps:null,s=u.children,Ph(l,u)?s=null:g!==null&&Ph(l,g)&&(n.flags|=32),n.memoizedState!==null&&(l=Ef(t,n,sS,null,null,i),zr._currentValue=l),_r(t,n),vn(t,n,s,i),n.child;case 6:return t===null&&ge&&((t=i=Ke)&&(i=fM(i,n.pendingProps,_i),i!==null?(n.stateNode=i,Sn=n,Ke=null,t=!0):t=!1),t||Na(n)),null;case 13:return e0(t,n,i);case 4:return U(n,n.stateNode.containerInfo),s=n.pendingProps,t===null?n.child=Rs(n,null,s,i):vn(t,n,s,i),n.child;case 11:return qg(t,n,n.type,n.pendingProps,i);case 7:return s=n.pendingProps,_r(t,n),vn(t,n,s,i),n.child;case 8:return vn(t,n,n.pendingProps.children,i),n.child;case 12:return vn(t,n,n.pendingProps.children,i),n.child;case 10:return a0(t,n,i);case 9:return l=n.type._context,s=n.pendingProps.children,Ms(n),l=An(l),s=s(l),n.flags|=1,vn(t,n,s,i),n.child;case 14:return Yg(t,n,n.type,n.pendingProps,i);case 15:return Wg(t,n,n.type,n.pendingProps,i);case 19:return Wf(t,n,i);case 31:return pS(t,n,i);case 22:return Zg(t,n,i,n.pendingProps);case 24:return Ms(n),s=An(fn),t===null?(l=hf(),l===null&&(l=Ye,u=uf(),l.pooledCache=u,u.refCount++,u!==null&&(l.pooledCacheLanes|=i),l=u),n.memoizedState={parent:s,cache:l},pf(n),Ua(n,fn,l)):((t.lanes&i)!==0&&(mf(t,n),No(n,null,null,i),Do()),l=t.memoizedState,u=n.memoizedState,l.parent!==s?(l={parent:s,cache:s},n.memoizedState=l,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=l),Ua(n,fn,s)):(s=u.cache,Ua(n,fn,s),s!==l.cache&&cf(n,[fn],i,!0))),vn(t,n,n.pendingProps.children,i),n.child;case 30:return n.stateNode===null&&(n.stateNode={autoName:null,paired:null,clones:null,ref:null}),s=n.pendingProps,s.name!=null&&s.name!=="auto"?n.flags|=t===null?18882560:18874368:ge&&Fl(n),t!==null&&t.memoizedProps.name!==s.name?n.flags|=4194816:_r(t,n),vn(t,n,s.children,i),n.child;case 29:throw n.pendingProps}throw Error(r(156,n.tag))}function da(t){t.flags|=4}function Kf(t,n,i,s,l){var u;if((u=(t.mode&32)!==0)&&(u=i===null?O_(n,s):O_(n,s)&&(s.src!==i.src||s.srcSet!==i.srcSet)),u){if(t.flags|=16777216,(l&335544128)===l)if(t.stateNode.complete)t.flags|=8192;else if(H0())t.flags|=8192;else throw As=ql,df}else t.flags&=-16777217}function r0(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!z_(n))if(H0())t.flags|=8192;else throw As=ql,df}function fc(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?El():536870912,t.lanes|=n,Mr|=n)}function Io(t,n){if(!ge)switch(t.tailMode){case"visible":break;case"collapsed":for(var i=t.tail,s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:s.sibling=null;break;default:for(n=t.tail,i=null;n!==null;)n.alternate!==null&&(i=n),n=n.sibling;i===null?t.tail=null:i.sibling=null}}function Qe(t){var n=t.alternate!==null&&t.alternate.child===t.child,i=0,s=0;if(n)for(var l=t.child;l!==null;)i|=l.lanes|l.childLanes,s|=l.subtreeFlags&1206910976,s|=l.flags&1206910976,l.return=t,l=l.sibling;else for(l=t.child;l!==null;)i|=l.lanes|l.childLanes,s|=l.subtreeFlags,s|=l.flags,l.return=t,l=l.sibling;return t.subtreeFlags|=s,t.childLanes=i,n}function _S(t,n,i){var s=n.pendingProps;switch(sf(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Qe(n),null;case 1:return Qe(n),null;case 3:return i=n.stateNode,s=null,t!==null&&(s=t.memoizedState.cache),n.memoizedState.cache!==s&&(n.flags|=2048),ca(fn),T(),i.pendingContext&&(i.context=i.pendingContext,i.pendingContext=null),(t===null||t.child===null)&&(ur(n)?da(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,of())),Qe(n),null;case 26:var l=n.type,u=n.memoizedState;return t===null?(da(n),u!==null?(Qe(n),r0(n,u)):(Qe(n),Kf(n,l,null,s,i))):u?u!==t.memoizedState?(da(n),Qe(n),r0(n,u)):(Qe(n),n.flags&=-16777217):(t=t.memoizedProps,t!==s&&da(n),Qe(n),Kf(n,l,t,s,i)),null;case 27:if(pt(n),i=qe.current,l=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==s&&da(n);else{if(!s){if(n.stateNode===null)throw Error(r(166));return Qe(n),n.subtreeFlags&=-33554433,null}t=Ft.current,ur(n)?Bm(n):(t=A_(l,s,i),n.stateNode=t,da(n))}return Qe(n),n.subtreeFlags&=-33554433,null;case 5:if(pt(n),l=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==s&&da(n);else{if(!s){if(n.stateNode===null)throw Error(r(166));return Qe(n),n.subtreeFlags&=-33554433,null}if(u=Ft.current,ur(n))Bm(n);else{var g=Wo(qe.current);switch(u){case 1:u=g.createElementNS("http://www.w3.org/2000/svg",l);break;case 2:u=g.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;default:switch(l){case"svg":u=g.createElementNS("http://www.w3.org/2000/svg",l);break;case"math":u=g.createElementNS("http://www.w3.org/1998/Math/MathML",l);break;case"script":u=g.createElement("div"),u.innerHTML="<script><\/script>",u=u.removeChild(u.firstChild);break;case"select":u=typeof s.is=="string"?g.createElement("select",{is:s.is}):g.createElement("select"),s.multiple?u.multiple=!0:s.size&&(u.size=s.size);break;default:u=typeof s.is=="string"?g.createElement(l,{is:s.is}):g.createElement(l)}}u[wt]=n,u[Xt]=s;t:for(g=n.child;g!==null;){if(g.tag===5||g.tag===6)u.appendChild(g.stateNode);else if(g.tag!==4&&g.tag!==27&&g.child!==null){g.child.return=g,g=g.child;continue}if(g===n)break t;for(;g.sibling===null;){if(g.return===null||g.return===n)break t;g=g.return}g.sibling.return=g.return,g=g.sibling}n.stateNode=u;t:switch(Dn(u,l,s),l){case"button":case"input":case"select":case"textarea":s=!!s.autoFocus;break t;case"img":s=!0;break t;default:s=!1}s&&da(n)}}return Qe(n),n.subtreeFlags&=-33554433,Kf(n,n.type,t===null?null:t.memoizedProps,n.pendingProps,i),null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==s&&da(n);else{if(typeof s!="string"&&n.stateNode===null)throw Error(r(166));if(t=qe.current,ur(n)){if(t=n.stateNode,i=n.memoizedProps,s=null,l=Sn,l!==null)switch(l.tag){case 27:case 5:s=l.memoizedProps}t[wt]=n,t=!!(t.nodeValue===i||s!==null&&s.suppressHydrationWarning===!0||s_(t.nodeValue,i)),t||Na(n,!0)}else t=Wo(t).createTextNode(s),t[wt]=n,n.stateNode=t}return Qe(n),null;case 31:if(i=n.memoizedState,t===null||t.memoizedState!==null){if(s=ur(n),i!==null){if(t===null){if(!s)throw Error(r(318));if(t=n.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(557));t[wt]=n}else xs(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Qe(n),t=!1}else i=of(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=i),t=!0;if(!t)return n.flags&256?(ei(n),n):(ei(n),null);if((n.flags&128)!==0)throw Error(r(558))}return Qe(n),null;case 13:if(s=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(l=ur(n),s!==null&&s.dehydrated!==null){if(t===null){if(!l)throw Error(r(318));if(l=n.memoizedState,l=l!==null?l.dehydrated:null,!l)throw Error(r(317));l[wt]=n}else xs(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Qe(n),l=!1}else l=of(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=l),l=!0;if(!l)return n.flags&256?(ei(n),n):(ei(n),null)}return ei(n),(n.flags&128)!==0?(n.lanes=i,n):(i=s!==null,t=t!==null&&t.memoizedState!==null,i&&(s=n.child,l=null,s.alternate!==null&&s.alternate.memoizedState!==null&&s.alternate.memoizedState.cachePool!==null&&(l=s.alternate.memoizedState.cachePool.pool),u=null,s.memoizedState!==null&&s.memoizedState.cachePool!==null&&(u=s.memoizedState.cachePool.pool),u!==l&&(s.flags|=2048)),i!==t&&i&&(n.child.flags|=8192),fc(n,n.updateQueue),Qe(n),null);case 4:return T(),t===null&&Nh(n.stateNode.containerInfo),n.flags|=67108864,Qe(n),null;case 10:return ca(n.type),Qe(n),null;case 19:if(Sf(n),s=n.memoizedState,s===null)return Qe(n),null;if(l=(n.flags&128)!==0,u=s.rendering,u===null)if(l)Io(s,!1);else{if(ln!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(u=Kl(t),u!==null){for(n.flags|=128,Io(s,!1),t=u.updateQueue,n.updateQueue=t,fc(n,t),n.subtreeFlags=0,t=i,i=n.child;i!==null;)Lm(i,t),i=i.sibling;return Uo(n,Cn.current&1|2),ge&&oa(n,s.treeForkCount),n.child}t=t.sibling}s.tail!==null&&X()>Ec&&(n.flags|=128,l=!0,Io(s,!1),n.lanes=4194304)}else{if(!l)if(t=Kl(u),t!==null){if(n.flags|=128,l=!0,t=t.updateQueue,n.updateQueue=t,fc(n,t),Io(s,!0),s.tail===null&&s.tailMode!=="collapsed"&&s.tailMode!=="visible"&&!u.alternate&&!ge)return Qe(n),null}else 2*X()-s.renderingStartTime>Ec&&i!==536870912&&(n.flags|=128,l=!0,Io(s,!1),n.lanes=4194304);s.isBackwards?(u.sibling=n.child,n.child=u):(t=s.last,t!==null?t.sibling=u:n.child=u,s.last=u)}if(s.tail!==null){t=s.tail;t:{for(i=t;i!==null;){if(i.alternate!==null){i=!1;break t}i=i.sibling}i=!0}return s.rendering=t,s.tail=t.sibling,s.renderingStartTime=X(),t.sibling=null,u=Cn.current,u=l?u&1|2:u&1,s.tailMode==="visible"||s.tailMode==="collapsed"||!i||ge?Uo(n,u):(i=u,ie(Rn,n),ie(Cn,i),On===null&&(On=n)),ge&&oa(n,s.treeForkCount),t}return Qe(n),null;case 22:case 23:return ei(n),xf(),s=n.memoizedState!==null,t!==null?t.memoizedState!==null!==s&&(n.flags|=8192):s&&(n.flags|=8192),s?(i&536870912)!==0&&(n.flags&128)===0&&(Qe(n),n.subtreeFlags&6&&(n.flags|=8192)):Qe(n),i=n.updateQueue,i!==null&&fc(n,i.retryQueue),i=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),s=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(s=n.memoizedState.cachePool.pool),s!==i&&(n.flags|=2048),t!==null&&Lt(Ts),null;case 24:return i=null,t!==null&&(i=t.memoizedState.cache),n.memoizedState.cache!==i&&(n.flags|=2048),ca(fn),Qe(n),null;case 25:return null;case 30:return n.flags|=33554432,Qe(n),null}throw Error(r(156,n.tag))}function vS(t,n){switch(sf(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return ca(fn),T(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return pt(n),null;case 31:if(n.memoizedState!==null){if(ei(n),n.alternate===null)throw Error(r(340));xs()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 13:if(ei(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(r(340));xs()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return Sf(n),t=n.flags,t&65536?(n.flags=t&-65537|128,t=n.memoizedState,t!==null&&(t.rendering=null,t.tail=null),n.flags|=4,n):null;case 4:return T(),null;case 10:return ca(n.type),null;case 22:case 23:return ei(n),xf(),t!==null&&Lt(Ts),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return ca(fn),null;case 25:return null;default:return null}}function o0(t,n){switch(sf(n),n.tag){case 3:ca(fn),T();break;case 26:case 27:case 5:pt(n);break;case 4:T();break;case 31:n.memoizedState!==null&&ei(n);break;case 13:ei(n);break;case 19:Sf(n);break;case 10:ca(n.type);break;case 22:case 23:ei(n),xf(),t!==null&&Lt(Ts);break;case 24:ca(fn)}}function Bo(t,n){try{var i=n.updateQueue,s=i!==null?i.lastEffect:null;if(s!==null){var l=s.next;i=l;do{if((i.tag&t)===t){s=void 0;var u=i.create,g=i.inst;s=u(),g.destroy=s}i=i.next}while(i!==l)}}catch(E){Fe(n,n.return,E)}}function Ha(t,n,i){try{var s=n.updateQueue,l=s!==null?s.lastEffect:null;if(l!==null){var u=l.next;s=u;do{if((s.tag&t)===t){var g=s.inst,E=g.destroy;if(E!==void 0){g.destroy=void 0,l=n;var O=i,Y=E;try{Y()}catch(at){Fe(l,O,at)}}}s=s.next}while(s!==u)}}catch(at){Fe(n,n.return,at)}}function l0(t){var n=t.updateQueue;if(n!==null){var i=t.stateNode;try{Qm(n,i)}catch(s){Fe(t,t.return,s)}}}function c0(t,n,i){i.props=ws(t.type,t.memoizedProps),i.state=t.memoizedState;try{i.componentWillUnmount()}catch(s){Fe(t,n,s)}}function Gi(t,n){try{var i=t.ref;if(i!==null){switch(t.tag){case 26:case 27:case 5:var s=t.stateNode;break;case 30:var l=t.stateNode,u=aa(t.memoizedProps,l);(l.ref===null||l.ref.name!==u)&&(l.ref=g_(u)),s=l.ref;break;case 7:if(t.stateNode===null){var g=new ri(t);p(t.child,!1,lM,g,void 0,void 0),t.stateNode=g}s=t.stateNode;break;default:s=t.stateNode}typeof i=="function"?t.refCleanup=i(s):i.current=s}}catch(E){Fe(t,n,E)}}function wn(t,n){var i=t.ref,s=t.refCleanup;if(i!==null)if(typeof s=="function")try{s()}catch(l){Fe(t,n,l)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof i=="function")try{i(null)}catch(l){Fe(t,n,l)}else i.current=null}function hc(t,n){if((t.tag===5||t.tag===27||t.tag===6)&&t.alternate===null&&n!==null)for(var i=0;i<n.length;i++)M_(t.stateNode,n[i])}function u0(t){for(var n=t.return;n!==null&&(Jf(n)&&M_(t.stateNode,n.stateNode),!Qf(n));)n=n.return}function Fo(t){for(var n=t.return;n!==null&&(Jf(n)&&cM(t.stateNode,n.stateNode),!Qf(n));)n=n.return}function Qf(t){return t.tag===5||t.tag===3||t.tag===27}function Jf(t){return t&&t.tag===7&&t.stateNode!==null}function $f(t){var n=t.type,i=t.memoizedProps,s=t.stateNode;try{t:switch(n){case"button":case"input":case"select":case"textarea":i.autoFocus&&s.focus();break t;case"img":i.src?s.src=i.src:i.srcSet&&(s.srcset=i.srcSet)}}catch(l){Fe(t,t.return,l)}}function th(t,n,i){try{var s=t.stateNode;XS(s,t.type,i,n),s[Xt]=n}catch(l){Fe(t,t.return,l)}}function f0(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&Ya(t.type)||t.tag===4}function eh(t){t:for(;;){for(;t.sibling===null;){if(t.return===null||f0(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&Ya(t.type)||t.flags&2||t.child===null||t.tag===4)continue t;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function nh(t,n,i,s){var l=t.tag;if(l===5||l===6)l=t.stateNode,n?(i.nodeType===9?i.body:i.nodeName==="HTML"?i.ownerDocument.body:i).insertBefore(l,n):(n=i.nodeType===9?i.body:i.nodeName==="HTML"?i.ownerDocument.body:i,n.appendChild(l),i=i._reactRootContainer,i!=null||n.onclick!==null||(n.onclick=Bi)),hc(t,s),De=!0;else if(l!==4&&(l===27&&(hc(t,s),s=null,Ya(t.type)&&(i=t.stateNode,n=null)),t=t.child,t!==null))for(nh(t,n,i,s),t=t.sibling;t!==null;)nh(t,n,i,s),t=t.sibling}function dc(t,n,i,s){var l=t.tag;if(l===5||l===6)l=t.stateNode,n?i.insertBefore(l,n):i.appendChild(l),hc(t,s),De=!0;else if(l!==4&&(l===27&&(hc(t,s),s=null,Ya(t.type)&&(i=t.stateNode)),t=t.child,t!==null))for(dc(t,n,i,s),t=t.sibling;t!==null;)dc(t,n,i,s),t=t.sibling}function h0(t){var n=t.stateNode,i=t.memoizedProps;try{for(var s=t.type,l=n.attributes;l.length;)n.removeAttributeNode(l[0]);Dn(n,s,i),n[wt]=t,n[Xt]=i}catch(u){Fe(t,t.return,u)}}var pc=!1,ni=null;function d0(t){(t.tag===30||(t.subtreeFlags&33554432)!==0)&&(pc=!0)}var Vi=null;function p0(){var t=Vi;return Vi=null,t}var Xn=0;function vr(t,n,i,s,l){return Xn=0,m0(t.child,n,i,s,l)}function m0(t,n,i,s,l){for(var u=!1;t!==null;){if(t.tag===5){var g=t.stateNode;if(s!==null){var E=Fh(g);s.push(E),E.view&&(u=!0)}else u||Fh(g).view&&(u=!0);pc=!0,p_(g,Xn===0?n:n+"_"+Xn,i),Xn++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&l||m0(t.child,n,i,s,l)&&(u=!0));t=t.sibling}return u}function ki(t,n){for(;t!==null;)t.tag===5?m_(t.stateNode,t.memoizedProps):(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&n||ki(t.child,n)),t=t.sibling}function mc(t){if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if((t.tag!==22||t.memoizedState===null)&&(mc(t),t.tag===30&&(t.flags&18874368)!==0&&t.stateNode.paired)){var n=t.memoizedProps;if(n.name==null||n.name==="auto")throw Error(r(544));var i=n.name;n=sa(n.default,n.share),n!=="none"&&(vr(t,i,n,null,!1)||ki(t.child,!1))}t=t.sibling}}function ih(t,n){if(t.tag===30){var i=t.stateNode,s=t.memoizedProps,l=aa(s,i),u=sa(s.default,i.paired?s.share:s.enter);u!=="none"?vr(t,l,u,null,!1)?(mc(t),i.paired||n||Ar(t,s.onEnter)):ki(t.child,!1):mc(t)}else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)ih(t,n),t=t.sibling;else mc(t)}function ah(t){if(ni!==null&&ni.size!==0){var n=ni;if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if(t.tag!==22||t.memoizedState===null){if(t.tag===30&&(t.flags&18874368)!==0){var i=t.memoizedProps,s=i.name;if(s!=null&&s!=="auto"){var l=n.get(s);if(l!==void 0){var u=sa(i.default,i.share);if(u!=="none"&&(vr(t,s,u,null,!1)?(u=t.stateNode,l.paired=u,u.paired=l,Ar(t,i.onShare)):ki(t.child,!1)),n.delete(s),n.size===0)break}}}ah(t)}t=t.sibling}}}function sh(t){if(t.tag===30){var n=t.memoizedProps,i=aa(n,t.stateNode),s=ni!==null?ni.get(i):void 0,l=sa(n.default,s!==void 0?n.share:n.exit);l!=="none"&&(vr(t,i,l,null,!1)?s!==void 0?(l=t.stateNode,s.paired=l,l.paired=s,ni.delete(i),Ar(t,n.onShare)):Ar(t,n.onExit):ki(t.child,!1)),ni!==null&&ah(t)}else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)sh(t),t=t.sibling;else ni!==null&&ah(t)}function g0(t){for(t=t.child;t!==null;){if(t.tag===30){var n=t.memoizedProps,i=aa(n,t.stateNode);n=sa(n.default,n.update),t.flags&=-5,n!=="none"&&vr(t,i,n,t.memoizedState=[],!1)}else(t.subtreeFlags&33554432)!==0&&g0(t);t=t.sibling}}function rh(t){if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if(t.tag!==22||t.memoizedState===null){if(t.tag===30&&(t.flags&18874368)!==0){var n=t.stateNode;n.paired!==null&&(n.paired=null,ki(t.child,!1))}rh(t)}t=t.sibling}}function gc(t){if(t.tag===30)t.stateNode.paired=null,ki(t.child,!1),rh(t);else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)gc(t),t=t.sibling;else rh(t)}function _0(t){for(t=t.child;t!==null;)t.tag===30?ki(t.child,!1):(t.subtreeFlags&33554432)!==0&&_0(t),t=t.sibling}function oh(t,n,i,s,l,u,g){for(var E=!1;n!==null;){if(n.tag===5){var O=n.stateNode;if(u!==null&&Xn<u.length){var Y=u[Xn],at=Fh(O);(Y.view||at.view)&&(E=!0);var mt;if(mt=(t.flags&4)===0)if(at.clip)mt=!0;else{mt=Y.rect;var j=at.rect;mt=mt.y!==j.y||mt.x!==j.x||mt.height!==j.height||mt.width!==j.width}mt&&(t.flags|=4),at.abs?at=!Y.abs:(Y=Y.rect,at=at.rect,at=Y.height!==at.height||Y.width!==at.width),at&&(t.flags|=32)}else t.flags|=32;(t.flags&4)!==0&&p_(O,Xn===0?i:i+"_"+Xn,l),E&&(t.flags&4)!==0||(Vi===null&&(Vi=[]),Vi.push(O,Xn===0?s:s+"_"+Xn,n.memoizedProps)),Xn++}else(n.tag!==22||n.memoizedState===null)&&(n.tag===30&&g?t.flags|=n.flags&32:oh(t,n.child,i,s,l,u,g)&&(E=!0));n=n.sibling}return E}function v0(t,n){for(t=t.child;t!==null;){if(t.tag===30){var i=t.memoizedProps,s=t.stateNode,l=aa(i,s),u=sa(i.default,i.update),g;g=t.memoizedState,t.memoizedState=null,s=t;var E=t.child;Xn=0,l=oh(s,E,l,l,u,g,!1),(t.flags&4)!==0&&l&&Ar(t,i.onUpdate)}else(t.subtreeFlags&33554432)!==0&&v0(t);t=t.sibling}}var Mn=!1,Ie=!1,Xi=!1,lh=!1,x0=typeof WeakSet=="function"?WeakSet:Set,En=null,ji=!1,Ho=!1,_c=!1,ch=!1;function xS(t,n,i){if(t=t.containerInfo,Oh=Pr,t=Em(t),Wu(t)){if("selectionStart"in t)var s={start:t.selectionStart,end:t.selectionEnd};else t:{s=(s=t.ownerDocument)&&s.defaultView||window;var l=s.getSelection&&s.getSelection();if(l&&l.rangeCount!==0){s=l.anchorNode;var u=l.anchorOffset,g=l.focusNode;l=l.focusOffset;try{s.nodeType,g.nodeType}catch{s=null;break t}var E=0,O=-1,Y=-1,at=0,mt=0,j=t,tt=null;e:for(;;){for(var Nt;j!==s||u!==0&&j.nodeType!==3||(O=E+u),j!==g||l!==0&&j.nodeType!==3||(Y=E+l),j.nodeType===3&&(E+=j.nodeValue.length),(Nt=j.firstChild)!==null;)tt=j,j=Nt;for(;;){if(j===t)break e;if(tt===s&&++at===u&&(O=E),tt===g&&++mt===l&&(Y=E),(Nt=j.nextSibling)!==null)break;j=tt,tt=j.parentNode}j=Nt}s=O===-1||Y===-1?null:{start:O,end:Y}}else s=null}s=s||{start:0,end:0}}else s=null;for(zh={focusedElem:t,selectionRange:s},Pr=!1,i=(i&335544064)===i,En=n,n=i?9270:1024;En!==null;){if(t=En,i&&(s=t.deletions,s!==null))for(u=0;u<s.length;u++)i&&sh(s[u]);if(t.alternate===null&&(t.flags&2)!==0)i&&d0(t),vc(i);else{if(t.tag===22){if(s=t.alternate,t.memoizedState!==null){s!==null&&s.memoizedState===null&&i&&sh(s),vc(i);continue}else if(s!==null&&s.memoizedState!==null){i&&d0(t),vc(i);continue}}s=t.child,(t.subtreeFlags&n)!==0&&s!==null?(s.return=t,En=s):(i&&g0(t),vc(i))}}ni=null}function vc(t){for(;En!==null;){var n=En,i=t,s=n.alternate,l=n.flags;switch(n.tag){case 0:case 11:case 15:break;case 1:if((l&1024)!==0&&s!==null){i=void 0,l=s.memoizedProps,s=s.memoizedState;var u=n.stateNode;try{var g=ws(n.type,l);i=u.getSnapshotBeforeUpdate(g,s),u.__reactInternalSnapshotBeforeUpdate=i}catch(E){Fe(n,n.return,E)}}break;case 3:if((l&1024)!==0){if(s=n.stateNode.containerInfo,i=s.nodeType,i===9)Vh(s);else if(i===1)switch(s.nodeName){case"HEAD":case"HTML":case"BODY":Vh(s);break;default:s.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:i&&s!==null&&(i=aa(s.memoizedProps,s.stateNode),l=n.memoizedProps,l=sa(l.default,l.update),l!=="none"&&vr(s,i,l,s.memoizedState=[],!0));break;default:if((l&1024)!==0)throw Error(r(163))}if(s=n.sibling,s!==null){s.return=n.return,En=s;break}En=n.return}}function y0(t,n,i){var s=i.flags;switch(i.tag){case 0:case 11:case 15:qi(t,i),s&4&&Bo(5,i);break;case 1:if(qi(t,i),s&4)if(t=i.stateNode,n===null)try{t.componentDidMount()}catch(g){Fe(i,i.return,g)}else{var l=ws(i.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(l,n,t.__reactInternalSnapshotBeforeUpdate)}catch(g){Fe(i,i.return,g)}}s&64&&l0(i),s&512&&Gi(i,i.return);break;case 3:if(qi(t,i),s&64&&(t=i.updateQueue,t!==null)){if(n=null,i.child!==null)switch(i.child.tag){case 27:case 5:n=i.child.stateNode;break;case 1:n=i.child.stateNode}try{Qm(t,n)}catch(g){Fe(i,i.return,g)}}break;case 27:n===null&&s&4&&h0(i);case 26:case 5:qi(t,i),n===null&&s&4&&$f(i),s&512&&Gi(i,i.return);break;case 12:qi(t,i);break;case 31:qi(t,i),s&4&&T0(t,i);break;case 13:qi(t,i),s&4&&b0(t,i),s&64&&(t=i.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(i=NS.bind(null,i),hM(t,i))));break;case 22:if(s=i.memoizedState!==null||Mn,!s){var u=n!==null&&n.memoizedState!==null||Ie;n=Mn,l=Ie,Mn=s,(Ie=u)&&!l?(s=2,(i.subtreeFlags&8772)!==0&&(s|=1),Ai(t,i,s)):qi(t,i),Mn=n,Ie=l}break;case 30:qi(t,i),s&512&&Gi(i,i.return);break;case 7:s&512&&Gi(i,i.return);default:qi(t,i)}}function uh(t,n){for(t=t.child;t!==null;)S0(t,n),t=t.sibling}function S0(t,n){switch(t.tag){case 5:case 26:try{var i=t.stateNode;if(n){var s=i.style;typeof s.setProperty=="function"?s.setProperty("display","none","important"):s.display="none"}else{var l=t.stateNode,u=t.memoizedProps.style,g=u!=null&&u.hasOwnProperty("display")?u.display:null;l.style.display=g==null||typeof g=="boolean"?"":(""+g).trim()}}catch(O){Fe(t,t.return,O)}fh(t,n);break;case 6:try{t.stateNode.nodeValue=n?"":t.memoizedProps,De=!0}catch(O){Fe(t,t.return,O)}break;case 18:try{var E=t.stateNode;n?d_(E,!0):d_(t.stateNode,!1)}catch(O){Fe(t,t.return,O)}break;case 22:case 23:t.memoizedState===null&&uh(t,n);break;default:uh(t,n)}}function fh(t,n){if(t.subtreeFlags&67108864)for(t=t.child;t!==null;){t:{var i=t,s=n;switch(i.tag){case 4:S0(i,s);break t;case 22:i.memoizedState===null&&fh(i,s);break t;default:fh(i,s)}}t=t.sibling}}function M0(t){var n=t.alternate;n!==null&&(t.alternate=null,M0(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&te(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var $e=null,jn=!1;function Ti(t,n,i){for(i=i.child;i!==null;)E0(t,n,i),i=i.sibling}function E0(t,n,i){if(en&&typeof en.onCommitFiberUnmount=="function")try{en.onCommitFiberUnmount(Se,i)}catch{}switch(i.tag){case 26:Ie||wn(i,n),Ti(t,n,i),i.memoizedState?i.memoizedState.count--:i.stateNode&&!Ie&&(i=i.stateNode,i.parentNode.removeChild(i));break;case 27:Ie||wn(i,n),Fo(i);var s=$e,l=jn;Ya(i.type)&&($e=i.stateNode,jn=!1),Ti(t,n,i),R_(i.stateNode,i.type,i.memoizedProps),$e=s,jn=l;break;case 5:Ie||wn(i,n),Fo(i);case 6:if(i.tag===6&&Fo(i),s=$e,l=jn,$e=null,Ti(t,n,i),$e=s,jn=l,$e!==null)if(jn)try{($e.nodeType===9?$e.body:$e.nodeName==="HTML"?$e.ownerDocument.body:$e).removeChild(i.stateNode),De=!0}catch(u){Fe(i,n,u)}else try{$e.removeChild(i.stateNode),De=!0}catch(u){Fe(i,n,u)}break;case 18:$e!==null&&(jn?(t=$e,h_(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,i.stateNode),Ir(t)):h_($e,i.stateNode));break;case 4:s=$e,l=jn,$e=i.stateNode.containerInfo,jn=!0,Ti(t,n,i),$e=s,jn=l;break;case 0:case 11:case 14:case 15:Ha(2,i,n),Ie||Ha(4,i,n),Ti(t,n,i);break;case 1:Ie||(wn(i,n),s=i.stateNode,typeof s.componentWillUnmount=="function"&&c0(i,n,s)),Ti(t,n,i);break;case 21:Ti(t,n,i);break;case 22:Ie=(s=Ie)||i.memoizedState!==null,Ti(t,n,i),Ie=s;break;case 30:wn(i,n),Ti(t,n,i);break;case 7:Ie||wn(i,n),Ti(t,n,i);break;default:Ti(t,n,i)}}function T0(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Ir(t)}catch(i){Fe(n,n.return,i)}}}function b0(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Ir(t)}catch(i){Fe(n,n.return,i)}}function yS(t){switch(t.tag){case 31:case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new x0),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new x0),n;default:throw Error(r(435,t.tag))}}function xc(t,n){var i=yS(t);n.forEach(function(s){if(!i.has(s)){i.add(s);var l=US.bind(null,t,s);s.then(l,l)}})}function Hn(t,n,i){var s=n.deletions;if(s!==null)for(var l=0;l<s.length;l++){var u=s[l],g=t,E=n,O=E;t:for(;O!==null;){switch(O.tag){case 27:if(Ya(O.type)){$e=O.stateNode,jn=!1;break t}break;case 5:$e=O.stateNode,jn=!1;break t;case 3:case 4:$e=O.stateNode.containerInfo,jn=!0;break t}O=O.return}if($e===null)throw Error(r(160));E0(g,E,u),$e=null,jn=!1,g=u.alternate,g!==null&&(g.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)A0(n,t,i),n=n.sibling}var bi=null;function A0(t,n,i){var s=t.alternate,l=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:if(l&4&&(s=t.updateQueue,s=s!==null?s.events:null,s!==null))for(var u=0;u<s.length;u++){var g=s[u];g.ref.impl=g.nextImpl}Hn(n,t,i),Gn(t),l&4&&(Ha(3,t,t.return),Bo(3,t),Ha(5,t,t.return));break;case 1:Hn(n,t,i),Gn(t),l&512&&(Ie||s===null||wn(s,s.return)),l&64&&Mn&&(t=t.updateQueue,t!==null&&(n=t.callbacks,n!==null&&(i=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=i===null?n:i.concat(n))));break;case 26:if(u=bi,Hn(n,t,i),Gn(t),l&512&&(Ie||s===null||wn(s,s.return)),l&4)if(l=s!==null?s.memoizedState:null,i=t.memoizedState,s===null)if(i===null)if(t.stateNode===null)if(Mn)t.stateNode=c_(t.type,t.memoizedProps,n.containerInfo,t);else{t:{n=t.type,i=t.memoizedProps,l=u.ownerDocument||u;e:switch(n){case"title":s=l.getElementsByTagName("title")[0],(!s||s[Le]||s[wt]||s.namespaceURI==="http://www.w3.org/2000/svg"||s.hasAttribute("itemprop"))&&(s=l.createElement(n),l.head.insertBefore(s,l.querySelector("head > title"))),Dn(s,n,i),s[wt]=t,we(s),n=s;break t;case"link":if(u=L_("link","href",l).get(n+(i.href||""))){for(g=0;g<u.length;g++)if(s=u[g],s.getAttribute("href")===(i.href==null||i.href===""?null:i.href)&&s.getAttribute("rel")===(i.rel==null?null:i.rel)&&s.getAttribute("title")===(i.title==null?null:i.title)&&s.getAttribute("crossorigin")===(i.crossOrigin==null?null:i.crossOrigin)){u.splice(g,1);break e}}s=l.createElement(n),Dn(s,n,i),l.head.appendChild(s);break;case"meta":if(u=L_("meta","content",l).get(n+(i.content||""))){for(g=0;g<u.length;g++)if(s=u[g],s.getAttribute("content")===(i.content==null?null:""+i.content)&&s.getAttribute("name")===(i.name==null?null:i.name)&&s.getAttribute("property")===(i.property==null?null:i.property)&&s.getAttribute("http-equiv")===(i.httpEquiv==null?null:i.httpEquiv)&&s.getAttribute("charset")===(i.charSet==null?null:i.charSet)){u.splice(g,1);break e}}s=l.createElement(n),Dn(s,n,i),l.head.appendChild(s);break;default:throw Error(r(468,n))}s[wt]=t,we(s),n=s}t.stateNode=n}else Mn||Zh(u,t.type,t.stateNode);else t.stateNode=U_(u,i,t.memoizedProps);else l!==i?(l===null?(n=s.stateNode,n===null||Ie||n.parentNode.removeChild(n)):l.count--,i===null?Mn||Zh(u,t.type,t.stateNode):U_(u,i,t.memoizedProps)):i===null&&t.stateNode!==null&&th(t,t.memoizedProps,s.memoizedProps);break;case 27:Hn(n,t,i),Gn(t),l&512&&(Ie||s===null||wn(s,s.return)),s!==null&&l&4&&th(t,t.memoizedProps,s.memoizedProps);break;case 5:if(u=Xi,Xi=!1,Hn(n,t,i),Xi=u,Gn(t),l&512&&(Ie||s===null||wn(s,s.return)),t.flags&32){n=t.stateNode;try{tr(n,""),De=!0}catch(at){Fe(t,t.return,at)}}l&4&&t.stateNode!=null&&(n=t.memoizedProps,th(t,n,s!==null?s.memoizedProps:n)),l&1024&&(lh=!0);break;case 6:if(Hn(n,t,i),Gn(t),l&4){if(t.stateNode===null)throw Error(r(162));n=t.memoizedProps,i=t.stateNode;try{i.nodeValue=n,De=!0}catch(at){Fe(t,t.return,at)}}break;case 3:if(De=!1,Oc=null,u=bi,bi=Zo(n.containerInfo),Hn(n,t,i),bi=u,Gn(t),l&4&&s!==null&&s.memoizedState.isDehydrated)try{Ir(n.containerInfo)}catch(at){Fe(t,t.return,at)}lh&&(lh=!1,R0(t)),De=!1;break;case 4:l=Xi,Xi=Mn,s=Yp(),u=bi,bi=Zo(t.stateNode.containerInfo),Hn(n,t,i),Gn(t),bi=u,De&&Ho&&(_c=!0),De=s,Xi=l;break;case 12:Hn(n,t,i),Gn(t);break;case 31:Hn(n,t,i),Gn(t),l&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,xc(t,n)));break;case 13:Hn(n,t,i),Gn(t),t.child.flags&8192&&t.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Mc=X()),l&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,xc(t,n)));break;case 22:u=t.memoizedState!==null,g=s!==null&&s.memoizedState!==null;var E=Mn,O=Ie,Y=Xi;Mn=E||u,Xi=Y||u,Ie=O||g,Hn(n,t,i),Ie=O,Xi=Y,Mn=E,Gn(t),l&8192&&(n=t.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,!u||s===null||g||Mn||Ie||(n=g||Ie,i=Mn,s=Ie,Mn=u||Mn,Ie=n,Ga(t,2),Mn=i,Ie=s),!u&&Xi||uh(t,u)),l&4&&(n=t.updateQueue,n!==null&&(i=n.retryQueue,i!==null&&(n.retryQueue=null,xc(t,i))));break;case 19:Hn(n,t,i),Gn(t),l&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,xc(t,n)));break;case 30:l&512&&(Ie||s===null||wn(s,s.return)),l=Yp(),u=Ho,g=(i&335544064)===i,E=t.memoizedProps,Ho=g&&sa(E.default,E.update)!=="none",Hn(n,t,i),Gn(t),g&&s!==null&&De&&(t.flags|=4),Ho=u,De=l;break;case 21:break;case 7:l&512&&(Ie||s===null||wn(s,s.return)),s&&s.stateNode!==null&&(s.stateNode._fragmentFiber=t);default:Hn(n,t,i),Gn(t)}}function Gn(t){var n=t.flags;if(n&2){try{for(var i,s=t.return;s!==null;){if(f0(s)){i=s;break}s=s.return}s=null;for(var l=t.return;l!==null;){if(Jf(l)){var u=l.stateNode;s===null?s=[u]:s.push(u)}if(Qf(l))break;l=l.return}var g=s;if(i==null)throw Error(r(160));switch(i.tag){case 27:var E=i.stateNode,O=eh(t);dc(t,O,E,g);break;case 5:var Y=i.stateNode;i.flags&32&&(tr(Y,""),i.flags&=-33);var at=eh(t);dc(t,at,Y,g);break;case 3:case 4:var mt=i.stateNode.containerInfo,j=eh(t);nh(t,j,mt,g);break;default:throw Error(r(161))}}catch(tt){Fe(t,t.return,tt)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function R0(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;R0(n),n.tag===5&&n.flags&1024&&(n=n.stateNode,Pr=!0,n.reset(),Pr=!1),t=t.sibling}}function xr(t,n){if(n.subtreeFlags&9270)for(n=n.child;n!==null;)C0(n,t),n=n.sibling;else v0(n)}function C0(t,n){var i=t.alternate;if(i===null)ih(t,!1);else switch(t.tag){case 3:if(ch=ji=!1,p0(),xr(n,t),!ji&&!_c){if(t=Vi,t!==null)for(var s=0;s<t.length;s+=3){i=t[s];var l=t[s+1];m_(i,t[s+2]),i=i.ownerDocument.documentElement,i!==null&&i.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+l+")"})}t=n.containerInfo,t=t.nodeType===9?t.documentElement:t.ownerDocument.documentElement,t!==null&&t.style.viewTransitionName===""&&(t.style.viewTransitionName="none",t.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),t.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),ch=!0}Vi=null;break;case 5:xr(n,t);break;case 4:s=ji,ji=!1,xr(n,t),ji&&(_c=!0),ji=s;break;case 22:t.memoizedState===null&&(i.memoizedState!==null?ih(t,!1):xr(n,t));break;case 30:s=ji,l=p0(),ji=!1,xr(n,t),ji&&(t.flags|=4);var u=t.memoizedProps,g=t.stateNode;n=aa(u,g),g=aa(i.memoizedProps,g);var E=sa(u.default,u.update);E==="none"?n=!1:(u=i.memoizedState,i.memoizedState=null,i=t.child,Xn=0,n=oh(t,i,n,g,E,u,!0),Xn!==(u===null?0:u.length)&&(t.flags|=32)),(t.flags&4)!==0&&n?(Ar(t,t.memoizedProps.onUpdate),Vi=l):l!==null&&(l.push.apply(l,Vi),Vi=l),ji=(t.flags&32)!==0?!0:s;break;default:xr(n,t)}}function qi(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)y0(t,n.alternate,n),n=n.sibling}function Ga(t,n){for(t=t.child;t!==null;){var i=t,s=n;switch(i.tag){case 0:case 11:case 14:case 15:Ha(4,i,i.return),Ga(i,s);break;case 1:wn(i,i.return);var l=i.stateNode;typeof l.componentWillUnmount=="function"&&c0(i,i.return,l),Ga(i,s);break;case 27:(s&2)!==0&&R_(i.stateNode,i.type,i.memoizedProps);case 5:wn(i,i.return),i.tag!==5&&i.tag!==27||Fo(i),Ga(i,s);break;case 6:Fo(i);break;case 26:wn(i,i.return),l=i.stateNode,i.memoizedState!==null||l===null||Ie||l.parentNode.removeChild(l),Ga(i,s);break;case 22:i.memoizedState===null&&Ga(i,s);break;case 30:wn(i,i.return),Ga(i,s);break;case 7:wn(i,i.return);default:Ga(i,s)}t=t.sibling}}function Ai(t,n,i){for(i=(n.subtreeFlags&8772)!==0?i:i&-2,n=n.child;n!==null;){var s=n.alternate,l=t,u=n,g=u.flags,E=(i&1)!==0;switch(u.tag){case 0:case 11:case 15:Ai(l,u,i),Bo(4,u);break;case 1:if(Ai(l,u,i),s=u,l=s.stateNode,typeof l.componentDidMount=="function")try{l.componentDidMount()}catch(at){Fe(s,s.return,at)}if(s=u,l=s.updateQueue,l!==null){var O=s.stateNode;try{var Y=l.shared.hiddenCallbacks;if(Y!==null)for(l.shared.hiddenCallbacks=null,l=0;l<Y.length;l++)Km(Y[l],O)}catch(at){Fe(s,s.return,at)}}E&&g&64&&l0(u),Gi(u,u.return);break;case 27:(i&2)!==0&&h0(u);case 5:u.tag!==5&&u.tag!==27||u0(u),Ai(l,u,i),E&&s===null&&g&4&&$f(u),Gi(u,u.return);break;case 6:u0(u);break;case 26:O=u.stateNode,u.memoizedState!==null||O===null||Mn||Zh(Zo(O.ownerDocument),u.type,O),Ai(l,u,i),E&&s===null&&g&4&&$f(u),Gi(u,u.return);break;case 12:Ai(l,u,i);break;case 31:Ai(l,u,i),E&&g&4&&T0(l,u);break;case 13:Ai(l,u,i),E&&g&4&&b0(l,u);break;case 22:u.memoizedState===null&&Ai(l,u,i),Gi(u,u.return);break;case 30:Ai(l,u,i),Gi(u,u.return);break;case 7:Gi(u,u.return);default:Ai(l,u,i)}n=n.sibling}}function hh(t,n){var i=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(i=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==i&&(t!=null&&t.refCount++,i!=null&&bo(i))}function dh(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&bo(t))}function vi(t,n,i,s){var l=(i&335544064)===i;if(n.subtreeFlags&(l?10262:10256))for(n=n.child;n!==null;)w0(t,n,i,s),n=n.sibling;else l&&_0(n)}function w0(t,n,i,s){var l=(i&335544064)===i;l&&n.alternate===null&&n.return!==null&&n.return.alternate!==null&&gc(n);var u=n.flags;switch(n.tag){case 0:case 11:case 15:vi(t,n,i,s),u&2048&&Bo(9,n);break;case 1:vi(t,n,i,s);break;case 3:vi(t,n,i,s),l&&ch&&(t=t.containerInfo,t=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,t.style.viewTransitionName==="root"&&(t.style.viewTransitionName=""),t=t.ownerDocument.documentElement,t!==null&&t.style.viewTransitionName==="none"&&(t.style.viewTransitionName="")),u&2048&&(u=null,n.alternate!==null&&(u=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==u&&(n.refCount++,u!=null&&bo(u)));break;case 12:if(u&2048){vi(t,n,i,s),u=n.stateNode;try{var g=n.memoizedProps,E=g.id,O=g.onPostCommit;typeof O=="function"&&O(E,n.alternate===null?"mount":"update",u.passiveEffectDuration,-0)}catch(Y){Fe(n,n.return,Y)}}else vi(t,n,i,s);break;case 31:vi(t,n,i,s);break;case 13:vi(t,n,i,s);break;case 23:break;case 22:g=n.stateNode,E=n.alternate,n.memoizedState!==null?(l&&E!==null&&E.memoizedState===null&&gc(E),g._visibility&2?vi(t,n,i,s):Go(t,n)):(l&&E!==null&&E.memoizedState!==null&&gc(n),g._visibility&2?vi(t,n,i,s):(g._visibility|=2,yr(t,n,i,s,(n.subtreeFlags&10256)!==0||!1))),u&2048&&hh(E,n);break;case 24:vi(t,n,i,s),u&2048&&dh(n.alternate,n);break;case 30:l&&(u=n.alternate,u!==null&&(ki(u.child,!0),ki(n.child,!0))),vi(t,n,i,s);break;default:vi(t,n,i,s)}}function yr(t,n,i,s,l){for(l=l&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var u=t,g=n,E=i,O=s,Y=g.flags;switch(g.tag){case 0:case 11:case 15:yr(u,g,E,O,l),Bo(8,g);break;case 23:break;case 22:var at=g.stateNode;g.memoizedState!==null?at._visibility&2?yr(u,g,E,O,l):Go(u,g):(at._visibility|=2,yr(u,g,E,O,l)),l&&Y&2048&&hh(g.alternate,g);break;case 24:yr(u,g,E,O,l),l&&Y&2048&&dh(g.alternate,g);break;default:yr(u,g,E,O,l)}n=n.sibling}}function Go(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var i=t,s=n,l=s.flags;switch(s.tag){case 22:Go(i,s),l&2048&&hh(s.alternate,s);break;case 24:Go(i,s),l&2048&&dh(s.alternate,s);break;default:Go(i,s)}n=n.sibling}}var Ds=8192;function Ns(t,n,i){if(t.subtreeFlags&Ds)for(t=t.child;t!==null;)D0(t,n,i),t=t.sibling}function D0(t,n,i){switch(t.tag){case 26:Ns(t,n,i),t.flags&Ds&&(t.memoizedState!==null?AM(i,bi,t.memoizedState,t.memoizedProps):(t=t.stateNode,(n&335544128)===n&&I_(i,t)));break;case 5:Ns(t,n,i),t.flags&Ds&&(t=t.stateNode,(n&335544128)===n&&I_(i,t));break;case 3:case 4:var s=bi;bi=Zo(t.stateNode.containerInfo),Ns(t,n,i),bi=s;break;case 22:t.memoizedState===null&&(s=t.alternate,s!==null&&s.memoizedState!==null?(s=Ds,Ds=16777216,Ns(t,n,i),Ds=s):Ns(t,n,i));break;case 30:if((t.flags&Ds)!==0&&(s=t.memoizedProps.name,s!=null&&s!=="auto")){var l=t.stateNode;l.paired=null,ni===null&&(ni=new Map),ni.set(s,l)}Ns(t,n,i);break;default:Ns(t,n,i)}}function N0(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function Vo(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var i=0;i<n.length;i++){var s=n[i];En=s,L0(s,t)}N0(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)U0(t),t=t.sibling}function U0(t){switch(t.tag){case 0:case 11:case 15:Vo(t),t.flags&2048&&Ha(9,t,t.return);break;case 3:Vo(t);break;case 12:Vo(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,yc(t)):Vo(t);break;default:Vo(t)}}function yc(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var i=0;i<n.length;i++){var s=n[i];En=s,L0(s,t)}N0(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:Ha(8,n,n.return),yc(n);break;case 22:i=n.stateNode,i._visibility&2&&(i._visibility&=-3,yc(n));break;default:yc(n)}t=t.sibling}}function L0(t,n){for(;En!==null;){var i=En;switch(i.tag){case 0:case 11:case 15:Ha(8,i,n);break;case 23:case 22:if(i.memoizedState!==null&&i.memoizedState.cachePool!==null){var s=i.memoizedState.cachePool.pool;s!=null&&s.refCount++}break;case 24:bo(i.memoizedState.cache)}if(s=i.child,s!==null)s.return=i,En=s;else t:for(i=t;En!==null;){s=En;var l=s.sibling,u=s.return;if(M0(s),s===i){En=null;break t}if(l!==null){l.return=u,En=l;break t}En=u}}}var SS={getCacheForType:function(t){var n=An(fn),i=n.data.get(t);return i===void 0&&(i=t(),n.data.set(t,i)),i},cacheSignal:function(){return An(fn).controller.signal}},MS=typeof WeakMap=="function"?WeakMap:Map,ze=0,Ye=null,xe=null,Me=0,Be=0,ii=null,Va=!1,Sr=!1,ph=!1,pa=0,ln=0,ka=0,Us=0,Sc=0,ai=0,Mr=0,ko=null,qn=null,mh=!1,Mc=0,O0=0,Ec=1/0,Tc=null,Xa=null,nn=0,Ri=null,Ls=null,Yi=0,gh=0,_h=null,z0=null,Er=null,Tr=null,br=null,Xo=0,bc=null;function si(){return(ze&2)!==0&&Me!==0?Me&-Me:Et.T!==null?Rh():Tt()}function P0(){if(ai===0)if((Me&536870912)===0||ge){var t=ea;ea<<=1,(ea&3932160)===0&&(ea=262144),ai=t}else ai=536870912;return t=Rn.current,t!==null&&(t.flags|=32),ai}function Ar(t,n){if(n!=null){var i=t.stateNode,s=i.ref;s===null&&(s=i.ref=g_(aa(t.memoizedProps,i))),Tr===null&&(Tr=[]),Tr.push(n.bind(null,s))}}function Yn(t,n,i){(t===Ye&&(Be===2||Be===9)||t.cancelPendingCommit!==null)&&(Rr(t,0),ja(t,Me,ai,!1)),ps(t,i),((ze&2)===0||t!==Ye)&&(t===Ye&&((ze&2)===0&&(Us|=i),ln===4&&ja(t,Me,ai,!1)),Wi(t))}function I0(t,n,i){if((ze&6)!==0)throw Error(r(327));var s=!i&&(n&127)===0&&(n&t.expiredLanes)===0||ba(t,n),l=s?bS(t,n):xh(t,n,!0),u=s;do{if(l===0){Sr&&!s&&ja(t,n,0,!1);break}else{if(i=t.current.alternate,u&&!ES(i)){l=xh(t,n,!1),u=!1;continue}if(l===2){if(u=n,t.errorRecoveryDisabledLanes&u)var g=0;else g=t.pendingLanes&-536870913,g=g!==0?g:g&536870912?536870912:0;if(g!==0){n=g;t:{var E=t;l=ko;var O=E.current.memoizedState.isDehydrated;if(O&&(Rr(E,g).flags|=256),g=xh(E,g,!1),g!==2&&g!==6){if(ph&&!O){E.errorRecoveryDisabledLanes|=u,Us|=u,l=4;break t}u=qn,qn=l,u!==null&&(qn===null?qn=u:qn.push.apply(qn,u))}l=g}if(u=!1,l!==2)continue}}if(l===1){Rr(t,0),ja(t,n,0,!0);break}t:{switch(s=t,u=l,u){case 0:case 1:throw Error(r(345));case 4:if((n&4194048)!==n&&(n&62914560)!==n)break;case 6:ja(s,n,ai,!Va);break t;case 2:qn=null;break;case 3:case 5:break;default:throw Error(r(329))}if((n&62914560)===n&&(l=Mc+300-X(),10<l)){if(ja(s,n,ai,!Va),ds(s,0,!0)!==0)break t;Yi=n,s.timeoutHandle=Bh(B0.bind(null,s,i,qn,Tc,mh,n,ai,Us,Mr,Va,u,"Throttled",-0,0),l);break t}B0(s,i,qn,Tc,mh,n,ai,Us,Mr,Va,u,null,-0,0)}}break}while(!0);Wi(t)}function B0(t,n,i,s,l,u,g,E,O,Y,at,mt,j,tt){t.timeoutHandle=-1;var Nt=n.subtreeFlags,jt=(u&335544064)===u;if(mt=null,(jt||Nt&8192||(Nt&16785408)===16785408)&&(mt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Bi},ni=null,D0(n,u,mt),jt&&(Nt=mt,jt=t.containerInfo,jt=(jt.nodeType===9?jt:jt.ownerDocument).__reactViewTransition,jt!=null&&(Nt.count++,Nt.waitingForViewTransition=!0,Nt=Jo.bind(Nt),jt.finished.then(Nt,Nt))),Nt=(u&62914560)===u?Mc-X():(u&4194048)===u?O0-X():0,Nt=RM(mt,Nt),Nt!==null)){Yi=u,t.cancelPendingCommit=Nt(q0.bind(null,t,n,u,i,s,l,g,E,O,Y,at,mt,null,j,tt)),ja(t,u,g,!Y);return}q0(t,n,u,i,s,l,g,E,O,Y,at,mt)}function ES(t){for(var n=t;;){var i=n.tag;if((i===0||i===11||i===15)&&n.flags&16384&&(i=n.updateQueue,i!==null&&(i=i.stores,i!==null)))for(var s=0;s<i.length;s++){var l=i[s],u=l.getSnapshot;l=l.value;try{if(!ti(u(),l))return!1}catch{return!1}}if(i=n.child,n.subtreeFlags&16384&&i!==null)i.return=n,n=i;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function ja(t,n,i,s){n=Ml(t,n),n&=~Sc,n&=~Us,t.suspendedLanes|=n,t.pingedLanes&=~n,s&&(t.warmLanes|=n),s=t.expirationTimes;for(var l=n;0<l;){var u=31-Un(l),g=1<<u;s[u]=-1,l&=~g}i!==0&&A(t,i,n)}function Ac(){return(ze&6)===0?(jo(0),!1):!0}function vh(){if(xe!==null){if(Be===0)var t=xe.return;else t=xe,la=ys=null,Af(t),dr=null,Co=0,t=xe;for(;t!==null;)o0(t.alternate,t),t=t.return;xe=null}}function Rr(t,n){var i=t.timeoutHandle;return i!==-1&&(t.timeoutHandle=-1,YS(i)),i=t.cancelPendingCommit,i!==null&&(t.cancelPendingCommit=null,i()),Yi=0,vh(),Ye=t,xe=i=ra(t.current,null),Me=n,Be=0,ii=null,Va=!1,Sr=ba(t,n),ph=!1,Mr=ai=Sc=Us=ka=ln=0,qn=ko=null,mh=!1,pa=Ml(t,n),Ol(),i}function F0(t,n){fe=null,Et.H=sc,n===hr||n===jl?(n=qm(),Be=3):n===df?(n=qm(),Be=4):Be=n===Gf?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,ii=n,xe===null&&(ln=1,rc(t,pi(n,t.current)))}function H0(){var t=Rn.current;return t===null?!0:(Me&4194048)===Me?On===null:(Me&62914560)===Me||(Me&536870912)!==0?t===On:!1}function G0(){var t=Et.H;return Et.H=sc,t===null?sc:t}function V0(){var t=Et.A;return Et.A=SS,t}function Rc(){ln=4,Va||(Me&4194048)!==Me&&Rn.current!==null||(Sr=!0),(ka&134217727)===0&&(Us&134217727)===0||Ye===null||ja(Ye,Me,ai,!1)}function xh(t,n,i){var s=ze;ze|=2;var l=G0(),u=V0();(Ye!==t||Me!==n)&&(Tc=null,Rr(t,n)),n=!1;var g=ln;t:do try{if(Be!==0&&xe!==null){var E=xe,O=ii;switch(Be){case 8:vh(),g=6;break t;case 3:case 2:case 9:case 6:Rn.current===null&&(n=!0);var Y=Be;if(Be=0,ii=null,Cr(t,E,O,Y),i&&Sr){g=0;break t}break;default:Y=Be,Be=0,ii=null,Cr(t,E,O,Y)}}TS(),g=ln;break}catch(at){F0(t,at)}while(!0);return n&&t.shellSuspendCounter++,la=ys=null,ze=s,Et.H=l,Et.A=u,xe===null&&(Ye=null,Me=0,Ol()),g}function TS(){for(;xe!==null;)k0(xe)}function bS(t,n){var i=ze;ze|=2;var s=G0(),l=V0();Ye!==t||Me!==n?(Tc=null,Ec=X()+500,Rr(t,n)):Sr=ba(t,n);t:do try{if(Be!==0&&xe!==null){n=xe;var u=ii;e:switch(Be){case 1:Be=0,ii=null,Cr(t,n,u,1);break;case 2:case 9:if(Xm(u)){Be=0,ii=null,X0(n);break}n=function(){Be!==2&&Be!==9||Ye!==t||(Be=7),Wi(t)},u.then(n,n);break t;case 3:Be=7;break t;case 4:Be=5;break t;case 7:Xm(u)?(Be=0,ii=null,X0(n)):(Be=0,ii=null,Cr(t,n,u,7));break;case 5:var g=null;switch(xe.tag){case 26:g=xe.memoizedState;case 5:case 27:var E=xe;if(g?z_(g):E.stateNode.complete){Be=0,ii=null;var O=E.sibling;if(O!==null)xe=O;else{var Y=E.return;Y!==null?(xe=Y,Cc(Y)):xe=null}break e}}Be=0,ii=null,Cr(t,n,u,5);break;case 6:Be=0,ii=null,Cr(t,n,u,6);break;case 8:vh(),ln=6;break t;default:throw Error(r(462))}}AS();break}catch(at){F0(t,at)}while(!0);return la=ys=null,Et.H=s,Et.A=l,ze=i,xe!==null?0:(Ye=null,Me=0,Ol(),ln)}function AS(){for(;xe!==null&&!zt();)k0(xe)}function k0(t){var n=s0(t.alternate,t,pa);t.memoizedProps=t.pendingProps,n===null?Cc(t):xe=n}function X0(t){var n=t,i=n.alternate;switch(n.tag){case 15:case 0:n=Jg(i,n,n.pendingProps,n.type,void 0,Me);break;case 11:n=Jg(i,n,n.pendingProps,n.type.render,n.ref,Me);break;case 5:Af(n);var s=n;s===Sn&&(ge?(Hl(s),s.tag===5&&s.stateNode!=null&&(Ke=s.stateNode)):(Hl(s),ge=!0));default:o0(i,n),n=xe=Lm(n,pa),n=s0(i,n,pa)}t.memoizedProps=t.pendingProps,n===null?Cc(t):xe=n}function Cr(t,n,i,s){la=ys=null,Af(n),dr=null,Co=0;var l=n.return;try{if(dS(t,l,n,i,Me)){ln=1,rc(t,pi(i,t.current)),xe=null;return}}catch(u){if(l!==null)throw xe=l,u;ln=1,rc(t,pi(i,t.current)),xe=null;return}n.flags&32768?(ge||s===1?t=!0:Sr||(Me&536870912)!==0?t=!1:(Va=t=!0,(s===2||s===9||s===3||s===6)&&(s=Rn.current,s!==null&&s.tag===13&&(s.flags|=16384))),j0(n,t)):Cc(n)}function Cc(t){var n=t;do{if((n.flags&32768)!==0){j0(n,Va);return}t=n.return;var i=_S(n.alternate,n,pa);if(i!==null){xe=i;return}if(n=n.sibling,n!==null){xe=n;return}xe=n=t}while(n!==null);ln===0&&(ln=5)}function j0(t,n){do{var i=vS(t.alternate,t);if(i!==null){i.flags&=32767,xe=i;return}if(i=t.return,i!==null&&(i.flags|=32768,i.subtreeFlags=0,i.deletions=null),!n&&(t=t.sibling,t!==null)){xe=t;return}xe=t=i}while(t!==null);ln=6,xe=null}function q0(t,n,i,s,l,u,g,E,O,Y,at,mt){t.cancelPendingCommit=null;do wc();while(nn!==0);if((ze&6)!==0)throw Error(r(327));if(n!==null){if(n===t.current)throw Error(r(177));t===Ye&&(xe=Ye=null,Me=0),Ls=n,Ri=t,Yi=i,_h=l,z0=s,RS(t,n,i,g,E,O,mt)}}function RS(t,n,i,s,l,u,g){var E=n.lanes|n.childLanes;if(gh=E,E|=$u,Du(t,i,E,s,l,u),Tr=null,(i&335544064)===i?(br=eS(t),s=10262):(br=null,s=10256),(n.subtreeFlags&s)!==0||(n.flags&s)!==0?(t.callbackNode=null,t.callbackPriority=0,LS(St,function(){return Eh(),null})):(t.callbackNode=null,t.callbackPriority=0),pc=!1,s=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||s){s=Et.T,Et.T=null,l=qt.p,qt.p=2,u=ze,ze|=4;try{xS(t,n,i)}finally{ze=u,qt.p=l,Et.T=s}}nn=1,pc?Er=$S(g,t.containerInfo,br,yh,Sh,wS,Mh,Eh,CS):(yh(),Sh(),Mh())}function CS(t){if(nn!==0){var n=Ri.onRecoverableError;n(t,{componentStack:null})}}function wS(){nn===3&&(nn=0,C0(Ls,Ri),nn=4)}function yh(){if(nn===1){nn=0;var t=Ri,n=Ls,i=Yi,s=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||s){s=Et.T,Et.T=null;var l=qt.p;qt.p=2;var u=ze;ze|=4;try{Ho=_c=!1,A0(n,t,i),i=zh;var g=Em(t.containerInfo),E=i.focusedElem,O=i.selectionRange;if(g!==E&&E&&E.ownerDocument&&Mm(E.ownerDocument.documentElement,E)){if(O!==null&&Wu(E)){var Y=O.start,at=O.end;if(at===void 0&&(at=Y),"selectionStart"in E)E.selectionStart=Y,E.selectionEnd=Math.min(at,E.value.length);else{var mt=E.ownerDocument||document,j=mt&&mt.defaultView||window;if(j.getSelection){var tt=j.getSelection(),Nt=E.textContent.length,jt=Math.min(O.start,Nt),he=O.end===void 0?jt:Math.min(O.end,Nt);!tt.extend&&jt>he&&(g=he,he=jt,jt=g);var q=Sm(E,jt),V=Sm(E,he);if(q&&V&&(tt.rangeCount!==1||tt.anchorNode!==q.node||tt.anchorOffset!==q.offset||tt.focusNode!==V.node||tt.focusOffset!==V.offset)){var J=mt.createRange();J.setStart(q.node,q.offset),tt.removeAllRanges(),jt>he?(tt.addRange(J),tt.extend(V.node,V.offset)):(J.setEnd(V.node,V.offset),tt.addRange(J))}}}}for(mt=[],tt=E;tt=tt.parentNode;)tt.nodeType===1&&mt.push({element:tt,left:tt.scrollLeft,top:tt.scrollTop});for(typeof E.focus=="function"&&E.focus(),E=0;E<mt.length;E++){var dt=mt[E];dt.element.scrollLeft=dt.left,dt.element.scrollTop=dt.top}}Pr=!!Oh,zh=Oh=null}finally{ze=u,qt.p=l,Et.T=s}}t.current=n,nn=2}}function Sh(){if(nn===2){nn=0;var t=Ri,n=Ls,i=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||i){i=Et.T,Et.T=null;var s=qt.p;qt.p=2;var l=ze;ze|=4;try{y0(t,n.alternate,n)}finally{ze=l,qt.p=s,Et.T=i}}nn=3}}function Mh(){if(nn===4||nn===3){nn=0;var t=Er;Er=null,ue();var n=Ri,i=Ls,s=Yi,l=z0,u=(s&335544064)===s?10262:10256;if((i.subtreeFlags&u)!==0||(i.flags&u)!==0?nn=5:(nn=0,Ls=Ri=null,Y0(n,n.pendingLanes)),u=n.pendingLanes,u===0&&(Xa=null),Q(s),i=i.stateNode,en&&typeof en.onCommitFiberRoot=="function")try{en.onCommitFiberRoot(Se,i,void 0,(i.current.flags&128)===128)}catch{}if(l!==null){i=Et.T,u=qt.p,qt.p=2,Et.T=null;try{for(var g=n.onRecoverableError,E=0;E<l.length;E++){var O=l[E];g(O.value,{componentStack:O.stack})}}finally{Et.T=i,qt.p=u}}if(l=Tr,g=br,br=null,l!==null&&(Tr=null,g===null&&(g=[]),t!==null))for(O=0;O<l.length;O++)i=(0,l[O])(g),i!==void 0&&t.finished.finally(i);(Yi&3)!==0&&wc(),Wi(n),u=n.pendingLanes,(s&261930)!==0&&(u&42)!==0?n===bc?Xo++:(Xo=0,bc=n):(Xo=0,bc=null),jo(0)}}function Y0(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,bo(n)))}function wc(){return Er!==null&&(Er.skipTransition(),Er=null),yh(),Sh(),Mh(),Eh()}function Eh(){if(nn!==5)return!1;var t=Ri,n=gh;gh=0;var i=Q(Yi),s=Et.T,l=qt.p;try{qt.p=32>i?32:i,Et.T=null,i=_h,_h=null;var u=Ri,g=Yi;if(nn=0,Ls=Ri=null,Yi=0,(ze&6)!==0)throw Error(r(331));var E=ze;if(ze|=4,U0(u.current),w0(u,u.current,g,i),ze=E,jo(0,!1),en&&typeof en.onPostCommitFiberRoot=="function")try{en.onPostCommitFiberRoot(Se,u)}catch{}return!0}finally{qt.p=l,Et.T=s,Y0(t,n)}}function W0(t,n,i){n=pi(i,n),n=Hf(t.stateNode,n,2),t=Pa(t,n,2),t!==null&&(ps(t,2),Wi(t))}function Fe(t,n,i){if(t.tag===3)W0(t,t,i);else for(;n!==null;){if(n.tag===3){W0(n,t,i);break}else if(n.tag===1){var s=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof s.componentDidCatch=="function"&&(Xa===null||!Xa.has(s))){t=pi(i,t),i=Xg(2),s=Pa(n,i,2),s!==null&&(jg(i,s,n,t),ps(s,2),Wi(s));break}}n=n.return}}function Th(t,n,i){var s=t.pingCache;if(s===null){s=t.pingCache=new MS;var l=new Set;s.set(n,l)}else l=s.get(n),l===void 0&&(l=new Set,s.set(n,l));l.has(i)||(ph=!0,l.add(i),t=DS.bind(null,t,n,i),n.then(t,t))}function DS(t,n,i){var s=t.pingCache;s!==null&&s.delete(n),t.pingedLanes|=t.suspendedLanes&i,t.warmLanes&=~i,Ye===t&&(Me&i)===i&&((ln===4||ln===3&&(Me&62914560)===Me&&300>X()-Mc)&&(ze&2)===0?Rr(t,0):Sc|=i,Mr===Me&&(Mr=0)),Wi(t)}function Z0(t,n){n===0&&(n=El()),t=_s(t,n),t!==null&&(ps(t,n),Wi(t))}function NS(t){var n=t.memoizedState,i=0;n!==null&&(i=n.retryLane),Z0(t,i)}function US(t,n){var i=0;switch(t.tag){case 31:case 13:var s=t.stateNode,l=t.memoizedState;l!==null&&(i=l.retryLane);break;case 19:s=t.stateNode;break;case 22:s=t.stateNode._retryCache;break;default:throw Error(r(314))}s!==null&&s.delete(n),Z0(t,i)}function LS(t,n){return ne(t,n)}var wr=null,Dr=null,bh=!1,Dc=!1,Ah=!1,qa=0;function Wi(t){t!==Dr&&t.next===null&&(Dr===null?wr=Dr=t:Dr=Dr.next=t),Dc=!0,bh||(bh=!0,zS())}function jo(t,n){if(!Ah&&Dc){Ah=!0;do for(var i=!1,s=wr;s!==null;){if(t!==0){var l=s.pendingLanes;if(l===0)var u=0;else{var g=s.suspendedLanes,E=s.pingedLanes;u=(1<<31-Un(42|t)+1)-1,u&=l&~(g&~E),u=u&201326741?u&201326741|1:u?u|2:0}u!==0&&(i=!0,$0(s,u))}else u=Me,u=ds(s,s===Ye?u:0,s.cancelPendingCommit!==null||s.timeoutHandle!==-1),(u&3)===0||ba(s,u)||(i=!0,$0(s,u));s=s.next}while(i);Ah=!1}}function OS(){K0()}function K0(){Dc=bh=!1;var t=0;qa!==0&&qS()&&(t=qa);for(var n=X(),i=null,s=wr;s!==null;){var l=s.next,u=Q0(s,n);u===0?(s.next=null,i===null?wr=l:i.next=l,l===null&&(Dr=i)):(i=s,(t!==0||(u&3)!==0)&&(Dc=!0)),s=l}nn!==0&&nn!==5||jo(t),qa!==0&&(qa=0)}function Q0(t,n){for(var i=t.suspendedLanes,s=t.pingedLanes,l=t.expirationTimes,u=t.pendingLanes&-62914561;0<u;){var g=31-Un(u),E=1<<g,O=l[g];O===-1?((E&i)===0||(E&s)!==0)&&(l[g]=wu(E,n)):O<=n&&(t.expiredLanes|=E),u&=~E}if(n=Ye,i=Me,i=ds(t,t===n?i:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),s=t.callbackNode,i===0||t===n&&(Be===2||Be===9)||t.cancelPendingCommit!==null)return s!==null&&s!==null&&Zt(s),t.callbackNode=null,t.callbackPriority=0;if((i&3)===0||ba(t,i)){if(n=i&-i,n===t.callbackPriority)return n;switch(s!==null&&Zt(s),Q(i)){case 2:case 8:i=Vt;break;case 32:i=St;break;case 268435456:i=Yt;break;default:i=St}return s=J0.bind(null,t),i=ne(i,s),t.callbackPriority=n,t.callbackNode=i,n}return s!==null&&s!==null&&Zt(s),t.callbackPriority=2,t.callbackNode=null,2}function J0(t,n){if(nn!==0&&nn!==5)return t.callbackNode=null,t.callbackPriority=0,null;var i=t.callbackNode;if(wc()&&t.callbackNode!==i)return null;var s=Me;return s=ds(t,t===Ye?s:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),s===0?null:(I0(t,s,n),Q0(t,X()),t.callbackNode!=null&&t.callbackNode===i?J0.bind(null,t):null)}function $0(t,n){if(wc())return null;I0(t,n,!0)}function zS(){WS(function(){(ze&6)!==0?ne(Dt,OS):K0()})}function Rh(){if(qa===0){var t=Es;t===0&&(t=fs,fs<<=1,(fs&261888)===0&&(fs=256)),qa=t}return qa}function t_(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:Al(t)}function PS(t,n,i,s,l){if(n==="submit"&&i&&i.stateNode===l){var u=t_((l[Xt]||null).action),g=s.submitter;g&&(n=(n=g[Xt]||null)?t_(n.formAction):g.getAttribute("formAction"),n!==null&&(u=n,g=null));var E=new Dl("action","action",null,s,l);t.push({event:E,listeners:[{instance:null,listener:function(){if(s.defaultPrevented){if(qa!==0){var O=new FormData(l,g);zf(i,{pending:!0,data:O,method:l.method,action:u},null,O)}}else typeof u=="function"&&(E.preventDefault(),O=new FormData(l,g),zf(i,{pending:!0,data:O,method:l.method,action:u},u,O))},currentTarget:l}]})}}for(var Ch=0;Ch<Ju.length;Ch++){var wh=Ju[Ch],IS=wh.toLowerCase(),BS=wh[0].toUpperCase()+wh.slice(1);Ei(IS,"on"+BS)}Ei(Am,"onAnimationEnd"),Ei(Rm,"onAnimationIteration"),Ei(Cm,"onAnimationStart"),Ei("dblclick","onDoubleClick"),Ei("focusin","onFocus"),Ei("focusout","onBlur"),Ei(Yy,"onTransitionRun"),Ei(Wy,"onTransitionStart"),Ei(Zy,"onTransitionCancel"),Ei(wm,"onTransitionEnd"),rn("onMouseEnter",["mouseout","mouseover"]),rn("onMouseLeave",["mouseout","mouseover"]),rn("onPointerEnter",["pointerout","pointerover"]),rn("onPointerLeave",["pointerout","pointerover"]),un("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),un("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),un("onBeforeInput",["compositionend","keypress","textInput","paste"]),un("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),un("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),un("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var qo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),FS=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(qo));function e_(t,n){n=(n&4)!==0;for(var i=0;i<t.length;i++){var s=t[i],l=s.event;s=s.listeners;t:{var u=void 0;if(n)for(var g=s.length-1;0<=g;g--){var E=s[g],O=E.instance,Y=E.currentTarget;if(E=E.listener,O!==u&&l.isPropagationStopped())break t;u=E,l.currentTarget=Y;try{u(l)}catch(at){Ll(at)}l.currentTarget=null,u=O}else for(g=0;g<s.length;g++){if(E=s[g],O=E.instance,Y=E.currentTarget,E=E.listener,O!==u&&l.isPropagationStopped())break t;u=E,l.currentTarget=Y;try{u(l)}catch(at){Ll(at)}l.currentTarget=null,u=O}}}}function ye(t,n){var i=n[$t];i===void 0&&(i=n[$t]=new Set);var s=t+"__bubble";i.has(s)||(n_(n,t,2,!1),i.add(s))}function Dh(t,n,i){var s=0;n&&(s|=4),n_(i,t,s,n)}var Nc="_reactListening"+Math.random().toString(36).slice(2);function Nh(t){if(!t[Nc]){t[Nc]=!0,Ze.forEach(function(i){i!=="selectionchange"&&(FS.has(i)||Dh(i,!1,t),Dh(i,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[Nc]||(n[Nc]=!0,Dh("selectionchange",!1,n))}}function n_(t,n,i,s){switch(j_(n)){case 2:var l=NM;break;case 8:l=UM;break;default:l=Qh}i=l.bind(null,n,i,t),l=void 0,!Bu||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(l=!0),s?l!==void 0?t.addEventListener(n,i,{capture:!0,passive:l}):t.addEventListener(n,i,!0):l!==void 0?t.addEventListener(n,i,{passive:l}):t.addEventListener(n,i,!1)}function Uh(t,n,i,s,l){var u=s;if((n&1)===0&&(n&2)===0&&s!==null)t:for(;;){if(s===null)return;var g=s.tag;if(g===3||g===4){var E=s.stateNode.containerInfo;if(E===l)break;if(g===4)for(g=s.return;g!==null;){var O=g.tag;if((O===3||O===4)&&g.stateNode.containerInfo===l)return;g=g.return}for(;E!==null;){if(g=Oe(E),g===null)return;if(O=g.tag,O===5||O===6||O===26||O===27){s=u=g;continue t}E=E.parentNode}}s=s.return}nm(function(){var Y=u,at=Pu(i),mt=[];t:{var j=Dm.get(t);if(j!==void 0){var tt=Dl,Nt=t;switch(t){case"keypress":if(Cl(i)===0)break t;case"keydown":case"keyup":tt=Ey;break;case"focusin":Nt="focus",tt=Vu;break;case"focusout":Nt="blur",tt=Vu;break;case"beforeblur":case"afterblur":tt=Vu;break;case"click":if(i.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":tt=sm;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":tt=fy;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":tt=Cy;break;case Am:case Rm:case Cm:tt=py;break;case wm:tt=Dy;break;case"scroll":case"scrollend":tt=cy;break;case"wheel":tt=Uy;break;case"copy":case"cut":case"paste":tt=gy;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":tt=om;break;case"submit":tt=Ay;break;case"toggle":case"beforetoggle":tt=Oy}var jt=(n&4)!==0,he=!jt&&(t==="scroll"||t==="scrollend"),q=jt?j!==null?j+"Capture":null:j;jt=[];for(var V=Y,J;V!==null;){var dt=V;if(J=dt.stateNode,dt=dt.tag,dt!==5&&dt!==26&&dt!==27||J===null||q===null||(dt=po(V,q),dt!=null&&jt.push(Yo(V,dt,J))),he)break;V=V.return}0<jt.length&&(j=new tt(j,Nt,null,i,at),mt.push({event:j,listeners:jt}))}}if((n&7)===0){t:{if(tt=t==="mouseover"||t==="pointerover",j=t==="mouseout"||t==="pointerout",tt&&i!==zu&&(Nt=i.relatedTarget||i.fromElement)&&(Oe(Nt)||Nt[ee]))break t;(j||tt)&&(Nt=at.window===at?at:(tt=at.ownerDocument)?tt.defaultView||tt.parentWindow:window,j?(tt=i.relatedTarget||i.toElement,j=Y,tt=tt?Oe(tt):null,tt!==null&&(he=f(tt),jt=tt.tag,tt!==he||jt!==5&&jt!==27&&jt!==6)&&(tt=null)):(j=null,tt=Y),j!==tt&&(jt=sm,dt="onMouseLeave",q="onMouseEnter",V="mouse",(t==="pointerout"||t==="pointerover")&&(jt=om,dt="onPointerLeave",q="onPointerEnter",V="pointer"),he=j==null?Nt:_n(j),J=tt==null?Nt:_n(tt),Nt=new jt(dt,V+"leave",j,i,at),Nt.target=he,Nt.relatedTarget=J,dt=null,Oe(at)===Y&&(jt=new jt(q,V+"enter",tt,i,at),jt.target=J,jt.relatedTarget=he,dt=jt),he=dt,jt=j&&tt?F(j,tt,HS):null,j!==null&&i_(mt,Nt,j,jt,!1),tt!==null&&he!==null&&i_(mt,he,tt,jt,!0)))}t:{if(j=Y?_n(Y):window,tt=j.nodeName&&j.nodeName.toLowerCase(),tt==="select"||tt==="input"&&j.type==="file")var Ht=mm;else if(dm(j))if(gm)Ht=Xy;else{Ht=Vy;var Ee=Gy}else tt=j.nodeName,!tt||tt.toLowerCase()!=="input"||j.type!=="checkbox"&&j.type!=="radio"?Y&&Ou(Y.elementType)&&(Ht=mm):Ht=ky;if(Ht&&(Ht=Ht(t,Y))){pm(mt,Ht,i,at);break t}Ee&&Ee(t,j,Y)}switch(Ee=Y?_n(Y):window,t){case"focusin":(dm(Ee)||Ee.contentEditable==="true")&&(ar=Ee,Zu=Y,Mo=null);break;case"focusout":Mo=Zu=ar=null;break;case"mousedown":Ku=!0;break;case"contextmenu":case"mouseup":case"dragend":Ku=!1,Tm(mt,i,at);break;case"selectionchange":if(qy)break;case"keydown":case"keyup":Tm(mt,i,at)}var Jt;if(Xu)t:{switch(t){case"compositionstart":var ae="onCompositionStart";break t;case"compositionend":ae="onCompositionEnd";break t;case"compositionupdate":ae="onCompositionUpdate";break t}ae=void 0}else ir?fm(t,i)&&(ae="onCompositionEnd"):t==="keydown"&&i.keyCode===229&&(ae="onCompositionStart");ae&&(lm&&i.locale!=="ko"&&(ir||ae!=="onCompositionStart"?ae==="onCompositionEnd"&&ir&&(Jt=im()):(Ra=at,Fu="value"in Ra?Ra.value:Ra.textContent,ir=!0)),Ee=Uc(Y,ae),0<Ee.length&&(ae=new rm(ae,t,null,i,at),mt.push({event:ae,listeners:Ee}),Jt?ae.data=Jt:(Jt=hm(i),Jt!==null&&(ae.data=Jt)))),(Jt=Py?Iy(t,i):By(t,i))&&(ae=Uc(Y,"onBeforeInput"),0<ae.length&&(Ee=new rm("onBeforeInput","beforeinput",null,i,at),mt.push({event:Ee,listeners:ae}),Ee.data=Jt)),PS(mt,t,Y,i,at)}e_(mt,n)})}function Yo(t,n,i){return{instance:t,listener:n,currentTarget:i}}function Uc(t,n){for(var i=n+"Capture",s=[];t!==null;){var l=t,u=l.stateNode;if(l=l.tag,l!==5&&l!==26&&l!==27||u===null||(l=po(t,i),l!=null&&s.unshift(Yo(t,l,u)),l=po(t,n),l!=null&&s.push(Yo(t,l,u))),t.tag===3)return s;t=t.return}return[]}function HS(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function i_(t,n,i,s,l){for(var u=n._reactName,g=[];i!==null&&i!==s;){var E=i,O=E.alternate,Y=E.stateNode;if(E=E.tag,O!==null&&O===s)break;E!==5&&E!==26&&E!==27||Y===null||(O=Y,l?(Y=po(i,u),Y!=null&&g.unshift(Yo(i,Y,O))):l||(Y=po(i,u),Y!=null&&g.push(Yo(i,Y,O)))),i=i.return}g.length!==0&&t.push({event:n,listeners:g})}var GS=/\r\n?/g,VS=/\u0000|\uFFFD/g;function a_(t){return(typeof t=="string"?t:""+t).replace(GS,`
`).replace(VS,"")}function s_(t,n){return n=a_(n),a_(t)===n}function He(t,n,i,s,l,u){switch(i){case"children":if(typeof s=="string")n==="body"||n==="textarea"&&s===""||tr(t,s);else if(typeof s=="number"||typeof s=="bigint")n!=="body"&&tr(t,""+s);else return;break;case"className":bl(t,"class",s);break;case"tabIndex":bl(t,"tabindex",s);break;case"dir":case"role":case"viewBox":case"width":case"height":bl(t,i,s);break;case"style":tm(t,s,u);return;case"data":if(n!=="object"){bl(t,"data",s);break}case"src":case"href":if(s===""&&(n!=="a"||i!=="href")){t.removeAttribute(i);break}if(s==null||typeof s=="function"||typeof s=="symbol"||typeof s=="boolean"){t.removeAttribute(i);break}s=Al(s),t.setAttribute(i,s);break;case"action":case"formAction":if(typeof s=="function"){t.setAttribute(i,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof u=="function"&&(i==="formAction"?(n!=="input"&&He(t,n,"name",l.name,l,null),He(t,n,"formEncType",l.formEncType,l,null),He(t,n,"formMethod",l.formMethod,l,null),He(t,n,"formTarget",l.formTarget,l,null)):(He(t,n,"encType",l.encType,l,null),He(t,n,"method",l.method,l,null),He(t,n,"target",l.target,l,null)));if(s==null||typeof s=="symbol"||typeof s=="boolean"){t.removeAttribute(i);break}s=Al(s),t.setAttribute(i,s);break;case"onClick":s!=null&&(t.onclick=Bi);return;case"onScroll":s!=null&&ye("scroll",t);return;case"onScrollEnd":s!=null&&ye("scrollend",t);return;case"dangerouslySetInnerHTML":if(s!=null){if(typeof s!="object"||!("__html"in s))throw Error(r(61));if(i=s.__html,i!=null){if(l.children!=null)throw Error(r(60));u?.__html!==i&&(t.innerHTML=i)}}break;case"multiple":t.multiple=s&&typeof s!="function"&&typeof s!="symbol";break;case"muted":t.muted=s&&typeof s!="function"&&typeof s!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(s==null||typeof s=="function"||typeof s=="boolean"||typeof s=="symbol"){t.removeAttribute("xlink:href");break}i=Al(s),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",i);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":s!=null&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(i,s):t.removeAttribute(i);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":s&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(i,""):t.removeAttribute(i);break;case"capture":case"download":s===!0?t.setAttribute(i,""):s!==!1&&s!=null&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(i,s):t.removeAttribute(i);break;case"cols":case"rows":case"size":case"span":s!=null&&typeof s!="function"&&typeof s!="symbol"&&!isNaN(s)&&1<=s?t.setAttribute(i,s):t.removeAttribute(i);break;case"rowSpan":case"start":s==null||typeof s=="function"||typeof s=="symbol"||isNaN(s)?t.removeAttribute(i):t.setAttribute(i,s);break;case"popover":ye("beforetoggle",t),ye("toggle",t),Tl(t,"popover",s);break;case"xlinkActuate":na(t,"http://www.w3.org/1999/xlink","xlink:actuate",s);break;case"xlinkArcrole":na(t,"http://www.w3.org/1999/xlink","xlink:arcrole",s);break;case"xlinkRole":na(t,"http://www.w3.org/1999/xlink","xlink:role",s);break;case"xlinkShow":na(t,"http://www.w3.org/1999/xlink","xlink:show",s);break;case"xlinkTitle":na(t,"http://www.w3.org/1999/xlink","xlink:title",s);break;case"xlinkType":na(t,"http://www.w3.org/1999/xlink","xlink:type",s);break;case"xmlBase":na(t,"http://www.w3.org/XML/1998/namespace","xml:base",s);break;case"xmlLang":na(t,"http://www.w3.org/XML/1998/namespace","xml:lang",s);break;case"xmlSpace":na(t,"http://www.w3.org/XML/1998/namespace","xml:space",s);break;case"is":Tl(t,"is",s);break;case"innerText":case"textContent":return;default:if(!(2<i.length)||i[0]!=="o"&&i[0]!=="O"||i[1]!=="n"&&i[1]!=="N")i=oy.get(i)||i,Tl(t,i,s);else return}De=!0}function Lh(t,n,i,s,l,u){switch(i){case"style":tm(t,s,u);return;case"dangerouslySetInnerHTML":if(s!=null){if(typeof s!="object"||!("__html"in s))throw Error(r(61));if(i=s.__html,i!=null){if(l.children!=null)throw Error(r(60));u?.__html!==i&&(t.innerHTML=i)}}break;case"children":if(typeof s=="string")tr(t,s);else if(typeof s=="number"||typeof s=="bigint")tr(t,""+s);else return;break;case"onScroll":s!=null&&ye("scroll",t);return;case"onScrollEnd":s!=null&&ye("scrollend",t);return;case"onClick":s!=null&&(t.onclick=Bi);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!In.hasOwnProperty(i))t:{if(i[0]==="o"&&i[1]==="n"&&(l=i.endsWith("Capture"),u=i.slice(2,l?i.length-7:void 0),n=t[Xt]||null,n=n!=null?n[i]:null,typeof n=="function"&&t.removeEventListener(u,n,l),typeof s=="function")){typeof n!="function"&&n!==null&&(i in t?t[i]=null:t.hasAttribute(i)&&t.removeAttribute(i)),t.addEventListener(u,s,l);break t}De=!0,i in t?t[i]=s:s===!0?t.setAttribute(i,""):Tl(t,i,s)}return}De=!0}function Dn(t,n,i){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ye("error",t),ye("load",t);var s=!1,l=!1,u;for(u in i)if(i.hasOwnProperty(u)){var g=i[u];if(g!=null)switch(u){case"src":s=!0;break;case"srcSet":l=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:He(t,n,u,g,i,null)}}l&&He(t,n,"srcSet",i.srcSet,i,null),s&&He(t,n,"src",i.src,i,null);return;case"input":ye("invalid",t);var E=u=g=l=null,O=null,Y=null;for(s in i)if(i.hasOwnProperty(s)){var at=i[s];if(at!=null)switch(s){case"name":l=at;break;case"type":g=at;break;case"checked":O=at;break;case"defaultChecked":Y=at;break;case"value":u=at;break;case"defaultValue":E=at;break;case"children":case"dangerouslySetInnerHTML":if(at!=null)throw Error(r(137,n));break;default:He(t,n,s,at,i,null)}}Kp(t,u,E,O,Y,g,l,!1);return;case"select":ye("invalid",t),s=g=u=null;for(l in i)if(i.hasOwnProperty(l)&&(E=i[l],E!=null))switch(l){case"value":u=E;break;case"defaultValue":g=E;break;case"multiple":s=E;default:He(t,n,l,E,i,null)}n=u,i=g,t.multiple=!!s,n!=null?$s(t,!!s,n,!1):i!=null&&$s(t,!!s,i,!0);return;case"textarea":ye("invalid",t),u=l=s=null;for(g in i)if(i.hasOwnProperty(g)&&(E=i[g],E!=null))switch(g){case"value":s=E;break;case"defaultValue":l=E;break;case"children":u=E;break;case"dangerouslySetInnerHTML":if(E!=null)throw Error(r(91));break;default:He(t,n,g,E,i,null)}Jp(t,s,l,u);return;case"option":for(O in i)i.hasOwnProperty(O)&&(s=i[O],s!=null)&&(O==="selected"?t.selected=s&&typeof s!="function"&&typeof s!="symbol":He(t,n,O,s,i,null));return;case"dialog":ye("beforetoggle",t),ye("toggle",t),ye("cancel",t),ye("close",t);break;case"iframe":case"object":ye("load",t);break;case"video":case"audio":for(s=0;s<qo.length;s++)ye(qo[s],t);break;case"image":ye("error",t),ye("load",t);break;case"details":ye("toggle",t);break;case"embed":case"source":case"link":ye("error",t),ye("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(Y in i)if(i.hasOwnProperty(Y)&&(s=i[Y],s!=null))switch(Y){case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:He(t,n,Y,s,i,null)}return;default:if(Ou(n)){for(at in i)i.hasOwnProperty(at)&&(s=i[at],s!==void 0&&Lh(t,n,at,s,i,void 0));return}}for(E in i)i.hasOwnProperty(E)&&(s=i[E],s!=null&&He(t,n,E,s,i,null))}var kS={};function XS(t,n,i,s){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var l=null,u=null,g=null,E=null,O=null,Y=null,at=null;for(tt in i){var mt=i[tt];if(i.hasOwnProperty(tt)&&mt!=null)switch(tt){case"checked":break;case"value":break;case"defaultValue":O=mt;default:s.hasOwnProperty(tt)||He(t,n,tt,null,s,mt)}}for(var j in s){var tt=s[j];if(mt=i[j],s.hasOwnProperty(j)&&(tt!=null||mt!=null))switch(j){case"type":tt!==mt&&(De=!0),u=tt;break;case"name":tt!==mt&&(De=!0),l=tt;break;case"checked":tt!==mt&&(De=!0),Y=tt;break;case"defaultChecked":tt!==mt&&(De=!0),at=tt;break;case"value":tt!==mt&&(De=!0),g=tt;break;case"defaultValue":tt!==mt&&(De=!0),E=tt;break;case"children":case"dangerouslySetInnerHTML":if(tt!=null)throw Error(r(137,n));break;default:tt!==mt&&He(t,n,j,tt,s,mt)}}Uu(t,g,E,O,Y,at,u,l);return;case"select":tt=g=E=j=null;for(u in i)if(O=i[u],i.hasOwnProperty(u)&&O!=null)switch(u){case"value":break;case"multiple":tt=O;default:s.hasOwnProperty(u)||He(t,n,u,null,s,O)}for(l in s)if(u=s[l],O=i[l],s.hasOwnProperty(l)&&(u!=null||O!=null))switch(l){case"value":u!==O&&(De=!0),j=u;break;case"defaultValue":u!==O&&(De=!0),E=u;break;case"multiple":u!==O&&(De=!0),g=u;default:u!==O&&He(t,n,l,u,s,O)}n=E,i=g,s=tt,j!=null?$s(t,!!i,j,!1):!!s!=!!i&&(n!=null?$s(t,!!i,n,!0):$s(t,!!i,i?[]:"",!1));return;case"textarea":tt=j=null;for(E in i)if(l=i[E],i.hasOwnProperty(E)&&l!=null&&!s.hasOwnProperty(E))switch(E){case"value":break;case"children":break;default:He(t,n,E,null,s,l)}for(g in s)if(l=s[g],u=i[g],s.hasOwnProperty(g)&&(l!=null||u!=null))switch(g){case"value":l!==u&&(De=!0),j=l;break;case"defaultValue":l!==u&&(De=!0),tt=l;break;case"children":break;case"dangerouslySetInnerHTML":if(l!=null)throw Error(r(91));break;default:l!==u&&He(t,n,g,l,s,u)}Qp(t,j,tt);return;case"option":for(var Nt in i)j=i[Nt],i.hasOwnProperty(Nt)&&j!=null&&!s.hasOwnProperty(Nt)&&(Nt==="selected"?t.selected=!1:He(t,n,Nt,null,s,j));for(O in s)j=s[O],tt=i[O],s.hasOwnProperty(O)&&j!==tt&&(j!=null||tt!=null)&&(O==="selected"?(j!==tt&&(De=!0),t.selected=j&&typeof j!="function"&&typeof j!="symbol"):He(t,n,O,j,s,tt));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var jt in i)j=i[jt],i.hasOwnProperty(jt)&&j!=null&&!s.hasOwnProperty(jt)&&He(t,n,jt,null,s,j);for(Y in s)if(j=s[Y],tt=i[Y],s.hasOwnProperty(Y)&&j!==tt&&(j!=null||tt!=null))switch(Y){case"children":case"dangerouslySetInnerHTML":if(j!=null)throw Error(r(137,n));break;default:He(t,n,Y,j,s,tt)}return;default:if(Ou(n)){for(var he in i)j=i[he],i.hasOwnProperty(he)&&j!==void 0&&!s.hasOwnProperty(he)&&Lh(t,n,he,void 0,s,j);for(at in s)j=s[at],tt=i[at],!s.hasOwnProperty(at)||j===tt||j===void 0&&tt===void 0||Lh(t,n,at,j,s,tt);return}}for(var q in i)j=i[q],i.hasOwnProperty(q)&&j!=null&&!s.hasOwnProperty(q)&&He(t,n,q,null,s,j);for(mt in s)j=s[mt],tt=i[mt],!s.hasOwnProperty(mt)||j===tt||j==null&&tt==null||He(t,n,mt,j,s,tt)}function r_(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function jS(){if(typeof performance.getEntriesByType=="function"){for(var t=0,n=0,i=performance.getEntriesByType("resource"),s=0;s<i.length;s++){var l=i[s],u=l.transferSize,g=l.initiatorType,E=l.duration;if(u&&E&&r_(g)){for(g=0,E=l.responseEnd,s+=1;s<i.length;s++){var O=i[s],Y=O.startTime;if(Y>E)break;var at=O.transferSize,mt=O.initiatorType;at&&r_(mt)&&(O=O.responseEnd,g+=at*(O<E?1:(E-Y)/(O-Y)))}if(--s,n+=8*(u+g)/(l.duration/1e3),t++,10<t)break}}if(0<t)return n/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var Oh=null,zh=null;function Wo(t){return t.nodeType===9?t:t.ownerDocument}function o_(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function l_(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function c_(t,n,i,s){return i=Wo(i).createElement(t),i[wt]=s,i[Xt]=n,Dn(i,t,n),we(i),i}function Ph(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var Ih=null;function qS(){var t=window.event;return t&&t.type==="popstate"?t===Ih?!1:(Ih=t,!0):(Ih=null,!1)}var Bh=typeof setTimeout=="function"?setTimeout:void 0,YS=typeof clearTimeout=="function"?clearTimeout:void 0,u_=typeof Promise=="function"?Promise:void 0,f_=typeof requestAnimationFrame=="function"?requestAnimationFrame:Bh,WS=typeof queueMicrotask=="function"?queueMicrotask:typeof u_<"u"?function(t){return u_.resolve(null).then(t).catch(ZS)}:Bh;function ZS(t){setTimeout(function(){throw t})}function Ya(t){return t==="head"}function h_(t,n){var i=n,s=0;do{var l=i.nextSibling;if(t.removeChild(i),l&&l.nodeType===8)if(i=l.data,i==="/$"||i==="/&"){if(s===0){t.removeChild(l),Ir(n);return}s--}else if(i==="$"||i==="$?"||i==="$~"||i==="$!"||i==="&")s++;else if(i==="html")qh(t.ownerDocument.documentElement);else if(i==="head"){i=t.ownerDocument.head,qh(i);for(var u=i.firstChild;u;){var g=u.nextSibling,E=u.nodeName;u[Le]||E==="SCRIPT"||E==="STYLE"||E==="LINK"&&u.rel.toLowerCase()==="stylesheet"||i.removeChild(u),u=g}}else i==="body"&&qh(t.ownerDocument.body);i=l}while(i);Ir(n)}function d_(t,n){var i=t;t=0;do{var s=i.nextSibling;if(i.nodeType===1?n?(i._stashedDisplay=i.style.display,i.style.display="none"):(i.style.display=i._stashedDisplay||"",i.getAttribute("style")===""&&i.removeAttribute("style")):i.nodeType===3&&(n?(i._stashedText=i.nodeValue,i.nodeValue=""):i.nodeValue=i._stashedText||""),s&&s.nodeType===8)if(i=s.data,i==="/$"){if(t===0)break;t--}else i!=="$"&&i!=="$?"&&i!=="$~"&&i!=="$!"||t++;i=s}while(i)}function p_(t,n,i){if(n=CSS.escape(n)!==n?"r-"+btoa(n).replace(/=/g,""):n,t.style.viewTransitionName=n,i!=null&&(t.style.viewTransitionClass=i),i=getComputedStyle(t),i.display==="inline"){if(n=t.getClientRects(),n.length===1)var s=1;else for(var l=s=0;l<n.length;l++){var u=n[l];0<u.width&&0<u.height&&s++}s===1&&(t=t.style,t.display=n.length===1?"inline-block":"block",t.marginTop="-"+i.paddingTop,t.marginBottom="-"+i.paddingBottom)}}function m_(t,n){t=t.style,n=n.style;var i=n!=null?n.hasOwnProperty("viewTransitionName")?n.viewTransitionName:n.hasOwnProperty("view-transition-name")?n["view-transition-name"]:null:null;t.viewTransitionName=i==null||typeof i=="boolean"?"":(""+i).trim(),i=n!=null?n.hasOwnProperty("viewTransitionClass")?n.viewTransitionClass:n.hasOwnProperty("view-transition-class")?n["view-transition-class"]:null:null,t.viewTransitionClass=i==null||typeof i=="boolean"?"":(""+i).trim(),t.display==="inline-block"&&(n==null?t.display=t.margin="":(i=n.display,t.display=i==null||typeof i=="boolean"?"":i,i=n.margin,i!=null?t.margin=i:(i=n.hasOwnProperty("marginTop")?n.marginTop:n["margin-top"],t.marginTop=i==null||typeof i=="boolean"?"":i,n=n.hasOwnProperty("marginBottom")?n.marginBottom:n["margin-bottom"],t.marginBottom=n==null||typeof n=="boolean"?"":n)))}function KS(t,n,i){return i=i.ownerDocument.defaultView,{rect:t,abs:n.position==="absolute"||n.position==="fixed",clip:n.clipPath!=="none"||n.overflow!=="visible"||n.filter!=="none"||n.mask!=="none"||n.mask!=="none"||n.borderRadius!=="0px",view:0<=t.bottom&&0<=t.right&&t.top<=i.innerHeight&&t.left<=i.innerWidth}}function Fh(t){var n=t.getBoundingClientRect(),i=getComputedStyle(t);return KS(n,i,t)}function QS(t){return t.documentElement.clientHeight}function JS(t){this.addEventListener("load",t),this.addEventListener("error",t)}function $S(t,n,i,s,l,u,g,E,O){var Y=n.nodeType===9?n:n.ownerDocument;try{var at=Y.startViewTransition({update:function(){var j=Y.defaultView,tt=j.navigation&&j.navigation.transition,Nt=Y.fonts.status;s();var jt=[];if(Nt==="loaded"&&(QS(Y),Y.fonts.status==="loading"&&jt.push(Y.fonts.ready)),Nt=jt.length,t!==null)for(var he=t.suspenseyImages,q=0,V=0;V<he.length;V++){var J=he[V];if(!J.complete){var dt=J.getBoundingClientRect();if(0<dt.bottom&&0<dt.right&&dt.top<j.innerHeight&&dt.left<j.innerWidth){if(q+=P_(J),q>zc){jt.length=Nt;break}J=new Promise(JS.bind(J)),jt.push(J)}}}if(0<jt.length)return j=Promise.race([Promise.all(jt),new Promise(function(Ht){return setTimeout(Ht,500)})]).then(l,l),(tt?Promise.allSettled([tt.finished,j]):j).then(u,u);if(l(),tt)return tt.finished.then(u,u);u()},types:i});Y.__reactViewTransition=at;var mt=[];return at.ready.then(function(){for(var j=Y.documentElement.getAnimations({subtree:!0}),tt=0;tt<j.length;tt++){var Nt=j[tt],jt=Nt.effect,he=jt.pseudoElement;if(he!=null&&he.startsWith("::view-transition")){mt.push(Nt),Nt=jt.getKeyframes();for(var q=he=void 0,V=!0,J=0;J<Nt.length;J++){var dt=Nt[J],Ht=dt.width;if(he===void 0)he=Ht;else if(he!==Ht){V=!1;break}if(Ht=dt.height,q===void 0)q=Ht;else if(q!==Ht){V=!1;break}delete dt.width,delete dt.height,dt.transform==="none"&&delete dt.transform}V&&he!==void 0&&q!==void 0&&(jt.setKeyframes(Nt),V=getComputedStyle(jt.target,jt.pseudoElement),V.width!==he||V.height!==q)&&(V=Nt[0],V.width=he,V.height=q,V=Nt[Nt.length-1],V.width=he,V.height=q,jt.setKeyframes(Nt))}}g()},function(j){Y.__reactViewTransition===at&&(Y.__reactViewTransition=null);try{typeof j=="object"&&j!==null&&j.name==="InvalidStateError"&&(j.message==="View transition was skipped because document visibility state is hidden."||j.message==="Skipping view transition because document visibility state has become hidden."||j.message==="Skipping view transition because viewport size changed."||j.message==="Transition was aborted because of invalid state")&&(j=null),j!==null&&O(j)}finally{s(),l(),g()}}),at.finished.finally(function(){for(var j=0;j<mt.length;j++)mt[j].cancel();Y.__reactViewTransition===at&&(Y.__reactViewTransition=null),E()}),at}catch{return s(),l(),g(),null}}function Os(t,n){this._scope=document.documentElement,this._selector="::view-transition-"+t+"("+n+")"}Os.prototype.animate=function(t,n){return n=typeof n=="number"?{duration:n}:P({},n),n.pseudoElement=this._selector,this._scope.animate(t,n)},Os.prototype.getAnimations=function(){for(var t=this._scope,n=this._selector,i=t.getAnimations({subtree:!0}),s=[],l=0;l<i.length;l++){var u=i[l].effect;u!==null&&u.target===t&&u.pseudoElement===n&&s.push(i[l])}return s},Os.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function g_(t){return{name:t,group:new Os("group",t),imagePair:new Os("image-pair",t),old:new Os("old",t),new:new Os("new",t)}}function ri(t){this._fragmentFiber=t,this._observers=this._eventListeners=null}ri.prototype.addEventListener=function(t,n,i){var s=null,l=null;if(!(i!=null&&typeof i!="boolean"&&(s=i.signal||null,s!==null&&s.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var u=this._eventListeners;if(v_(u,t,n,i)===-1){var g=this,E=n;i!=null&&typeof i!="boolean"&&i.once===!0&&(E=function(O){g.removeEventListener(t,n,i),typeof n=="function"?n.call(this,O):n.handleEvent(O)}),s!==null&&(l=g.removeEventListener.bind(g,t,n,i),s.addEventListener("abort",l,{once:!0}),l=s.removeEventListener.bind(s,"abort",l)),s=Nr(i),u.push({type:t,listener:n,optionsOrUseCapture:i,attachedListener:E,cleanup:l}),p(this._fragmentFiber.child,!1,tM,t,E,s)}this._eventListeners=u}};function tM(t,n,i,s){return S(t).addEventListener(n,i,s),!1}ri.prototype.removeEventListener=function(t,n,i){var s=this._eventListeners;if(s!==null&&(n=v_(s,t,n,i),n!==-1)){var l=s[n];i=l.attachedListener;var u=l.cleanup;l=Nr(l.optionsOrUseCapture),p(this._fragmentFiber.child,!1,eM,t,i,l),s.splice(n,1),u!==null&&u()}};function eM(t,n,i,s){return S(t).removeEventListener(n,i,s),!1}function Nr(t){return t!=null&&typeof t!="boolean"&&(t.once===!0||t.signal instanceof AbortSignal)?{capture:t.capture,passive:t.passive}:t}function __(t){return t==null?"c=0":typeof t=="boolean"?"c="+(t?"1":"0"):"c="+(t.capture?"1":"0")}function v_(t,n,i,s){if(t.length===0)return-1;s=__(s);for(var l=0;l<t.length;l++){var u=t[l];if(u.type===n&&u.listener===i&&__(u.optionsOrUseCapture)===s)return l}return-1}ri.prototype.dispatchEvent=function(t){var n=y(this._fragmentFiber);if(n===null)return!0;n=S(n);var i=this._eventListeners;if(i!==null&&0<i.length||!t.bubbles){var s=n.nodeType===9?n.createComment(""):document.createTextNode("");if(i)for(var l=0;l<i.length;l++){var u=i[l];s.addEventListener(u.type,u.attachedListener,Nr(u.optionsOrUseCapture))}if(n.appendChild(s),t=s.dispatchEvent(t),i)for(l=0;l<i.length;l++)u=i[l],s.removeEventListener(u.type,u.attachedListener,Nr(u.optionsOrUseCapture));return n.removeChild(s),t}return n.dispatchEvent(t)},ri.prototype.focus=function(t){p(this._fragmentFiber.child,!0,x_,t,void 0,void 0)};function x_(t,n){return t.tag===6?!1:(t=S(t),dM(t,n))}ri.prototype.focusLast=function(t){var n=[];p(this._fragmentFiber.child,!0,Hh,n,void 0,void 0);for(var i=n.length-1;0<=i&&!x_(n[i],t);i--);};function Hh(t,n){return n.push(t),!1}ri.prototype.blur=function(){var t=y(this._fragmentFiber);t!==null&&(t=S(t),t=Wo(t).activeElement,t!==null&&p(this._fragmentFiber.child,!1,nM,t,void 0,void 0))};function nM(t,n){return t.tag===6?!1:(t=S(t),t===n||t.contains(n)?(n.blur(),!0):!1)}ri.prototype.observeUsing=function(t){this._observers===null&&(this._observers=new Set),this._observers.add(t),p(this._fragmentFiber.child,!1,iM,t,void 0,void 0)};function iM(t,n){return t.tag===6||(t=S(t),n.observe(t)),!1}ri.prototype.unobserveUsing=function(t){var n=this._observers;if(n!==null&&n.has(t)){n.delete(t),p(this._fragmentFiber.child,!1,aM,t,void 0,void 0);for(var i=n=0;i<Ci.length;i++){var s=Ci[i];s.fragmentInstance===this&&s.observer===t?t.unobserve(s.instance):Ci[n++]=s}Ci.length=n}};function aM(t,n){return t.tag===6||(t=S(t),n.unobserve(t)),!1}var Ci=[],Gh=!1;function sM(t,n,i){Ci.push({fragmentInstance:t,observer:n,instance:i}),Gh||(Gh=!0,pM(function(){Gh=!1;var s=Ci;Ci=[];for(var l=0;l<s.length;l++){var u=s[l];u.observer.unobserve(u.instance)}}))}ri.prototype.getClientRects=function(){var t=[];return p(this._fragmentFiber.child,!1,rM,t,void 0,void 0),t};function rM(t,n){if(t.tag===6){t=t.stateNode;var i=t.ownerDocument.createRange();i.selectNodeContents(t),n.push.apply(n,i.getClientRects())}else t=S(t),n.push.apply(n,t.getClientRects());return!1}ri.prototype.getRootNode=function(t){var n=y(this._fragmentFiber);return n===null?this:S(n).getRootNode(t)},ri.prototype.compareDocumentPosition=function(t){var n=y(this._fragmentFiber);if(n===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var i=[];p(this._fragmentFiber.child,!1,Hh,i,void 0,void 0);var s=S(n);if(i.length===0){if(i=s,M(this._fragmentFiber)){t:{for(n=this._fragmentFiber.return;n!==null;){if(n.tag===4){n=n.stateNode.containerInfo;break t}if(n.tag===3||n.tag===5||n.tag===27)break;n=n.return}n=null}n!=null&&(i=n)}n=this._fragmentFiber;var l=s=i.compareDocumentPosition(t);return i===t?l=Node.DOCUMENT_POSITION_CONTAINS:s&Node.DOCUMENT_POSITION_CONTAINED_BY&&(i=b(n)[1],i===null?l=Node.DOCUMENT_POSITION_PRECEDING:(t=S(i).compareDocumentPosition(t),l=t===0||t&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),l|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}n=S(i[0]),l=S(i[i.length-1]);var u=M(this._fragmentFiber)?n.parentElement:s;if(u==null)return Node.DOCUMENT_POSITION_DISCONNECTED;s=u.compareDocumentPosition(n)&Node.DOCUMENT_POSITION_CONTAINED_BY,u=u.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_CONTAINED_BY;var g=n.compareDocumentPosition(t),E=l.compareDocumentPosition(t),O=g&Node.DOCUMENT_POSITION_CONTAINED_BY||E&Node.DOCUMENT_POSITION_CONTAINED_BY;return E=s&&u&&g&Node.DOCUMENT_POSITION_FOLLOWING&&E&Node.DOCUMENT_POSITION_PRECEDING,n=s&&n===t||u&&l===t||O||E?Node.DOCUMENT_POSITION_CONTAINED_BY:!s&&n===t||!u&&l===t?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:g,n&Node.DOCUMENT_POSITION_DISCONNECTED||n&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||oM(n,this._fragmentFiber,i[0],i[i.length-1],t)?n:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function oM(t,n,i,s,l){var u=Oe(l);if(t&Node.DOCUMENT_POSITION_CONTAINED_BY){if(i=!!u)t:{for(;u!==null;){if(u.tag===7&&(u===n||u.alternate===n)){i=!0;break t}u=u.return}i=!1}return i}if(t&Node.DOCUMENT_POSITION_CONTAINS){if(u===null)return u=l.ownerDocument,l===u||l===u.documentElement||l===u.body;t:{for(u=n,n=y(n);u!==null;){if(!(u.tag!==5&&u.tag!==3&&u.tag!==27||u!==n&&u.alternate!==n)){u=!0;break t}u=u.return}u=!1}return u}return t&Node.DOCUMENT_POSITION_PRECEDING?((n=!!u)&&!(n=u===i)&&(n=F(i,u,H),n===null?n=!1:(p(n,!0,z,u,i),u=v,v=null,n=u!==null)),n):t&Node.DOCUMENT_POSITION_FOLLOWING?((n=!!u)&&!(n=u===s)&&(n=F(s,u,H),n===null?n=!1:(p(n,!0,N,u,s),u=v,L=v=null,n=u!==null)),n):!1}function y_(t,n){var i=t.ownerDocument.createRange();i.selectNodeContents(t),t=i.getBoundingClientRect(),window.scrollTo(window.scrollX+t.left,n?window.scrollY+t.top:window.scrollY+t.bottom-window.innerHeight)}ri.prototype.scrollIntoView=function(t){if(typeof t=="object")throw Error(r(566));var n=[];p(this._fragmentFiber.child,!1,Hh,n,void 0,void 0);var i=t!==!1;if(n.length===0){var s=b(this._fragmentFiber);if(s=i?s[1]||s[0]||y(this._fragmentFiber):s[0]||s[1],s===null)return;if(s.tag===6){t=S(s),y_(t,i);return}if(s=S(s),s.nodeType!==9){if(s.nodeType===11){i="host"in s?s.host:null,i!==null&&i.scrollIntoView(t);return}s.scrollIntoView(t)}}for(s=i?n.length-1:0;s!==(i?-1:n.length);){var l=n[s];l.tag===6?(l=S(l),y_(l,i)):S(l).scrollIntoView(t),s+=i?-1:1}};function lM(t,n){return t=S(t),S_(t,n),!1}function S_(t,n){t.reactFragments==null&&(t.reactFragments=new Set),t.reactFragments.add(n)}function M_(t,n){var i=n._eventListeners;if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];t.addEventListener(l.type,l.attachedListener,Nr(l.optionsOrUseCapture))}t.nodeType!==3&&(i=n._observers,i!==null&&i.forEach(function(u){for(var g=0,E=0;E<Ci.length;E++){var O=Ci[E];(O.fragmentInstance!==n||O.observer!==u||O.instance!==t)&&(Ci[g++]=O)}Ci.length=g,u.observe(t)}),S_(t,n))}function cM(t,n){var i=n._eventListeners;if(i!==null)for(var s=0;s<i.length;s++){var l=i[s];t.removeEventListener(l.type,l.attachedListener,Nr(l.optionsOrUseCapture))}t.nodeType!==3&&(i=n._observers,i!==null&&i.forEach(function(u){typeof u.rootMargin=="string"?sM(n,u,t):u.unobserve(t)}),t.reactFragments!=null&&t.reactFragments.delete(n))}function Vh(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var i=n;switch(n=n.nextSibling,i.nodeName){case"HTML":case"HEAD":case"BODY":Vh(i),te(i);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(i.rel.toLowerCase()==="stylesheet")continue}t.removeChild(i)}}function uM(t,n,i,s){for(;t.nodeType===1;){var l=i;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!s&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(s){if(!t[Le])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(u=t.getAttribute("rel"),u==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(u!==l.rel||t.getAttribute("href")!==(l.href==null||l.href===""?null:l.href)||t.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin)||t.getAttribute("title")!==(l.title==null?null:l.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(u=t.getAttribute("src"),(u!==(l.src==null?null:l.src)||t.getAttribute("type")!==(l.type==null?null:l.type)||t.getAttribute("crossorigin")!==(l.crossOrigin==null?null:l.crossOrigin))&&u&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var u=l.name==null?null:""+l.name;if(l.type==="hidden"&&t.getAttribute("name")===u)return t}else return t;if(t=xi(t.nextSibling),t===null)break}return null}function fM(t,n,i){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!i||(t=xi(t.nextSibling),t===null))return null;return t}function E_(t,n){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!n||(t=xi(t.nextSibling),t===null))return null;return t}function kh(t){return t.data==="$?"||t.data==="$~"}function Xh(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function hM(t,n){var i=t.ownerDocument;if(t.data==="$~")t._reactRetry=n;else if(t.data!=="$?"||i.readyState!=="loading")n();else{var s=function(){n(),i.removeEventListener("DOMContentLoaded",s)};i.addEventListener("DOMContentLoaded",s),t._reactRetry=s}}function xi(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return t}var jh=null;function T_(t){t=t.nextSibling;for(var n=0;t;){if(t.nodeType===8){var i=t.data;if(i==="/$"||i==="/&"){if(n===0)return xi(t.nextSibling);n--}else i!=="$"&&i!=="$!"&&i!=="$?"&&i!=="$~"&&i!=="&"||n++}t=t.nextSibling}return null}function b_(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var i=t.data;if(i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"){if(n===0)return t;n--}else i!=="/$"&&i!=="/&"||n++}t=t.previousSibling}return null}function dM(t,n){function i(){s=!0}if(t.ownerDocument.activeElement===t)return!0;var s=!1;try{t.ownerDocument.addEventListener("focus",i,!0),(t.focus||HTMLElement.prototype.focus).call(t,n)}finally{t.ownerDocument.removeEventListener("focus",i,!0)}return s}function pM(t){f_(function(){f_(function(n){return t(n)})})}function A_(t,n,i){switch(n=Wo(i),t){case"html":if(t=n.documentElement,!t)throw Error(r(452));return t;case"head":if(t=n.head,!t)throw Error(r(453));return t;case"body":if(t=n.body,!t)throw Error(r(454));return t;default:throw Error(r(451))}}function R_(t,n,i){for(var s in i){var l=i[s];i.hasOwnProperty(s)&&l!=null&&He(t,n,s,null,kS,l)}i.dangerouslySetInnerHTML!=null&&(t.textContent=""),t.onclick===Bi&&(t.onclick=null),te(t)}function qh(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);te(t)}var yi=new Map,C_=new Set;function Zo(t){if(typeof t.getRootNode=="function"){var n=t.getRootNode();if(n.nodeType===9||n.nodeType===11)return n}return t.nodeType===9?t:t.ownerDocument}var ma=qt.d;qt.d={f:mM,r:gM,D:_M,C:vM,L:xM,m:yM,X:MM,S:SM,M:EM};function mM(){var t=ma.f(),n=Ac();return t||n}function gM(t){var n=me(t);n!==null&&n.tag===5&&n.type==="form"?Dg(n):ma.r(t)}var Ur=typeof document>"u"?null:document;function w_(t,n,i){var s=Ur;if(s&&typeof n=="string"&&n){var l=hi(n);l='link[rel="'+t+'"][href="'+l+'"]',typeof i=="string"&&(l+='[crossorigin="'+i+'"]'),C_.has(l)||(C_.add(l),t={rel:t,crossOrigin:i,href:n},s.querySelector(l)===null&&(n=s.createElement("link"),Dn(n,"link",t),we(n),s.head.appendChild(n)))}}function _M(t){ma.D(t),w_("dns-prefetch",t,null)}function vM(t,n){ma.C(t,n),w_("preconnect",t,n)}function xM(t,n,i){ma.L(t,n,i);var s=Ur;if(s&&t&&n){var l='link[rel="preload"][as="'+hi(n)+'"]';n==="image"&&i&&i.imageSrcSet?(l+='[imagesrcset="'+hi(i.imageSrcSet)+'"]',typeof i.imageSizes=="string"&&(l+='[imagesizes="'+hi(i.imageSizes)+'"]')):l+='[href="'+hi(t)+'"]';var u=l;switch(n){case"style":u=Lr(t);break;case"script":u=Or(t)}if(!(yi.has(u)||(t=P({rel:"preload",href:n==="image"&&i&&i.imageSrcSet?void 0:t,as:n},i),yi.set(u,t),s.querySelector(l)!==null||n==="style"&&s.querySelector(Ko(u))||n==="script"&&s.querySelector(Qo(u))))){var g=s.createElement("link");Dn(g,"link",t),n==="style"&&(g[Ce]=!0,g.onload=g.onerror=function(){Aa(g)}),we(g),s.head.appendChild(g)}}}function yM(t,n){ma.m(t,n);var i=Ur;if(i&&t){var s=n&&typeof n.as=="string"?n.as:"script",l='link[rel="modulepreload"][as="'+hi(s)+'"][href="'+hi(t)+'"]',u=l;switch(s){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":u=Or(t)}if(!yi.has(u)&&(t=P({rel:"modulepreload",href:t},n),yi.set(u,t),i.querySelector(l)===null)){switch(s){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(i.querySelector(Qo(u)))return}s=i.createElement("link"),Dn(s,"link",t),we(s),i.head.appendChild(s)}}}function SM(t,n,i){ma.S(t,n,i);var s=Ur;if(s&&t){var l=Jn(s).hoistableStyles,u=Lr(t);n=n||"default";var g=l.get(u);if(!g){var E={loading:0,preload:null};if(g=s.querySelector(Ko(u)))E.loading=5;else{t=P({rel:"stylesheet",href:t,"data-precedence":n},i),(i=yi.get(u))&&Yh(t,i);var O=g=s.createElement("link");we(O),Dn(O,"link",t),O._p=new Promise(function(Y,at){O.onload=Y,O.onerror=at}),O.addEventListener("load",function(){E.loading|=1}),O.addEventListener("error",function(){E.loading|=2}),E.loading|=4,Lc(g,n,s)}g={type:"stylesheet",instance:g,count:1,state:E},l.set(u,g)}}}function MM(t,n){ma.X(t,n);var i=Ur;if(i&&t){var s=Jn(i).hoistableScripts,l=Or(t),u=s.get(l);u||(u=i.querySelector(Qo(l)),u||(t=P({src:t,async:!0},n),(n=yi.get(l))&&Wh(t,n),u=i.createElement("script"),we(u),Dn(u,"link",t),i.head.appendChild(u)),u={type:"script",instance:u,count:1,state:null},s.set(l,u))}}function EM(t,n){ma.M(t,n);var i=Ur;if(i&&t){var s=Jn(i).hoistableScripts,l=Or(t),u=s.get(l);u||(u=i.querySelector(Qo(l)),u||(t=P({src:t,async:!0,type:"module"},n),(n=yi.get(l))&&Wh(t,n),u=i.createElement("script"),we(u),Dn(u,"link",t),i.head.appendChild(u)),u={type:"script",instance:u,count:1,state:null},s.set(l,u))}}function D_(t,n,i,s){var l=(l=qe.current)?Zo(l):null;if(!l)throw Error(r(446));switch(t){case"meta":case"title":return null;case"style":return typeof i.precedence=="string"&&typeof i.href=="string"?(i=Lr(i.href),n=Jn(l).hoistableStyles,s=n.get(i),s||(s={type:"style",instance:null,count:0,state:null},n.set(i,s)),s):{type:"void",instance:null,count:0,state:null};case"link":if(i.rel==="stylesheet"&&typeof i.href=="string"&&typeof i.precedence=="string"){t=Lr(i.href);var u=Jn(l).hoistableStyles,g=u.get(t);if(g||(l=l.ownerDocument||l,g={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},u.set(t,g),(u=l.querySelector(Ko(t)))?u._p||(g.instance=u,g.state.loading=5):(u=yi.get(t),u||(u={rel:"preload",as:"style",href:i.href,crossOrigin:i.crossOrigin,integrity:i.integrity,media:i.media,hrefLang:i.hrefLang,referrerPolicy:i.referrerPolicy},yi.set(t,u)),TM(l,t,u,g.state))),n&&s===null)throw Error(r(528,""));return g}if(n&&s!==null)throw Error(r(529,""));return null;case"script":return n=i.async,i=i.src,typeof i=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(i=Or(i),n=Jn(l).hoistableScripts,s=n.get(i),s||(s={type:"script",instance:null,count:0,state:null},n.set(i,s)),s):{type:"void",instance:null,count:0,state:null};default:throw Error(r(444,t))}}function Lr(t){return'href="'+hi(t)+'"'}function Ko(t){return'link[rel="stylesheet"]['+t+"]"}function N_(t){return P({},t,{"data-precedence":t.precedence,precedence:null})}function TM(t,n,i,s){if(n=t.querySelector('link[rel="preload"][as="style"]['+n+"]")){if(n[Ce]!==!0){s.loading=1;return}}else n=t.createElement("link"),n[Ce]=!0,n.onload=n.onerror=Aa.bind(null,n),Dn(n,"link",i),we(n),t.head.appendChild(n);s.preload=n,n.addEventListener("load",function(){return s.loading|=1}),n.addEventListener("error",function(){return s.loading|=2})}function Or(t){return'[src="'+hi(t)+'"]'}function Qo(t){return"script[async]"+t}function U_(t,n,i){if(n.count++,n.instance===null)switch(n.type){case"style":var s=t.querySelector('style[data-href~="'+hi(i.href)+'"]');if(s)return n.instance=s,we(s),s;var l=P({},i,{"data-href":i.href,"data-precedence":i.precedence,href:null,precedence:null});return s=(t.ownerDocument||t).createElement("style"),we(s),Dn(s,"style",l),Lc(s,i.precedence,t),n.instance=s;case"stylesheet":l=Lr(i.href);var u=t.querySelector(Ko(l));if(u)return n.state.loading|=4,n.instance=u,we(u),u;s=N_(i),(l=yi.get(l))&&Yh(s,l),u=(t.ownerDocument||t).createElement("link"),we(u);var g=u;return g._p=new Promise(function(E,O){g.onload=E,g.onerror=O}),Dn(u,"link",s),n.state.loading|=4,Lc(u,i.precedence,t),n.instance=u;case"script":return u=Or(i.src),(l=t.querySelector(Qo(u)))?(n.instance=l,we(l),l):(s=i,(l=yi.get(u))&&(s=P({},i),Wh(s,l)),t=t.ownerDocument||t,l=t.createElement("script"),we(l),Dn(l,"link",s),t.head.appendChild(l),n.instance=l);case"void":return null;default:throw Error(r(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(s=n.instance,n.state.loading|=4,Lc(s,i.precedence,t));return n.instance}function Lc(t,n,i){for(var s=i.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),l=s.length?s[s.length-1]:null,u=l,g=0;g<s.length;g++){var E=s[g];if(E.dataset.precedence===n)u=E;else if(u!==l)break}u?u.parentNode.insertBefore(t,u.nextSibling):(n=i.nodeType===9?i.head:i,n.insertBefore(t,n.firstChild))}function Yh(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function Wh(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var Oc=null;function L_(t,n,i){if(Oc===null){var s=new Map,l=Oc=new Map;l.set(i,s)}else l=Oc,s=l.get(i),s||(s=new Map,l.set(i,s));if(s.has(t))return s;for(s.set(t,null),i=i.getElementsByTagName(t),l=0;l<i.length;l++){var u=i[l];if(!(u[Le]||u[wt]||t==="link"&&u.getAttribute("rel")==="stylesheet")&&u.namespaceURI!=="http://www.w3.org/2000/svg"){var g=u.getAttribute(n)||"";g=t+g;var E=s.get(g);E?E.push(u):s.set(g,[u])}}return s}function Zh(t,n,i){t=t.ownerDocument||t,t.head.insertBefore(i,n==="title"?t.querySelector("head > title"):null)}function bM(t,n,i){if(i===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;return n.rel==="stylesheet"?(t=n.disabled,typeof n.precedence=="string"&&t==null):!0;case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function O_(t,n){return t==="img"&&n.src!=null&&n.src!==""&&n.onLoad==null&&n.loading!=="lazy"}function z_(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function P_(t){return(t.width||100)*(t.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function I_(t,n){typeof n.decode=="function"&&(t.imgCount++,n.complete||(t.imgBytes+=P_(n),t.suspenseyImages.push(n)),t=CM.bind(t),n.decode().then(t,t))}function AM(t,n,i,s){if(i.type==="stylesheet"&&(typeof s.media!="string"||matchMedia(s.media).matches!==!1)&&(i.state.loading&4)===0){if(i.instance===null){var l=Lr(s.href),u=n.querySelector(Ko(l));if(u){n=u._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(t.count++,t=Jo.bind(t),n.then(t,t)),i.state.loading|=4,i.instance=u,we(u);return}u=n.ownerDocument||n,s=N_(s),(l=yi.get(l))&&Yh(s,l),u=u.createElement("link"),we(u);var g=u;g._p=new Promise(function(E,O){g.onload=E,g.onerror=O}),Dn(u,"link",s),i.instance=u}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(i,n),(n=i.state.preload)&&(i.state.loading&3)===0&&(t.count++,i=Jo.bind(t),n.addEventListener("load",i),n.addEventListener("error",i))}}var zc=0;function RM(t,n){return t.stylesheets&&t.count===0&&Ic(t,t.stylesheets),0<t.count||0<t.imgCount?function(i){var s=setTimeout(function(){if(t.stylesheets&&Ic(t,t.stylesheets),t.unsuspend){var u=t.unsuspend;t.unsuspend=null,u()}},6e4+n);0<t.imgBytes&&zc===0&&(zc=62500*jS());var l=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&Ic(t,t.stylesheets),t.unsuspend)){var u=t.unsuspend;t.unsuspend=null,u()}},(t.imgBytes>zc?50:800)+n);return t.unsuspend=i,function(){t.unsuspend=null,clearTimeout(s),clearTimeout(l)}}:null}function B_(t){if(t.count===0&&(t.imgCount===0||!t.waitingForImages)){if(t.stylesheets)Ic(t,t.stylesheets);else if(t.unsuspend){var n=t.unsuspend;t.unsuspend=null,n()}}}function Jo(){this.count--,B_(this)}function CM(){this.imgCount--,B_(this)}var Pc=null;function Ic(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Pc=new Map,n.forEach(wM,t),Pc=null,Jo.call(t))}function wM(t,n){if(!(n.state.loading&4)){var i=Pc.get(t);if(i)var s=i.get(null);else{i=new Map,Pc.set(t,i);for(var l=t.querySelectorAll("link[data-precedence],style[data-precedence]"),u=0;u<l.length;u++){var g=l[u];(g.nodeName==="LINK"||g.getAttribute("media")!=="not all")&&(i.set(g.dataset.precedence,g),s=g)}s&&i.set(null,s)}l=n.instance,g=l.getAttribute("data-precedence"),u=i.get(g)||s,u===s&&i.set(null,l),i.set(g,l),this.count++,s=Jo.bind(this),l.addEventListener("load",s),l.addEventListener("error",s),u?u.parentNode.insertBefore(l,u.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(l,t.firstChild)),n.state.loading|=4}}var zr={$$typeof:ut,Provider:null,Consumer:null,_currentValue:I,_currentValue2:I,_threadCount:0};function DM(t,n,i,s,l,u,g,E,O){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=ho(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=ho(0),this.hiddenUpdates=ho(null),this.identifierPrefix=s,this.onUncaughtError=l,this.onCaughtError=u,this.onRecoverableError=g,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=O,this.transitionTypes=null,this.incompleteTransitions=new Map}function F_(t,n,i,s,l,u,g,E,O,Y,at,mt){return t=new DM(t,n,i,g,O,Y,at,mt,E),n=1,u===!0&&(n|=24),u=kn(3,null,null,n),t.current=u,u.stateNode=t,n=uf(),n.refCount++,t.pooledCache=n,n.refCount++,u.memoizedState={element:s,isDehydrated:i,cache:n},pf(u),t}function H_(t){return t?(t=or,t):or}function G_(t,n,i,s,l,u){l=H_(l),s.context===null?s.context=l:s.pendingContext=l,s=za(n),s.payload={element:i},u=u===void 0?null:u,u!==null&&(s.callback=u),i=Pa(t,s,n),i!==null&&(Yn(i,t,n),wo(i,t,n))}function V_(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var i=t.retryLane;t.retryLane=i!==0&&i<n?i:n}}function Kh(t,n){V_(t,n),(t=t.alternate)&&V_(t,n)}function k_(t){if(t.tag===13||t.tag===31){var n=_s(t,67108864);n!==null&&Yn(n,t,67108864),Kh(t,67108864)}}function X_(t){if(t.tag===13||t.tag===31){var n=si();n=lt(n);var i=_s(t,n);i!==null&&Yn(i,t,n),Kh(t,n)}}var Pr=!0;function NM(t,n,i,s){var l=Et.T;Et.T=null;var u=qt.p;try{qt.p=2,Qh(t,n,i,s)}finally{qt.p=u,Et.T=l}}function UM(t,n,i,s){var l=Et.T;Et.T=null;var u=qt.p;try{qt.p=8,Qh(t,n,i,s)}finally{qt.p=u,Et.T=l}}function Qh(t,n,i,s){if(Pr){var l=Jh(s);if(l===null)Uh(t,n,s,Bc,i),q_(t,s);else if(OM(l,t,n,i,s))s.stopPropagation();else if(q_(t,s),n&4&&-1<LM.indexOf(t)){for(;l!==null;){var u=me(l);if(u!==null)switch(u.tag){case 3:if(u=u.stateNode,u.current.memoizedState.isDehydrated){var g=fi(u.pendingLanes);if(g!==0){var E=u;for(E.pendingLanes|=2,E.entangledLanes|=2;g;){var O=1<<31-Un(g);E.entanglements[1]|=O,g&=~O}Wi(u),(ze&6)===0&&(Ec=X()+500,jo(0))}}break;case 31:case 13:E=_s(u,2),E!==null&&Yn(E,u,2),Ac(),Kh(u,2)}if(u=Jh(s),u===null&&Uh(t,n,s,Bc,i),u===l)break;l=u}l!==null&&s.stopPropagation()}else Uh(t,n,s,null,i)}}function Jh(t){return t=Pu(t),$h(t)}var Bc=null;function $h(t){if(Bc=null,t=Oe(t),t!==null){var n=f(t);if(n===null)t=null;else{var i=n.tag;if(i===13){if(t=h(n),t!==null)return t;t=null}else if(i===31){if(t=d(n),t!==null)return t;t=null}else if(i===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return Bc=t,null}function j_(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(At()){case Dt:return 2;case Vt:return 8;case St:case _t:return 32;case Yt:return 268435456;default:return 32}default:return 32}}var td=!1,Wa=null,Za=null,Ka=null,$o=new Map,tl=new Map,Qa=[],LM="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function q_(t,n){switch(t){case"focusin":case"focusout":Wa=null;break;case"dragenter":case"dragleave":Za=null;break;case"mouseover":case"mouseout":Ka=null;break;case"pointerover":case"pointerout":$o.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":tl.delete(n.pointerId)}}function el(t,n,i,s,l,u){return t===null||t.nativeEvent!==u?(t={blockedOn:n,domEventName:i,eventSystemFlags:s,nativeEvent:u,targetContainers:[l]},n!==null&&(n=me(n),n!==null&&k_(n)),t):(t.eventSystemFlags|=s,n=t.targetContainers,l!==null&&n.indexOf(l)===-1&&n.push(l),t)}function OM(t,n,i,s,l){switch(n){case"focusin":return Wa=el(Wa,t,n,i,s,l),!0;case"dragenter":return Za=el(Za,t,n,i,s,l),!0;case"mouseover":return Ka=el(Ka,t,n,i,s,l),!0;case"pointerover":var u=l.pointerId;return $o.set(u,el($o.get(u)||null,t,n,i,s,l)),!0;case"gotpointercapture":return u=l.pointerId,tl.set(u,el(tl.get(u)||null,t,n,i,s,l)),!0}return!1}function Y_(t){var n=Oe(t.target);if(n!==null){var i=f(n);if(i!==null){if(n=i.tag,n===13){if(n=h(i),n!==null){t.blockedOn=n,Pt(t.priority,function(){X_(i)});return}}else if(n===31){if(n=d(i),n!==null){t.blockedOn=n,Pt(t.priority,function(){X_(i)});return}}else if(n===3&&i.stateNode.current.memoizedState.isDehydrated){t.blockedOn=i.tag===3?i.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Fc(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var i=Jh(t.nativeEvent);if(i===null){i=t.nativeEvent;var s=new i.constructor(i.type,i);zu=s,i.target.dispatchEvent(s),zu=null}else return n=me(i),n!==null&&k_(n),t.blockedOn=i,!1;n.shift()}return!0}function W_(t,n,i){Fc(t)&&i.delete(n)}function zM(){td=!1,Wa!==null&&Fc(Wa)&&(Wa=null),Za!==null&&Fc(Za)&&(Za=null),Ka!==null&&Fc(Ka)&&(Ka=null),$o.forEach(W_),tl.forEach(W_)}function Hc(t,n){t.blockedOn===n&&(t.blockedOn=null,td||(td=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,zM)))}var Gc=null;function Z_(t){Gc!==t&&(Gc=t,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){Gc===t&&(Gc=null);for(var n=0;n<t.length;n+=3){var i=t[n],s=t[n+1],l=t[n+2];if(typeof s!="function"){if($h(s||i)===null)continue;break}var u=me(i);u!==null&&(t.splice(n,3),n-=3,zf(u,{pending:!0,data:l,method:i.method,action:s},s,l))}}))}function Ir(t){function n(O){return Hc(O,t)}Wa!==null&&Hc(Wa,t),Za!==null&&Hc(Za,t),Ka!==null&&Hc(Ka,t),$o.forEach(n),tl.forEach(n);for(var i=0;i<Qa.length;i++){var s=Qa[i];s.blockedOn===t&&(s.blockedOn=null)}for(;0<Qa.length&&(i=Qa[0],i.blockedOn===null);)Y_(i),i.blockedOn===null&&Qa.shift();if(i=(t.ownerDocument||t).$$reactFormReplay,i!=null)for(s=0;s<i.length;s+=3){var l=i[s],u=i[s+1],g=l[Xt]||null;if(typeof u=="function")g||Z_(i);else if(g){var E=null;if(u&&u.hasAttribute("formAction")){if(l=u,g=u[Xt]||null)E=g.formAction;else if($h(l)!==null)continue}else E=g.action;typeof E=="function"?i[s+1]=E:(i.splice(s,3),s-=3),Z_(i)}}}function K_(){function t(u){u.canIntercept&&u.info==="react-transition"&&u.intercept({handler:function(){return new Promise(function(g){return l=g})},focusReset:"manual",scroll:"manual"})}function n(){l!==null&&(l(),l=null),s||setTimeout(i,20)}function i(){if(!s&&!navigation.transition){var u=navigation.currentEntry;u&&u.url!=null&&navigation.navigate(u.url,{state:u.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var s=!1,l=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(i,100),function(){s=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),l!==null&&(l(),l=null)}}}function ed(t){this._internalRoot=t}Vc.prototype.render=ed.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(r(409));var i=n.current,s=si();G_(i,s,t,n,null,null)},Vc.prototype.unmount=ed.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;G_(t.current,2,null,t,null,null),Ac(),n[ee]=null}};function Vc(t){this._internalRoot=t}Vc.prototype.unstable_scheduleHydration=function(t){if(t){var n=Tt();t={blockedOn:null,target:t,priority:n};for(var i=0;i<Qa.length&&n!==0&&n<Qa[i].priority;i++);Qa.splice(i,0,t),i===0&&Y_(t)}};var Q_=e.version;if(Q_!=="19.3.0")throw Error(r(527,Q_,"19.3.0"));qt.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(r(188)):(t=Object.keys(t).join(","),Error(r(268,t)));return t=m(n),t=t!==null?x(t):null,t=t===null?null:t.stateNode,t};var PM={bundleType:0,version:"19.3.0",rendererPackageName:"react-dom",currentDispatcherRef:Et,reconcilerVersion:"19.3.0"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var kc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!kc.isDisabled&&kc.supportsFiber)try{Se=kc.inject(PM),en=kc}catch{}}return il.createRoot=function(t,n){if(!c(t))throw Error(r(299));var i=!1,s="",l=Hg,u=Gg,g=Vg;return n!=null&&(n.unstable_strictMode===!0&&(i=!0),n.identifierPrefix!==void 0&&(s=n.identifierPrefix),n.onUncaughtError!==void 0&&(l=n.onUncaughtError),n.onCaughtError!==void 0&&(u=n.onCaughtError),n.onRecoverableError!==void 0&&(g=n.onRecoverableError)),n=F_(t,1,!1,null,null,i,s,null,l,u,g,K_),t[ee]=n.current,Nh(t),new ed(n)},il.hydrateRoot=function(t,n,i){if(!c(t))throw Error(r(299));var s=!1,l="",u=Hg,g=Gg,E=Vg,O=null;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(l=i.identifierPrefix),i.onUncaughtError!==void 0&&(u=i.onUncaughtError),i.onCaughtError!==void 0&&(g=i.onCaughtError),i.onRecoverableError!==void 0&&(E=i.onRecoverableError),i.formState!==void 0&&(O=i.formState)),n=F_(t,1,!0,n,i??null,s,l,O,u,g,E,K_),n.context=H_(null),i=n.current,s=si(),s=lt(s),l=za(s),l.callback=null,Pa(i,l,s),i=s,n.current.lanes=i,ps(n,i),Wi(n),t[ee]=n.current,Nh(t),new Vc(n)},il.version="19.3.0",il}var ov;function qM(){if(ov)return ad.exports;ov=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),ad.exports=jM(),ad.exports}var YM=qM();const Lp="180",WM=0,lv=1,ZM=2,hx=1,KM=2,Sa=3,cs=0,Kn=1,Ma=2,rs=0,to=1,cv=2,uv=3,fv=4,QM=5,ks=100,JM=101,$M=102,tE=103,eE=104,nE=200,iE=201,aE=202,sE=203,Gd=204,Vd=205,rE=206,oE=207,lE=208,cE=209,uE=210,fE=211,hE=212,dE=213,pE=214,kd=0,Xd=1,jd=2,no=3,qd=4,Yd=5,Wd=6,Zd=7,dx=0,mE=1,gE=2,os=0,_E=1,vE=2,xE=3,Op=4,yE=5,SE=6,ME=7,px=300,io=301,ao=302,Kd=303,Qd=304,Tu=306,Jd=1e3,js=1001,$d=1002,Oi=1003,EE=1004,Xc=1005,Ki=1006,ld=1007,qs=1008,Ji=1009,mx=1010,gx=1011,fl=1012,zp=1013,Zs=1014,Ea=1015,_l=1016,Pp=1017,Ip=1018,hl=1020,_x=35902,vx=35899,xx=1021,yx=1022,Li=1023,dl=1026,pl=1027,Sx=1028,Bp=1029,Mx=1030,Fp=1031,Hp=1033,pu=33776,mu=33777,gu=33778,_u=33779,tp=35840,ep=35841,np=35842,ip=35843,ap=36196,sp=37492,rp=37496,op=37808,lp=37809,cp=37810,up=37811,fp=37812,hp=37813,dp=37814,pp=37815,mp=37816,gp=37817,_p=37818,vp=37819,xp=37820,yp=37821,Sp=36492,Mp=36494,Ep=36495,Tp=36283,bp=36284,Ap=36285,Rp=36286,TE=3200,bE=3201,Ex=0,AE=1,ss="",Mi="srgb",so="srgb-linear",xu="linear",Xe="srgb",Br=7680,hv=519,RE=512,CE=513,wE=514,Tx=515,DE=516,NE=517,UE=518,LE=519,dv=35044,pv="300 es",Qi=2e3,yu=2001;class oo{addEventListener(e,a){this._listeners===void 0&&(this._listeners={});const r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(a)===-1&&r[e].push(a)}hasEventListener(e,a){const r=this._listeners;return r===void 0?!1:r[e]!==void 0&&r[e].indexOf(a)!==-1}removeEventListener(e,a){const r=this._listeners;if(r===void 0)return;const c=r[e];if(c!==void 0){const f=c.indexOf(a);f!==-1&&c.splice(f,1)}}dispatchEvent(e){const a=this._listeners;if(a===void 0)return;const r=a[e.type];if(r!==void 0){e.target=this;const c=r.slice(0);for(let f=0,h=c.length;f<h;f++)c[f].call(this,e);e.target=null}}}const zn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],cd=Math.PI/180,Cp=180/Math.PI;function vl(){const o=Math.random()*4294967295|0,e=Math.random()*4294967295|0,a=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(zn[o&255]+zn[o>>8&255]+zn[o>>16&255]+zn[o>>24&255]+"-"+zn[e&255]+zn[e>>8&255]+"-"+zn[e>>16&15|64]+zn[e>>24&255]+"-"+zn[a&63|128]+zn[a>>8&255]+"-"+zn[a>>16&255]+zn[a>>24&255]+zn[r&255]+zn[r>>8&255]+zn[r>>16&255]+zn[r>>24&255]).toLowerCase()}function be(o,e,a){return Math.max(e,Math.min(a,o))}function OE(o,e){return(o%e+e)%e}function ud(o,e,a){return(1-a)*o+a*e}function al(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function Wn(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class Ue{constructor(e=0,a=0){Ue.prototype.isVector2=!0,this.x=e,this.y=a}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,a){return this.x=e,this.y=a,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,a){switch(e){case 0:this.x=a;break;case 1:this.y=a;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,a){return this.x=e.x+a.x,this.y=e.y+a.y,this}addScaledVector(e,a){return this.x+=e.x*a,this.y+=e.y*a,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,a){return this.x=e.x-a.x,this.y=e.y-a.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const a=this.x,r=this.y,c=e.elements;return this.x=c[0]*a+c[3]*r+c[6],this.y=c[1]*a+c[4]*r+c[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,a){return this.x=be(this.x,e.x,a.x),this.y=be(this.y,e.y,a.y),this}clampScalar(e,a){return this.x=be(this.x,e,a),this.y=be(this.y,e,a),this}clampLength(e,a){const r=this.length();return this.divideScalar(r||1).multiplyScalar(be(r,e,a))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const a=Math.sqrt(this.lengthSq()*e.lengthSq());if(a===0)return Math.PI/2;const r=this.dot(e)/a;return Math.acos(be(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const a=this.x-e.x,r=this.y-e.y;return a*a+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,a){return this.x+=(e.x-this.x)*a,this.y+=(e.y-this.y)*a,this}lerpVectors(e,a,r){return this.x=e.x+(a.x-e.x)*r,this.y=e.y+(a.y-e.y)*r,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,a=0){return this.x=e[a],this.y=e[a+1],this}toArray(e=[],a=0){return e[a]=this.x,e[a+1]=this.y,e}fromBufferAttribute(e,a){return this.x=e.getX(a),this.y=e.getY(a),this}rotateAround(e,a){const r=Math.cos(a),c=Math.sin(a),f=this.x-e.x,h=this.y-e.y;return this.x=f*r-h*c+e.x,this.y=f*c+h*r+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class xl{constructor(e=0,a=0,r=0,c=1){this.isQuaternion=!0,this._x=e,this._y=a,this._z=r,this._w=c}static slerpFlat(e,a,r,c,f,h,d){let _=r[c+0],m=r[c+1],x=r[c+2],p=r[c+3];const y=f[h+0],M=f[h+1],b=f[h+2],D=f[h+3];if(d===0){e[a+0]=_,e[a+1]=m,e[a+2]=x,e[a+3]=p;return}if(d===1){e[a+0]=y,e[a+1]=M,e[a+2]=b,e[a+3]=D;return}if(p!==D||_!==y||m!==M||x!==b){let S=1-d;const v=_*y+m*M+x*b+p*D,L=v>=0?1:-1,z=1-v*v;if(z>Number.EPSILON){const H=Math.sqrt(z),F=Math.atan2(H,v*L);S=Math.sin(S*F)/H,d=Math.sin(d*F)/H}const N=d*L;if(_=_*S+y*N,m=m*S+M*N,x=x*S+b*N,p=p*S+D*N,S===1-d){const H=1/Math.sqrt(_*_+m*m+x*x+p*p);_*=H,m*=H,x*=H,p*=H}}e[a]=_,e[a+1]=m,e[a+2]=x,e[a+3]=p}static multiplyQuaternionsFlat(e,a,r,c,f,h){const d=r[c],_=r[c+1],m=r[c+2],x=r[c+3],p=f[h],y=f[h+1],M=f[h+2],b=f[h+3];return e[a]=d*b+x*p+_*M-m*y,e[a+1]=_*b+x*y+m*p-d*M,e[a+2]=m*b+x*M+d*y-_*p,e[a+3]=x*b-d*p-_*y-m*M,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,a,r,c){return this._x=e,this._y=a,this._z=r,this._w=c,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,a=!0){const r=e._x,c=e._y,f=e._z,h=e._order,d=Math.cos,_=Math.sin,m=d(r/2),x=d(c/2),p=d(f/2),y=_(r/2),M=_(c/2),b=_(f/2);switch(h){case"XYZ":this._x=y*x*p+m*M*b,this._y=m*M*p-y*x*b,this._z=m*x*b+y*M*p,this._w=m*x*p-y*M*b;break;case"YXZ":this._x=y*x*p+m*M*b,this._y=m*M*p-y*x*b,this._z=m*x*b-y*M*p,this._w=m*x*p+y*M*b;break;case"ZXY":this._x=y*x*p-m*M*b,this._y=m*M*p+y*x*b,this._z=m*x*b+y*M*p,this._w=m*x*p-y*M*b;break;case"ZYX":this._x=y*x*p-m*M*b,this._y=m*M*p+y*x*b,this._z=m*x*b-y*M*p,this._w=m*x*p+y*M*b;break;case"YZX":this._x=y*x*p+m*M*b,this._y=m*M*p+y*x*b,this._z=m*x*b-y*M*p,this._w=m*x*p-y*M*b;break;case"XZY":this._x=y*x*p-m*M*b,this._y=m*M*p-y*x*b,this._z=m*x*b+y*M*p,this._w=m*x*p+y*M*b;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+h)}return a===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,a){const r=a/2,c=Math.sin(r);return this._x=e.x*c,this._y=e.y*c,this._z=e.z*c,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){const a=e.elements,r=a[0],c=a[4],f=a[8],h=a[1],d=a[5],_=a[9],m=a[2],x=a[6],p=a[10],y=r+d+p;if(y>0){const M=.5/Math.sqrt(y+1);this._w=.25/M,this._x=(x-_)*M,this._y=(f-m)*M,this._z=(h-c)*M}else if(r>d&&r>p){const M=2*Math.sqrt(1+r-d-p);this._w=(x-_)/M,this._x=.25*M,this._y=(c+h)/M,this._z=(f+m)/M}else if(d>p){const M=2*Math.sqrt(1+d-r-p);this._w=(f-m)/M,this._x=(c+h)/M,this._y=.25*M,this._z=(_+x)/M}else{const M=2*Math.sqrt(1+p-r-d);this._w=(h-c)/M,this._x=(f+m)/M,this._y=(_+x)/M,this._z=.25*M}return this._onChangeCallback(),this}setFromUnitVectors(e,a){let r=e.dot(a)+1;return r<1e-8?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*a.z-e.z*a.y,this._y=e.z*a.x-e.x*a.z,this._z=e.x*a.y-e.y*a.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(be(this.dot(e),-1,1)))}rotateTowards(e,a){const r=this.angleTo(e);if(r===0)return this;const c=Math.min(1,a/r);return this.slerp(e,c),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,a){const r=e._x,c=e._y,f=e._z,h=e._w,d=a._x,_=a._y,m=a._z,x=a._w;return this._x=r*x+h*d+c*m-f*_,this._y=c*x+h*_+f*d-r*m,this._z=f*x+h*m+r*_-c*d,this._w=h*x-r*d-c*_-f*m,this._onChangeCallback(),this}slerp(e,a){if(a===0)return this;if(a===1)return this.copy(e);const r=this._x,c=this._y,f=this._z,h=this._w;let d=h*e._w+r*e._x+c*e._y+f*e._z;if(d<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,d=-d):this.copy(e),d>=1)return this._w=h,this._x=r,this._y=c,this._z=f,this;const _=1-d*d;if(_<=Number.EPSILON){const M=1-a;return this._w=M*h+a*this._w,this._x=M*r+a*this._x,this._y=M*c+a*this._y,this._z=M*f+a*this._z,this.normalize(),this}const m=Math.sqrt(_),x=Math.atan2(m,d),p=Math.sin((1-a)*x)/m,y=Math.sin(a*x)/m;return this._w=h*p+this._w*y,this._x=r*p+this._x*y,this._y=c*p+this._y*y,this._z=f*p+this._z*y,this._onChangeCallback(),this}slerpQuaternions(e,a,r){return this.copy(e).slerp(a,r)}random(){const e=2*Math.PI*Math.random(),a=2*Math.PI*Math.random(),r=Math.random(),c=Math.sqrt(1-r),f=Math.sqrt(r);return this.set(c*Math.sin(e),c*Math.cos(e),f*Math.sin(a),f*Math.cos(a))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,a=0){return this._x=e[a],this._y=e[a+1],this._z=e[a+2],this._w=e[a+3],this._onChangeCallback(),this}toArray(e=[],a=0){return e[a]=this._x,e[a+1]=this._y,e[a+2]=this._z,e[a+3]=this._w,e}fromBufferAttribute(e,a){return this._x=e.getX(a),this._y=e.getY(a),this._z=e.getZ(a),this._w=e.getW(a),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class et{constructor(e=0,a=0,r=0){et.prototype.isVector3=!0,this.x=e,this.y=a,this.z=r}set(e,a,r){return r===void 0&&(r=this.z),this.x=e,this.y=a,this.z=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,a){switch(e){case 0:this.x=a;break;case 1:this.y=a;break;case 2:this.z=a;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,a){return this.x=e.x+a.x,this.y=e.y+a.y,this.z=e.z+a.z,this}addScaledVector(e,a){return this.x+=e.x*a,this.y+=e.y*a,this.z+=e.z*a,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,a){return this.x=e.x-a.x,this.y=e.y-a.y,this.z=e.z-a.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,a){return this.x=e.x*a.x,this.y=e.y*a.y,this.z=e.z*a.z,this}applyEuler(e){return this.applyQuaternion(mv.setFromEuler(e))}applyAxisAngle(e,a){return this.applyQuaternion(mv.setFromAxisAngle(e,a))}applyMatrix3(e){const a=this.x,r=this.y,c=this.z,f=e.elements;return this.x=f[0]*a+f[3]*r+f[6]*c,this.y=f[1]*a+f[4]*r+f[7]*c,this.z=f[2]*a+f[5]*r+f[8]*c,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const a=this.x,r=this.y,c=this.z,f=e.elements,h=1/(f[3]*a+f[7]*r+f[11]*c+f[15]);return this.x=(f[0]*a+f[4]*r+f[8]*c+f[12])*h,this.y=(f[1]*a+f[5]*r+f[9]*c+f[13])*h,this.z=(f[2]*a+f[6]*r+f[10]*c+f[14])*h,this}applyQuaternion(e){const a=this.x,r=this.y,c=this.z,f=e.x,h=e.y,d=e.z,_=e.w,m=2*(h*c-d*r),x=2*(d*a-f*c),p=2*(f*r-h*a);return this.x=a+_*m+h*p-d*x,this.y=r+_*x+d*m-f*p,this.z=c+_*p+f*x-h*m,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const a=this.x,r=this.y,c=this.z,f=e.elements;return this.x=f[0]*a+f[4]*r+f[8]*c,this.y=f[1]*a+f[5]*r+f[9]*c,this.z=f[2]*a+f[6]*r+f[10]*c,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,a){return this.x=be(this.x,e.x,a.x),this.y=be(this.y,e.y,a.y),this.z=be(this.z,e.z,a.z),this}clampScalar(e,a){return this.x=be(this.x,e,a),this.y=be(this.y,e,a),this.z=be(this.z,e,a),this}clampLength(e,a){const r=this.length();return this.divideScalar(r||1).multiplyScalar(be(r,e,a))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,a){return this.x+=(e.x-this.x)*a,this.y+=(e.y-this.y)*a,this.z+=(e.z-this.z)*a,this}lerpVectors(e,a,r){return this.x=e.x+(a.x-e.x)*r,this.y=e.y+(a.y-e.y)*r,this.z=e.z+(a.z-e.z)*r,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,a){const r=e.x,c=e.y,f=e.z,h=a.x,d=a.y,_=a.z;return this.x=c*_-f*d,this.y=f*h-r*_,this.z=r*d-c*h,this}projectOnVector(e){const a=e.lengthSq();if(a===0)return this.set(0,0,0);const r=e.dot(this)/a;return this.copy(e).multiplyScalar(r)}projectOnPlane(e){return fd.copy(this).projectOnVector(e),this.sub(fd)}reflect(e){return this.sub(fd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const a=Math.sqrt(this.lengthSq()*e.lengthSq());if(a===0)return Math.PI/2;const r=this.dot(e)/a;return Math.acos(be(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const a=this.x-e.x,r=this.y-e.y,c=this.z-e.z;return a*a+r*r+c*c}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,a,r){const c=Math.sin(a)*e;return this.x=c*Math.sin(r),this.y=Math.cos(a)*e,this.z=c*Math.cos(r),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,a,r){return this.x=e*Math.sin(a),this.y=r,this.z=e*Math.cos(a),this}setFromMatrixPosition(e){const a=e.elements;return this.x=a[12],this.y=a[13],this.z=a[14],this}setFromMatrixScale(e){const a=this.setFromMatrixColumn(e,0).length(),r=this.setFromMatrixColumn(e,1).length(),c=this.setFromMatrixColumn(e,2).length();return this.x=a,this.y=r,this.z=c,this}setFromMatrixColumn(e,a){return this.fromArray(e.elements,a*4)}setFromMatrix3Column(e,a){return this.fromArray(e.elements,a*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,a=0){return this.x=e[a],this.y=e[a+1],this.z=e[a+2],this}toArray(e=[],a=0){return e[a]=this.x,e[a+1]=this.y,e[a+2]=this.z,e}fromBufferAttribute(e,a){return this.x=e.getX(a),this.y=e.getY(a),this.z=e.getZ(a),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,a=Math.random()*2-1,r=Math.sqrt(1-a*a);return this.x=r*Math.cos(e),this.y=a,this.z=r*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const fd=new et,mv=new xl;class de{constructor(e,a,r,c,f,h,d,_,m){de.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,a,r,c,f,h,d,_,m)}set(e,a,r,c,f,h,d,_,m){const x=this.elements;return x[0]=e,x[1]=c,x[2]=d,x[3]=a,x[4]=f,x[5]=_,x[6]=r,x[7]=h,x[8]=m,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const a=this.elements,r=e.elements;return a[0]=r[0],a[1]=r[1],a[2]=r[2],a[3]=r[3],a[4]=r[4],a[5]=r[5],a[6]=r[6],a[7]=r[7],a[8]=r[8],this}extractBasis(e,a,r){return e.setFromMatrix3Column(this,0),a.setFromMatrix3Column(this,1),r.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const a=e.elements;return this.set(a[0],a[4],a[8],a[1],a[5],a[9],a[2],a[6],a[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,a){const r=e.elements,c=a.elements,f=this.elements,h=r[0],d=r[3],_=r[6],m=r[1],x=r[4],p=r[7],y=r[2],M=r[5],b=r[8],D=c[0],S=c[3],v=c[6],L=c[1],z=c[4],N=c[7],H=c[2],F=c[5],P=c[8];return f[0]=h*D+d*L+_*H,f[3]=h*S+d*z+_*F,f[6]=h*v+d*N+_*P,f[1]=m*D+x*L+p*H,f[4]=m*S+x*z+p*F,f[7]=m*v+x*N+p*P,f[2]=y*D+M*L+b*H,f[5]=y*S+M*z+b*F,f[8]=y*v+M*N+b*P,this}multiplyScalar(e){const a=this.elements;return a[0]*=e,a[3]*=e,a[6]*=e,a[1]*=e,a[4]*=e,a[7]*=e,a[2]*=e,a[5]*=e,a[8]*=e,this}determinant(){const e=this.elements,a=e[0],r=e[1],c=e[2],f=e[3],h=e[4],d=e[5],_=e[6],m=e[7],x=e[8];return a*h*x-a*d*m-r*f*x+r*d*_+c*f*m-c*h*_}invert(){const e=this.elements,a=e[0],r=e[1],c=e[2],f=e[3],h=e[4],d=e[5],_=e[6],m=e[7],x=e[8],p=x*h-d*m,y=d*_-x*f,M=m*f-h*_,b=a*p+r*y+c*M;if(b===0)return this.set(0,0,0,0,0,0,0,0,0);const D=1/b;return e[0]=p*D,e[1]=(c*m-x*r)*D,e[2]=(d*r-c*h)*D,e[3]=y*D,e[4]=(x*a-c*_)*D,e[5]=(c*f-d*a)*D,e[6]=M*D,e[7]=(r*_-m*a)*D,e[8]=(h*a-r*f)*D,this}transpose(){let e;const a=this.elements;return e=a[1],a[1]=a[3],a[3]=e,e=a[2],a[2]=a[6],a[6]=e,e=a[5],a[5]=a[7],a[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const a=this.elements;return e[0]=a[0],e[1]=a[3],e[2]=a[6],e[3]=a[1],e[4]=a[4],e[5]=a[7],e[6]=a[2],e[7]=a[5],e[8]=a[8],this}setUvTransform(e,a,r,c,f,h,d){const _=Math.cos(f),m=Math.sin(f);return this.set(r*_,r*m,-r*(_*h+m*d)+h+e,-c*m,c*_,-c*(-m*h+_*d)+d+a,0,0,1),this}scale(e,a){return this.premultiply(hd.makeScale(e,a)),this}rotate(e){return this.premultiply(hd.makeRotation(-e)),this}translate(e,a){return this.premultiply(hd.makeTranslation(e,a)),this}makeTranslation(e,a){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,a,0,0,1),this}makeRotation(e){const a=Math.cos(e),r=Math.sin(e);return this.set(a,-r,0,r,a,0,0,0,1),this}makeScale(e,a){return this.set(e,0,0,0,a,0,0,0,1),this}equals(e){const a=this.elements,r=e.elements;for(let c=0;c<9;c++)if(a[c]!==r[c])return!1;return!0}fromArray(e,a=0){for(let r=0;r<9;r++)this.elements[r]=e[r+a];return this}toArray(e=[],a=0){const r=this.elements;return e[a]=r[0],e[a+1]=r[1],e[a+2]=r[2],e[a+3]=r[3],e[a+4]=r[4],e[a+5]=r[5],e[a+6]=r[6],e[a+7]=r[7],e[a+8]=r[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const hd=new de;function bx(o){for(let e=o.length-1;e>=0;--e)if(o[e]>=65535)return!0;return!1}function Su(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function zE(){const o=Su("canvas");return o.style.display="block",o}const gv={};function ml(o){o in gv||(gv[o]=!0,console.warn(o))}function PE(o,e,a){return new Promise(function(r,c){function f(){switch(o.clientWaitSync(e,o.SYNC_FLUSH_COMMANDS_BIT,0)){case o.WAIT_FAILED:c();break;case o.TIMEOUT_EXPIRED:setTimeout(f,a);break;default:r()}}setTimeout(f,a)})}const _v=new de().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),vv=new de().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function IE(){const o={enabled:!0,workingColorSpace:so,spaces:{},convert:function(c,f,h){return this.enabled===!1||f===h||!f||!h||(this.spaces[f].transfer===Xe&&(c.r=Ta(c.r),c.g=Ta(c.g),c.b=Ta(c.b)),this.spaces[f].primaries!==this.spaces[h].primaries&&(c.applyMatrix3(this.spaces[f].toXYZ),c.applyMatrix3(this.spaces[h].fromXYZ)),this.spaces[h].transfer===Xe&&(c.r=eo(c.r),c.g=eo(c.g),c.b=eo(c.b))),c},workingToColorSpace:function(c,f){return this.convert(c,this.workingColorSpace,f)},colorSpaceToWorking:function(c,f){return this.convert(c,f,this.workingColorSpace)},getPrimaries:function(c){return this.spaces[c].primaries},getTransfer:function(c){return c===ss?xu:this.spaces[c].transfer},getToneMappingMode:function(c){return this.spaces[c].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(c,f=this.workingColorSpace){return c.fromArray(this.spaces[f].luminanceCoefficients)},define:function(c){Object.assign(this.spaces,c)},_getMatrix:function(c,f,h){return c.copy(this.spaces[f].toXYZ).multiply(this.spaces[h].fromXYZ)},_getDrawingBufferColorSpace:function(c){return this.spaces[c].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(c=this.workingColorSpace){return this.spaces[c].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(c,f){return ml("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),o.workingToColorSpace(c,f)},toWorkingColorSpace:function(c,f){return ml("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),o.colorSpaceToWorking(c,f)}},e=[.64,.33,.3,.6,.15,.06],a=[.2126,.7152,.0722],r=[.3127,.329];return o.define({[so]:{primaries:e,whitePoint:r,transfer:xu,toXYZ:_v,fromXYZ:vv,luminanceCoefficients:a,workingColorSpaceConfig:{unpackColorSpace:Mi},outputColorSpaceConfig:{drawingBufferColorSpace:Mi}},[Mi]:{primaries:e,whitePoint:r,transfer:Xe,toXYZ:_v,fromXYZ:vv,luminanceCoefficients:a,outputColorSpaceConfig:{drawingBufferColorSpace:Mi}}}),o}const Ne=IE();function Ta(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function eo(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Fr;class BE{static getDataURL(e,a="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let r;if(e instanceof HTMLCanvasElement)r=e;else{Fr===void 0&&(Fr=Su("canvas")),Fr.width=e.width,Fr.height=e.height;const c=Fr.getContext("2d");e instanceof ImageData?c.putImageData(e,0,0):c.drawImage(e,0,0,e.width,e.height),r=Fr}return r.toDataURL(a)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const a=Su("canvas");a.width=e.width,a.height=e.height;const r=a.getContext("2d");r.drawImage(e,0,0,e.width,e.height);const c=r.getImageData(0,0,e.width,e.height),f=c.data;for(let h=0;h<f.length;h++)f[h]=Ta(f[h]/255)*255;return r.putImageData(c,0,0),a}else if(e.data){const a=e.data.slice(0);for(let r=0;r<a.length;r++)a instanceof Uint8Array||a instanceof Uint8ClampedArray?a[r]=Math.floor(Ta(a[r]/255)*255):a[r]=Ta(a[r]);return{data:a,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let FE=0;class Gp{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:FE++}),this.uuid=vl(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const a=this.data;return typeof HTMLVideoElement<"u"&&a instanceof HTMLVideoElement?e.set(a.videoWidth,a.videoHeight,0):a instanceof VideoFrame?e.set(a.displayHeight,a.displayWidth,0):a!==null?e.set(a.width,a.height,a.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const a=e===void 0||typeof e=="string";if(!a&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const r={uuid:this.uuid,url:""},c=this.data;if(c!==null){let f;if(Array.isArray(c)){f=[];for(let h=0,d=c.length;h<d;h++)c[h].isDataTexture?f.push(dd(c[h].image)):f.push(dd(c[h]))}else f=dd(c);r.url=f}return a||(e.images[this.uuid]=r),r}}function dd(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?BE.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let HE=0;const pd=new et;class Qn extends oo{constructor(e=Qn.DEFAULT_IMAGE,a=Qn.DEFAULT_MAPPING,r=js,c=js,f=Ki,h=qs,d=Li,_=Ji,m=Qn.DEFAULT_ANISOTROPY,x=ss){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:HE++}),this.uuid=vl(),this.name="",this.source=new Gp(e),this.mipmaps=[],this.mapping=a,this.channel=0,this.wrapS=r,this.wrapT=c,this.magFilter=f,this.minFilter=h,this.anisotropy=m,this.format=d,this.internalFormat=null,this.type=_,this.offset=new Ue(0,0),this.repeat=new Ue(1,1),this.center=new Ue(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new de,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=x,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(pd).x}get height(){return this.source.getSize(pd).y}get depth(){return this.source.getSize(pd).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,a){this.updateRanges.push({start:e,count:a})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const a in e){const r=e[a];if(r===void 0){console.warn(`THREE.Texture.setValues(): parameter '${a}' has value of undefined.`);continue}const c=this[a];if(c===void 0){console.warn(`THREE.Texture.setValues(): property '${a}' does not exist.`);continue}c&&r&&c.isVector2&&r.isVector2||c&&r&&c.isVector3&&r.isVector3||c&&r&&c.isMatrix3&&r.isMatrix3?c.copy(r):this[a]=r}}toJSON(e){const a=e===void 0||typeof e=="string";if(!a&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const r={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(r.userData=this.userData),a||(e.textures[this.uuid]=r),r}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==px)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Jd:e.x=e.x-Math.floor(e.x);break;case js:e.x=e.x<0?0:1;break;case $d:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Jd:e.y=e.y-Math.floor(e.y);break;case js:e.y=e.y<0?0:1;break;case $d:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Qn.DEFAULT_IMAGE=null;Qn.DEFAULT_MAPPING=px;Qn.DEFAULT_ANISOTROPY=1;class je{constructor(e=0,a=0,r=0,c=1){je.prototype.isVector4=!0,this.x=e,this.y=a,this.z=r,this.w=c}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,a,r,c){return this.x=e,this.y=a,this.z=r,this.w=c,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,a){switch(e){case 0:this.x=a;break;case 1:this.y=a;break;case 2:this.z=a;break;case 3:this.w=a;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,a){return this.x=e.x+a.x,this.y=e.y+a.y,this.z=e.z+a.z,this.w=e.w+a.w,this}addScaledVector(e,a){return this.x+=e.x*a,this.y+=e.y*a,this.z+=e.z*a,this.w+=e.w*a,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,a){return this.x=e.x-a.x,this.y=e.y-a.y,this.z=e.z-a.z,this.w=e.w-a.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const a=this.x,r=this.y,c=this.z,f=this.w,h=e.elements;return this.x=h[0]*a+h[4]*r+h[8]*c+h[12]*f,this.y=h[1]*a+h[5]*r+h[9]*c+h[13]*f,this.z=h[2]*a+h[6]*r+h[10]*c+h[14]*f,this.w=h[3]*a+h[7]*r+h[11]*c+h[15]*f,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const a=Math.sqrt(1-e.w*e.w);return a<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/a,this.y=e.y/a,this.z=e.z/a),this}setAxisAngleFromRotationMatrix(e){let a,r,c,f;const _=e.elements,m=_[0],x=_[4],p=_[8],y=_[1],M=_[5],b=_[9],D=_[2],S=_[6],v=_[10];if(Math.abs(x-y)<.01&&Math.abs(p-D)<.01&&Math.abs(b-S)<.01){if(Math.abs(x+y)<.1&&Math.abs(p+D)<.1&&Math.abs(b+S)<.1&&Math.abs(m+M+v-3)<.1)return this.set(1,0,0,0),this;a=Math.PI;const z=(m+1)/2,N=(M+1)/2,H=(v+1)/2,F=(x+y)/4,P=(p+D)/4,k=(b+S)/4;return z>N&&z>H?z<.01?(r=0,c=.707106781,f=.707106781):(r=Math.sqrt(z),c=F/r,f=P/r):N>H?N<.01?(r=.707106781,c=0,f=.707106781):(c=Math.sqrt(N),r=F/c,f=k/c):H<.01?(r=.707106781,c=.707106781,f=0):(f=Math.sqrt(H),r=P/f,c=k/f),this.set(r,c,f,a),this}let L=Math.sqrt((S-b)*(S-b)+(p-D)*(p-D)+(y-x)*(y-x));return Math.abs(L)<.001&&(L=1),this.x=(S-b)/L,this.y=(p-D)/L,this.z=(y-x)/L,this.w=Math.acos((m+M+v-1)/2),this}setFromMatrixPosition(e){const a=e.elements;return this.x=a[12],this.y=a[13],this.z=a[14],this.w=a[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,a){return this.x=be(this.x,e.x,a.x),this.y=be(this.y,e.y,a.y),this.z=be(this.z,e.z,a.z),this.w=be(this.w,e.w,a.w),this}clampScalar(e,a){return this.x=be(this.x,e,a),this.y=be(this.y,e,a),this.z=be(this.z,e,a),this.w=be(this.w,e,a),this}clampLength(e,a){const r=this.length();return this.divideScalar(r||1).multiplyScalar(be(r,e,a))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,a){return this.x+=(e.x-this.x)*a,this.y+=(e.y-this.y)*a,this.z+=(e.z-this.z)*a,this.w+=(e.w-this.w)*a,this}lerpVectors(e,a,r){return this.x=e.x+(a.x-e.x)*r,this.y=e.y+(a.y-e.y)*r,this.z=e.z+(a.z-e.z)*r,this.w=e.w+(a.w-e.w)*r,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,a=0){return this.x=e[a],this.y=e[a+1],this.z=e[a+2],this.w=e[a+3],this}toArray(e=[],a=0){return e[a]=this.x,e[a+1]=this.y,e[a+2]=this.z,e[a+3]=this.w,e}fromBufferAttribute(e,a){return this.x=e.getX(a),this.y=e.getY(a),this.z=e.getZ(a),this.w=e.getW(a),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class GE extends oo{constructor(e=1,a=1,r={}){super(),r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ki,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},r),this.isRenderTarget=!0,this.width=e,this.height=a,this.depth=r.depth,this.scissor=new je(0,0,e,a),this.scissorTest=!1,this.viewport=new je(0,0,e,a);const c={width:e,height:a,depth:r.depth},f=new Qn(c);this.textures=[];const h=r.count;for(let d=0;d<h;d++)this.textures[d]=f.clone(),this.textures[d].isRenderTargetTexture=!0,this.textures[d].renderTarget=this;this._setTextureOptions(r),this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=r.depthTexture,this.samples=r.samples,this.multiview=r.multiview}_setTextureOptions(e={}){const a={minFilter:Ki,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(a.mapping=e.mapping),e.wrapS!==void 0&&(a.wrapS=e.wrapS),e.wrapT!==void 0&&(a.wrapT=e.wrapT),e.wrapR!==void 0&&(a.wrapR=e.wrapR),e.magFilter!==void 0&&(a.magFilter=e.magFilter),e.minFilter!==void 0&&(a.minFilter=e.minFilter),e.format!==void 0&&(a.format=e.format),e.type!==void 0&&(a.type=e.type),e.anisotropy!==void 0&&(a.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(a.colorSpace=e.colorSpace),e.flipY!==void 0&&(a.flipY=e.flipY),e.generateMipmaps!==void 0&&(a.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(a.internalFormat=e.internalFormat);for(let r=0;r<this.textures.length;r++)this.textures[r].setValues(a)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,a,r=1){if(this.width!==e||this.height!==a||this.depth!==r){this.width=e,this.height=a,this.depth=r;for(let c=0,f=this.textures.length;c<f;c++)this.textures[c].image.width=e,this.textures[c].image.height=a,this.textures[c].image.depth=r,this.textures[c].isArrayTexture=this.textures[c].image.depth>1;this.dispose()}this.viewport.set(0,0,e,a),this.scissor.set(0,0,e,a)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let a=0,r=e.textures.length;a<r;a++){this.textures[a]=e.textures[a].clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;const c=Object.assign({},e.textures[a].image);this.textures[a].source=new Gp(c)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Ks extends GE{constructor(e=1,a=1,r={}){super(e,a,r),this.isWebGLRenderTarget=!0}}class Ax extends Qn{constructor(e=null,a=1,r=1,c=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:a,height:r,depth:c},this.magFilter=Oi,this.minFilter=Oi,this.wrapR=js,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class VE extends Qn{constructor(e=null,a=1,r=1,c=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:a,height:r,depth:c},this.magFilter=Oi,this.minFilter=Oi,this.wrapR=js,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class yl{constructor(e=new et(1/0,1/0,1/0),a=new et(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=a}set(e,a){return this.min.copy(e),this.max.copy(a),this}setFromArray(e){this.makeEmpty();for(let a=0,r=e.length;a<r;a+=3)this.expandByPoint(wi.fromArray(e,a));return this}setFromBufferAttribute(e){this.makeEmpty();for(let a=0,r=e.count;a<r;a++)this.expandByPoint(wi.fromBufferAttribute(e,a));return this}setFromPoints(e){this.makeEmpty();for(let a=0,r=e.length;a<r;a++)this.expandByPoint(e[a]);return this}setFromCenterAndSize(e,a){const r=wi.copy(a).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,a=!1){return this.makeEmpty(),this.expandByObject(e,a)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,a=!1){e.updateWorldMatrix(!1,!1);const r=e.geometry;if(r!==void 0){const f=r.getAttribute("position");if(a===!0&&f!==void 0&&e.isInstancedMesh!==!0)for(let h=0,d=f.count;h<d;h++)e.isMesh===!0?e.getVertexPosition(h,wi):wi.fromBufferAttribute(f,h),wi.applyMatrix4(e.matrixWorld),this.expandByPoint(wi);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),jc.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),jc.copy(r.boundingBox)),jc.applyMatrix4(e.matrixWorld),this.union(jc)}const c=e.children;for(let f=0,h=c.length;f<h;f++)this.expandByObject(c[f],a);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,a){return a.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,wi),wi.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let a,r;return e.normal.x>0?(a=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(a=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(a+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(a+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(a+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(a+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),a<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(sl),qc.subVectors(this.max,sl),Hr.subVectors(e.a,sl),Gr.subVectors(e.b,sl),Vr.subVectors(e.c,sl),$a.subVectors(Gr,Hr),ts.subVectors(Vr,Gr),zs.subVectors(Hr,Vr);let a=[0,-$a.z,$a.y,0,-ts.z,ts.y,0,-zs.z,zs.y,$a.z,0,-$a.x,ts.z,0,-ts.x,zs.z,0,-zs.x,-$a.y,$a.x,0,-ts.y,ts.x,0,-zs.y,zs.x,0];return!md(a,Hr,Gr,Vr,qc)||(a=[1,0,0,0,1,0,0,0,1],!md(a,Hr,Gr,Vr,qc))?!1:(Yc.crossVectors($a,ts),a=[Yc.x,Yc.y,Yc.z],md(a,Hr,Gr,Vr,qc))}clampPoint(e,a){return a.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,wi).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(wi).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ga[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ga[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ga[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ga[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ga[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ga[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ga[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ga[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ga),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const ga=[new et,new et,new et,new et,new et,new et,new et,new et],wi=new et,jc=new yl,Hr=new et,Gr=new et,Vr=new et,$a=new et,ts=new et,zs=new et,sl=new et,qc=new et,Yc=new et,Ps=new et;function md(o,e,a,r,c){for(let f=0,h=o.length-3;f<=h;f+=3){Ps.fromArray(o,f);const d=c.x*Math.abs(Ps.x)+c.y*Math.abs(Ps.y)+c.z*Math.abs(Ps.z),_=e.dot(Ps),m=a.dot(Ps),x=r.dot(Ps);if(Math.max(-Math.max(_,m,x),Math.min(_,m,x))>d)return!1}return!0}const kE=new yl,rl=new et,gd=new et;class bu{constructor(e=new et,a=-1){this.isSphere=!0,this.center=e,this.radius=a}set(e,a){return this.center.copy(e),this.radius=a,this}setFromPoints(e,a){const r=this.center;a!==void 0?r.copy(a):kE.setFromPoints(e).getCenter(r);let c=0;for(let f=0,h=e.length;f<h;f++)c=Math.max(c,r.distanceToSquared(e[f]));return this.radius=Math.sqrt(c),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const a=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=a*a}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,a){const r=this.center.distanceToSquared(e);return a.copy(e),r>this.radius*this.radius&&(a.sub(this.center).normalize(),a.multiplyScalar(this.radius).add(this.center)),a}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;rl.subVectors(e,this.center);const a=rl.lengthSq();if(a>this.radius*this.radius){const r=Math.sqrt(a),c=(r-this.radius)*.5;this.center.addScaledVector(rl,c/r),this.radius+=c}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(gd.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(rl.copy(e.center).add(gd)),this.expandByPoint(rl.copy(e.center).sub(gd))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const _a=new et,_d=new et,Wc=new et,es=new et,vd=new et,Zc=new et,xd=new et;class Rx{constructor(e=new et,a=new et(0,0,-1)){this.origin=e,this.direction=a}set(e,a){return this.origin.copy(e),this.direction.copy(a),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,a){return a.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,_a)),this}closestPointToPoint(e,a){a.subVectors(e,this.origin);const r=a.dot(this.direction);return r<0?a.copy(this.origin):a.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const a=_a.subVectors(e,this.origin).dot(this.direction);return a<0?this.origin.distanceToSquared(e):(_a.copy(this.origin).addScaledVector(this.direction,a),_a.distanceToSquared(e))}distanceSqToSegment(e,a,r,c){_d.copy(e).add(a).multiplyScalar(.5),Wc.copy(a).sub(e).normalize(),es.copy(this.origin).sub(_d);const f=e.distanceTo(a)*.5,h=-this.direction.dot(Wc),d=es.dot(this.direction),_=-es.dot(Wc),m=es.lengthSq(),x=Math.abs(1-h*h);let p,y,M,b;if(x>0)if(p=h*_-d,y=h*d-_,b=f*x,p>=0)if(y>=-b)if(y<=b){const D=1/x;p*=D,y*=D,M=p*(p+h*y+2*d)+y*(h*p+y+2*_)+m}else y=f,p=Math.max(0,-(h*y+d)),M=-p*p+y*(y+2*_)+m;else y=-f,p=Math.max(0,-(h*y+d)),M=-p*p+y*(y+2*_)+m;else y<=-b?(p=Math.max(0,-(-h*f+d)),y=p>0?-f:Math.min(Math.max(-f,-_),f),M=-p*p+y*(y+2*_)+m):y<=b?(p=0,y=Math.min(Math.max(-f,-_),f),M=y*(y+2*_)+m):(p=Math.max(0,-(h*f+d)),y=p>0?f:Math.min(Math.max(-f,-_),f),M=-p*p+y*(y+2*_)+m);else y=h>0?-f:f,p=Math.max(0,-(h*y+d)),M=-p*p+y*(y+2*_)+m;return r&&r.copy(this.origin).addScaledVector(this.direction,p),c&&c.copy(_d).addScaledVector(Wc,y),M}intersectSphere(e,a){_a.subVectors(e.center,this.origin);const r=_a.dot(this.direction),c=_a.dot(_a)-r*r,f=e.radius*e.radius;if(c>f)return null;const h=Math.sqrt(f-c),d=r-h,_=r+h;return _<0?null:d<0?this.at(_,a):this.at(d,a)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const a=e.normal.dot(this.direction);if(a===0)return e.distanceToPoint(this.origin)===0?0:null;const r=-(this.origin.dot(e.normal)+e.constant)/a;return r>=0?r:null}intersectPlane(e,a){const r=this.distanceToPlane(e);return r===null?null:this.at(r,a)}intersectsPlane(e){const a=e.distanceToPoint(this.origin);return a===0||e.normal.dot(this.direction)*a<0}intersectBox(e,a){let r,c,f,h,d,_;const m=1/this.direction.x,x=1/this.direction.y,p=1/this.direction.z,y=this.origin;return m>=0?(r=(e.min.x-y.x)*m,c=(e.max.x-y.x)*m):(r=(e.max.x-y.x)*m,c=(e.min.x-y.x)*m),x>=0?(f=(e.min.y-y.y)*x,h=(e.max.y-y.y)*x):(f=(e.max.y-y.y)*x,h=(e.min.y-y.y)*x),r>h||f>c||((f>r||isNaN(r))&&(r=f),(h<c||isNaN(c))&&(c=h),p>=0?(d=(e.min.z-y.z)*p,_=(e.max.z-y.z)*p):(d=(e.max.z-y.z)*p,_=(e.min.z-y.z)*p),r>_||d>c)||((d>r||r!==r)&&(r=d),(_<c||c!==c)&&(c=_),c<0)?null:this.at(r>=0?r:c,a)}intersectsBox(e){return this.intersectBox(e,_a)!==null}intersectTriangle(e,a,r,c,f){vd.subVectors(a,e),Zc.subVectors(r,e),xd.crossVectors(vd,Zc);let h=this.direction.dot(xd),d;if(h>0){if(c)return null;d=1}else if(h<0)d=-1,h=-h;else return null;es.subVectors(this.origin,e);const _=d*this.direction.dot(Zc.crossVectors(es,Zc));if(_<0)return null;const m=d*this.direction.dot(vd.cross(es));if(m<0||_+m>h)return null;const x=-d*es.dot(xd);return x<0?null:this.at(x/h,f)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class sn{constructor(e,a,r,c,f,h,d,_,m,x,p,y,M,b,D,S){sn.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,a,r,c,f,h,d,_,m,x,p,y,M,b,D,S)}set(e,a,r,c,f,h,d,_,m,x,p,y,M,b,D,S){const v=this.elements;return v[0]=e,v[4]=a,v[8]=r,v[12]=c,v[1]=f,v[5]=h,v[9]=d,v[13]=_,v[2]=m,v[6]=x,v[10]=p,v[14]=y,v[3]=M,v[7]=b,v[11]=D,v[15]=S,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new sn().fromArray(this.elements)}copy(e){const a=this.elements,r=e.elements;return a[0]=r[0],a[1]=r[1],a[2]=r[2],a[3]=r[3],a[4]=r[4],a[5]=r[5],a[6]=r[6],a[7]=r[7],a[8]=r[8],a[9]=r[9],a[10]=r[10],a[11]=r[11],a[12]=r[12],a[13]=r[13],a[14]=r[14],a[15]=r[15],this}copyPosition(e){const a=this.elements,r=e.elements;return a[12]=r[12],a[13]=r[13],a[14]=r[14],this}setFromMatrix3(e){const a=e.elements;return this.set(a[0],a[3],a[6],0,a[1],a[4],a[7],0,a[2],a[5],a[8],0,0,0,0,1),this}extractBasis(e,a,r){return e.setFromMatrixColumn(this,0),a.setFromMatrixColumn(this,1),r.setFromMatrixColumn(this,2),this}makeBasis(e,a,r){return this.set(e.x,a.x,r.x,0,e.y,a.y,r.y,0,e.z,a.z,r.z,0,0,0,0,1),this}extractRotation(e){const a=this.elements,r=e.elements,c=1/kr.setFromMatrixColumn(e,0).length(),f=1/kr.setFromMatrixColumn(e,1).length(),h=1/kr.setFromMatrixColumn(e,2).length();return a[0]=r[0]*c,a[1]=r[1]*c,a[2]=r[2]*c,a[3]=0,a[4]=r[4]*f,a[5]=r[5]*f,a[6]=r[6]*f,a[7]=0,a[8]=r[8]*h,a[9]=r[9]*h,a[10]=r[10]*h,a[11]=0,a[12]=0,a[13]=0,a[14]=0,a[15]=1,this}makeRotationFromEuler(e){const a=this.elements,r=e.x,c=e.y,f=e.z,h=Math.cos(r),d=Math.sin(r),_=Math.cos(c),m=Math.sin(c),x=Math.cos(f),p=Math.sin(f);if(e.order==="XYZ"){const y=h*x,M=h*p,b=d*x,D=d*p;a[0]=_*x,a[4]=-_*p,a[8]=m,a[1]=M+b*m,a[5]=y-D*m,a[9]=-d*_,a[2]=D-y*m,a[6]=b+M*m,a[10]=h*_}else if(e.order==="YXZ"){const y=_*x,M=_*p,b=m*x,D=m*p;a[0]=y+D*d,a[4]=b*d-M,a[8]=h*m,a[1]=h*p,a[5]=h*x,a[9]=-d,a[2]=M*d-b,a[6]=D+y*d,a[10]=h*_}else if(e.order==="ZXY"){const y=_*x,M=_*p,b=m*x,D=m*p;a[0]=y-D*d,a[4]=-h*p,a[8]=b+M*d,a[1]=M+b*d,a[5]=h*x,a[9]=D-y*d,a[2]=-h*m,a[6]=d,a[10]=h*_}else if(e.order==="ZYX"){const y=h*x,M=h*p,b=d*x,D=d*p;a[0]=_*x,a[4]=b*m-M,a[8]=y*m+D,a[1]=_*p,a[5]=D*m+y,a[9]=M*m-b,a[2]=-m,a[6]=d*_,a[10]=h*_}else if(e.order==="YZX"){const y=h*_,M=h*m,b=d*_,D=d*m;a[0]=_*x,a[4]=D-y*p,a[8]=b*p+M,a[1]=p,a[5]=h*x,a[9]=-d*x,a[2]=-m*x,a[6]=M*p+b,a[10]=y-D*p}else if(e.order==="XZY"){const y=h*_,M=h*m,b=d*_,D=d*m;a[0]=_*x,a[4]=-p,a[8]=m*x,a[1]=y*p+D,a[5]=h*x,a[9]=M*p-b,a[2]=b*p-M,a[6]=d*x,a[10]=D*p+y}return a[3]=0,a[7]=0,a[11]=0,a[12]=0,a[13]=0,a[14]=0,a[15]=1,this}makeRotationFromQuaternion(e){return this.compose(XE,e,jE)}lookAt(e,a,r){const c=this.elements;return oi.subVectors(e,a),oi.lengthSq()===0&&(oi.z=1),oi.normalize(),ns.crossVectors(r,oi),ns.lengthSq()===0&&(Math.abs(r.z)===1?oi.x+=1e-4:oi.z+=1e-4,oi.normalize(),ns.crossVectors(r,oi)),ns.normalize(),Kc.crossVectors(oi,ns),c[0]=ns.x,c[4]=Kc.x,c[8]=oi.x,c[1]=ns.y,c[5]=Kc.y,c[9]=oi.y,c[2]=ns.z,c[6]=Kc.z,c[10]=oi.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,a){const r=e.elements,c=a.elements,f=this.elements,h=r[0],d=r[4],_=r[8],m=r[12],x=r[1],p=r[5],y=r[9],M=r[13],b=r[2],D=r[6],S=r[10],v=r[14],L=r[3],z=r[7],N=r[11],H=r[15],F=c[0],P=c[4],k=c[8],C=c[12],w=c[1],G=c[5],it=c[9],ct=c[13],gt=c[2],ut=c[6],W=c[10],rt=c[14],K=c[3],vt=c[7],yt=c[11],Gt=c[15];return f[0]=h*F+d*w+_*gt+m*K,f[4]=h*P+d*G+_*ut+m*vt,f[8]=h*k+d*it+_*W+m*yt,f[12]=h*C+d*ct+_*rt+m*Gt,f[1]=x*F+p*w+y*gt+M*K,f[5]=x*P+p*G+y*ut+M*vt,f[9]=x*k+p*it+y*W+M*yt,f[13]=x*C+p*ct+y*rt+M*Gt,f[2]=b*F+D*w+S*gt+v*K,f[6]=b*P+D*G+S*ut+v*vt,f[10]=b*k+D*it+S*W+v*yt,f[14]=b*C+D*ct+S*rt+v*Gt,f[3]=L*F+z*w+N*gt+H*K,f[7]=L*P+z*G+N*ut+H*vt,f[11]=L*k+z*it+N*W+H*yt,f[15]=L*C+z*ct+N*rt+H*Gt,this}multiplyScalar(e){const a=this.elements;return a[0]*=e,a[4]*=e,a[8]*=e,a[12]*=e,a[1]*=e,a[5]*=e,a[9]*=e,a[13]*=e,a[2]*=e,a[6]*=e,a[10]*=e,a[14]*=e,a[3]*=e,a[7]*=e,a[11]*=e,a[15]*=e,this}determinant(){const e=this.elements,a=e[0],r=e[4],c=e[8],f=e[12],h=e[1],d=e[5],_=e[9],m=e[13],x=e[2],p=e[6],y=e[10],M=e[14],b=e[3],D=e[7],S=e[11],v=e[15];return b*(+f*_*p-c*m*p-f*d*y+r*m*y+c*d*M-r*_*M)+D*(+a*_*M-a*m*y+f*h*y-c*h*M+c*m*x-f*_*x)+S*(+a*m*p-a*d*M-f*h*p+r*h*M+f*d*x-r*m*x)+v*(-c*d*x-a*_*p+a*d*y+c*h*p-r*h*y+r*_*x)}transpose(){const e=this.elements;let a;return a=e[1],e[1]=e[4],e[4]=a,a=e[2],e[2]=e[8],e[8]=a,a=e[6],e[6]=e[9],e[9]=a,a=e[3],e[3]=e[12],e[12]=a,a=e[7],e[7]=e[13],e[13]=a,a=e[11],e[11]=e[14],e[14]=a,this}setPosition(e,a,r){const c=this.elements;return e.isVector3?(c[12]=e.x,c[13]=e.y,c[14]=e.z):(c[12]=e,c[13]=a,c[14]=r),this}invert(){const e=this.elements,a=e[0],r=e[1],c=e[2],f=e[3],h=e[4],d=e[5],_=e[6],m=e[7],x=e[8],p=e[9],y=e[10],M=e[11],b=e[12],D=e[13],S=e[14],v=e[15],L=p*S*m-D*y*m+D*_*M-d*S*M-p*_*v+d*y*v,z=b*y*m-x*S*m-b*_*M+h*S*M+x*_*v-h*y*v,N=x*D*m-b*p*m+b*d*M-h*D*M-x*d*v+h*p*v,H=b*p*_-x*D*_-b*d*y+h*D*y+x*d*S-h*p*S,F=a*L+r*z+c*N+f*H;if(F===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const P=1/F;return e[0]=L*P,e[1]=(D*y*f-p*S*f-D*c*M+r*S*M+p*c*v-r*y*v)*P,e[2]=(d*S*f-D*_*f+D*c*m-r*S*m-d*c*v+r*_*v)*P,e[3]=(p*_*f-d*y*f-p*c*m+r*y*m+d*c*M-r*_*M)*P,e[4]=z*P,e[5]=(x*S*f-b*y*f+b*c*M-a*S*M-x*c*v+a*y*v)*P,e[6]=(b*_*f-h*S*f-b*c*m+a*S*m+h*c*v-a*_*v)*P,e[7]=(h*y*f-x*_*f+x*c*m-a*y*m-h*c*M+a*_*M)*P,e[8]=N*P,e[9]=(b*p*f-x*D*f-b*r*M+a*D*M+x*r*v-a*p*v)*P,e[10]=(h*D*f-b*d*f+b*r*m-a*D*m-h*r*v+a*d*v)*P,e[11]=(x*d*f-h*p*f-x*r*m+a*p*m+h*r*M-a*d*M)*P,e[12]=H*P,e[13]=(x*D*c-b*p*c+b*r*y-a*D*y-x*r*S+a*p*S)*P,e[14]=(b*d*c-h*D*c-b*r*_+a*D*_+h*r*S-a*d*S)*P,e[15]=(h*p*c-x*d*c+x*r*_-a*p*_-h*r*y+a*d*y)*P,this}scale(e){const a=this.elements,r=e.x,c=e.y,f=e.z;return a[0]*=r,a[4]*=c,a[8]*=f,a[1]*=r,a[5]*=c,a[9]*=f,a[2]*=r,a[6]*=c,a[10]*=f,a[3]*=r,a[7]*=c,a[11]*=f,this}getMaxScaleOnAxis(){const e=this.elements,a=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],r=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],c=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(a,r,c))}makeTranslation(e,a,r){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,a,0,0,1,r,0,0,0,1),this}makeRotationX(e){const a=Math.cos(e),r=Math.sin(e);return this.set(1,0,0,0,0,a,-r,0,0,r,a,0,0,0,0,1),this}makeRotationY(e){const a=Math.cos(e),r=Math.sin(e);return this.set(a,0,r,0,0,1,0,0,-r,0,a,0,0,0,0,1),this}makeRotationZ(e){const a=Math.cos(e),r=Math.sin(e);return this.set(a,-r,0,0,r,a,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,a){const r=Math.cos(a),c=Math.sin(a),f=1-r,h=e.x,d=e.y,_=e.z,m=f*h,x=f*d;return this.set(m*h+r,m*d-c*_,m*_+c*d,0,m*d+c*_,x*d+r,x*_-c*h,0,m*_-c*d,x*_+c*h,f*_*_+r,0,0,0,0,1),this}makeScale(e,a,r){return this.set(e,0,0,0,0,a,0,0,0,0,r,0,0,0,0,1),this}makeShear(e,a,r,c,f,h){return this.set(1,r,f,0,e,1,h,0,a,c,1,0,0,0,0,1),this}compose(e,a,r){const c=this.elements,f=a._x,h=a._y,d=a._z,_=a._w,m=f+f,x=h+h,p=d+d,y=f*m,M=f*x,b=f*p,D=h*x,S=h*p,v=d*p,L=_*m,z=_*x,N=_*p,H=r.x,F=r.y,P=r.z;return c[0]=(1-(D+v))*H,c[1]=(M+N)*H,c[2]=(b-z)*H,c[3]=0,c[4]=(M-N)*F,c[5]=(1-(y+v))*F,c[6]=(S+L)*F,c[7]=0,c[8]=(b+z)*P,c[9]=(S-L)*P,c[10]=(1-(y+D))*P,c[11]=0,c[12]=e.x,c[13]=e.y,c[14]=e.z,c[15]=1,this}decompose(e,a,r){const c=this.elements;let f=kr.set(c[0],c[1],c[2]).length();const h=kr.set(c[4],c[5],c[6]).length(),d=kr.set(c[8],c[9],c[10]).length();this.determinant()<0&&(f=-f),e.x=c[12],e.y=c[13],e.z=c[14],Di.copy(this);const m=1/f,x=1/h,p=1/d;return Di.elements[0]*=m,Di.elements[1]*=m,Di.elements[2]*=m,Di.elements[4]*=x,Di.elements[5]*=x,Di.elements[6]*=x,Di.elements[8]*=p,Di.elements[9]*=p,Di.elements[10]*=p,a.setFromRotationMatrix(Di),r.x=f,r.y=h,r.z=d,this}makePerspective(e,a,r,c,f,h,d=Qi,_=!1){const m=this.elements,x=2*f/(a-e),p=2*f/(r-c),y=(a+e)/(a-e),M=(r+c)/(r-c);let b,D;if(_)b=f/(h-f),D=h*f/(h-f);else if(d===Qi)b=-(h+f)/(h-f),D=-2*h*f/(h-f);else if(d===yu)b=-h/(h-f),D=-h*f/(h-f);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+d);return m[0]=x,m[4]=0,m[8]=y,m[12]=0,m[1]=0,m[5]=p,m[9]=M,m[13]=0,m[2]=0,m[6]=0,m[10]=b,m[14]=D,m[3]=0,m[7]=0,m[11]=-1,m[15]=0,this}makeOrthographic(e,a,r,c,f,h,d=Qi,_=!1){const m=this.elements,x=2/(a-e),p=2/(r-c),y=-(a+e)/(a-e),M=-(r+c)/(r-c);let b,D;if(_)b=1/(h-f),D=h/(h-f);else if(d===Qi)b=-2/(h-f),D=-(h+f)/(h-f);else if(d===yu)b=-1/(h-f),D=-f/(h-f);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+d);return m[0]=x,m[4]=0,m[8]=0,m[12]=y,m[1]=0,m[5]=p,m[9]=0,m[13]=M,m[2]=0,m[6]=0,m[10]=b,m[14]=D,m[3]=0,m[7]=0,m[11]=0,m[15]=1,this}equals(e){const a=this.elements,r=e.elements;for(let c=0;c<16;c++)if(a[c]!==r[c])return!1;return!0}fromArray(e,a=0){for(let r=0;r<16;r++)this.elements[r]=e[r+a];return this}toArray(e=[],a=0){const r=this.elements;return e[a]=r[0],e[a+1]=r[1],e[a+2]=r[2],e[a+3]=r[3],e[a+4]=r[4],e[a+5]=r[5],e[a+6]=r[6],e[a+7]=r[7],e[a+8]=r[8],e[a+9]=r[9],e[a+10]=r[10],e[a+11]=r[11],e[a+12]=r[12],e[a+13]=r[13],e[a+14]=r[14],e[a+15]=r[15],e}}const kr=new et,Di=new sn,XE=new et(0,0,0),jE=new et(1,1,1),ns=new et,Kc=new et,oi=new et,xv=new sn,yv=new xl;class $i{constructor(e=0,a=0,r=0,c=$i.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=a,this._z=r,this._order=c}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,a,r,c=this._order){return this._x=e,this._y=a,this._z=r,this._order=c,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,a=this._order,r=!0){const c=e.elements,f=c[0],h=c[4],d=c[8],_=c[1],m=c[5],x=c[9],p=c[2],y=c[6],M=c[10];switch(a){case"XYZ":this._y=Math.asin(be(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-x,M),this._z=Math.atan2(-h,f)):(this._x=Math.atan2(y,m),this._z=0);break;case"YXZ":this._x=Math.asin(-be(x,-1,1)),Math.abs(x)<.9999999?(this._y=Math.atan2(d,M),this._z=Math.atan2(_,m)):(this._y=Math.atan2(-p,f),this._z=0);break;case"ZXY":this._x=Math.asin(be(y,-1,1)),Math.abs(y)<.9999999?(this._y=Math.atan2(-p,M),this._z=Math.atan2(-h,m)):(this._y=0,this._z=Math.atan2(_,f));break;case"ZYX":this._y=Math.asin(-be(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(y,M),this._z=Math.atan2(_,f)):(this._x=0,this._z=Math.atan2(-h,m));break;case"YZX":this._z=Math.asin(be(_,-1,1)),Math.abs(_)<.9999999?(this._x=Math.atan2(-x,m),this._y=Math.atan2(-p,f)):(this._x=0,this._y=Math.atan2(d,M));break;case"XZY":this._z=Math.asin(-be(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(y,m),this._y=Math.atan2(d,f)):(this._x=Math.atan2(-x,M),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+a)}return this._order=a,r===!0&&this._onChangeCallback(),this}setFromQuaternion(e,a,r){return xv.makeRotationFromQuaternion(e),this.setFromRotationMatrix(xv,a,r)}setFromVector3(e,a=this._order){return this.set(e.x,e.y,e.z,a)}reorder(e){return yv.setFromEuler(this),this.setFromQuaternion(yv,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],a=0){return e[a]=this._x,e[a+1]=this._y,e[a+2]=this._z,e[a+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}$i.DEFAULT_ORDER="XYZ";let Cx=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},qE=0;const Sv=new et,Xr=new xl,va=new sn,Qc=new et,ol=new et,YE=new et,WE=new xl,Mv=new et(1,0,0),Ev=new et(0,1,0),Tv=new et(0,0,1),bv={type:"added"},ZE={type:"removed"},jr={type:"childadded",child:null},yd={type:"childremoved",child:null};class bn extends oo{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:qE++}),this.uuid=vl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=bn.DEFAULT_UP.clone();const e=new et,a=new $i,r=new xl,c=new et(1,1,1);function f(){r.setFromEuler(a,!1)}function h(){a.setFromQuaternion(r,void 0,!1)}a._onChange(f),r._onChange(h),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:a},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:c},modelViewMatrix:{value:new sn},normalMatrix:{value:new de}}),this.matrix=new sn,this.matrixWorld=new sn,this.matrixAutoUpdate=bn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Cx,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,a){this.quaternion.setFromAxisAngle(e,a)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,a){return Xr.setFromAxisAngle(e,a),this.quaternion.multiply(Xr),this}rotateOnWorldAxis(e,a){return Xr.setFromAxisAngle(e,a),this.quaternion.premultiply(Xr),this}rotateX(e){return this.rotateOnAxis(Mv,e)}rotateY(e){return this.rotateOnAxis(Ev,e)}rotateZ(e){return this.rotateOnAxis(Tv,e)}translateOnAxis(e,a){return Sv.copy(e).applyQuaternion(this.quaternion),this.position.add(Sv.multiplyScalar(a)),this}translateX(e){return this.translateOnAxis(Mv,e)}translateY(e){return this.translateOnAxis(Ev,e)}translateZ(e){return this.translateOnAxis(Tv,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(va.copy(this.matrixWorld).invert())}lookAt(e,a,r){e.isVector3?Qc.copy(e):Qc.set(e,a,r);const c=this.parent;this.updateWorldMatrix(!0,!1),ol.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?va.lookAt(ol,Qc,this.up):va.lookAt(Qc,ol,this.up),this.quaternion.setFromRotationMatrix(va),c&&(va.extractRotation(c.matrixWorld),Xr.setFromRotationMatrix(va),this.quaternion.premultiply(Xr.invert()))}add(e){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.add(arguments[a]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(bv),jr.child=e,this.dispatchEvent(jr),jr.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.remove(arguments[r]);return this}const a=this.children.indexOf(e);return a!==-1&&(e.parent=null,this.children.splice(a,1),e.dispatchEvent(ZE),yd.child=e,this.dispatchEvent(yd),yd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),va.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),va.multiply(e.parent.matrixWorld)),e.applyMatrix4(va),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(bv),jr.child=e,this.dispatchEvent(jr),jr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,a){if(this[e]===a)return this;for(let r=0,c=this.children.length;r<c;r++){const h=this.children[r].getObjectByProperty(e,a);if(h!==void 0)return h}}getObjectsByProperty(e,a,r=[]){this[e]===a&&r.push(this);const c=this.children;for(let f=0,h=c.length;f<h;f++)c[f].getObjectsByProperty(e,a,r);return r}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ol,e,YE),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ol,WE,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const a=this.matrixWorld.elements;return e.set(a[8],a[9],a[10]).normalize()}raycast(){}traverse(e){e(this);const a=this.children;for(let r=0,c=a.length;r<c;r++)a[r].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const a=this.children;for(let r=0,c=a.length;r<c;r++)a[r].traverseVisible(e)}traverseAncestors(e){const a=this.parent;a!==null&&(e(a),a.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const a=this.children;for(let r=0,c=a.length;r<c;r++)a[r].updateMatrixWorld(e)}updateWorldMatrix(e,a){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),a===!0){const c=this.children;for(let f=0,h=c.length;f<h;f++)c[f].updateWorldMatrix(!1,!0)}}toJSON(e){const a=e===void 0||typeof e=="string",r={};a&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},r.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const c={};c.uuid=this.uuid,c.type=this.type,this.name!==""&&(c.name=this.name),this.castShadow===!0&&(c.castShadow=!0),this.receiveShadow===!0&&(c.receiveShadow=!0),this.visible===!1&&(c.visible=!1),this.frustumCulled===!1&&(c.frustumCulled=!1),this.renderOrder!==0&&(c.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(c.userData=this.userData),c.layers=this.layers.mask,c.matrix=this.matrix.toArray(),c.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(c.matrixAutoUpdate=!1),this.isInstancedMesh&&(c.type="InstancedMesh",c.count=this.count,c.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(c.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(c.type="BatchedMesh",c.perObjectFrustumCulled=this.perObjectFrustumCulled,c.sortObjects=this.sortObjects,c.drawRanges=this._drawRanges,c.reservedRanges=this._reservedRanges,c.geometryInfo=this._geometryInfo.map(d=>({...d,boundingBox:d.boundingBox?d.boundingBox.toJSON():void 0,boundingSphere:d.boundingSphere?d.boundingSphere.toJSON():void 0})),c.instanceInfo=this._instanceInfo.map(d=>({...d})),c.availableInstanceIds=this._availableInstanceIds.slice(),c.availableGeometryIds=this._availableGeometryIds.slice(),c.nextIndexStart=this._nextIndexStart,c.nextVertexStart=this._nextVertexStart,c.geometryCount=this._geometryCount,c.maxInstanceCount=this._maxInstanceCount,c.maxVertexCount=this._maxVertexCount,c.maxIndexCount=this._maxIndexCount,c.geometryInitialized=this._geometryInitialized,c.matricesTexture=this._matricesTexture.toJSON(e),c.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(c.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(c.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(c.boundingBox=this.boundingBox.toJSON()));function f(d,_){return d[_.uuid]===void 0&&(d[_.uuid]=_.toJSON(e)),_.uuid}if(this.isScene)this.background&&(this.background.isColor?c.background=this.background.toJSON():this.background.isTexture&&(c.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(c.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){c.geometry=f(e.geometries,this.geometry);const d=this.geometry.parameters;if(d!==void 0&&d.shapes!==void 0){const _=d.shapes;if(Array.isArray(_))for(let m=0,x=_.length;m<x;m++){const p=_[m];f(e.shapes,p)}else f(e.shapes,_)}}if(this.isSkinnedMesh&&(c.bindMode=this.bindMode,c.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(f(e.skeletons,this.skeleton),c.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const d=[];for(let _=0,m=this.material.length;_<m;_++)d.push(f(e.materials,this.material[_]));c.material=d}else c.material=f(e.materials,this.material);if(this.children.length>0){c.children=[];for(let d=0;d<this.children.length;d++)c.children.push(this.children[d].toJSON(e).object)}if(this.animations.length>0){c.animations=[];for(let d=0;d<this.animations.length;d++){const _=this.animations[d];c.animations.push(f(e.animations,_))}}if(a){const d=h(e.geometries),_=h(e.materials),m=h(e.textures),x=h(e.images),p=h(e.shapes),y=h(e.skeletons),M=h(e.animations),b=h(e.nodes);d.length>0&&(r.geometries=d),_.length>0&&(r.materials=_),m.length>0&&(r.textures=m),x.length>0&&(r.images=x),p.length>0&&(r.shapes=p),y.length>0&&(r.skeletons=y),M.length>0&&(r.animations=M),b.length>0&&(r.nodes=b)}return r.object=c,r;function h(d){const _=[];for(const m in d){const x=d[m];delete x.metadata,_.push(x)}return _}}clone(e){return new this.constructor().copy(this,e)}copy(e,a=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),a===!0)for(let r=0;r<e.children.length;r++){const c=e.children[r];this.add(c.clone())}return this}}bn.DEFAULT_UP=new et(0,1,0);bn.DEFAULT_MATRIX_AUTO_UPDATE=!0;bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Ni=new et,xa=new et,Sd=new et,ya=new et,qr=new et,Yr=new et,Av=new et,Md=new et,Ed=new et,Td=new et,bd=new je,Ad=new je,Rd=new je;class Ui{constructor(e=new et,a=new et,r=new et){this.a=e,this.b=a,this.c=r}static getNormal(e,a,r,c){c.subVectors(r,a),Ni.subVectors(e,a),c.cross(Ni);const f=c.lengthSq();return f>0?c.multiplyScalar(1/Math.sqrt(f)):c.set(0,0,0)}static getBarycoord(e,a,r,c,f){Ni.subVectors(c,a),xa.subVectors(r,a),Sd.subVectors(e,a);const h=Ni.dot(Ni),d=Ni.dot(xa),_=Ni.dot(Sd),m=xa.dot(xa),x=xa.dot(Sd),p=h*m-d*d;if(p===0)return f.set(0,0,0),null;const y=1/p,M=(m*_-d*x)*y,b=(h*x-d*_)*y;return f.set(1-M-b,b,M)}static containsPoint(e,a,r,c){return this.getBarycoord(e,a,r,c,ya)===null?!1:ya.x>=0&&ya.y>=0&&ya.x+ya.y<=1}static getInterpolation(e,a,r,c,f,h,d,_){return this.getBarycoord(e,a,r,c,ya)===null?(_.x=0,_.y=0,"z"in _&&(_.z=0),"w"in _&&(_.w=0),null):(_.setScalar(0),_.addScaledVector(f,ya.x),_.addScaledVector(h,ya.y),_.addScaledVector(d,ya.z),_)}static getInterpolatedAttribute(e,a,r,c,f,h){return bd.setScalar(0),Ad.setScalar(0),Rd.setScalar(0),bd.fromBufferAttribute(e,a),Ad.fromBufferAttribute(e,r),Rd.fromBufferAttribute(e,c),h.setScalar(0),h.addScaledVector(bd,f.x),h.addScaledVector(Ad,f.y),h.addScaledVector(Rd,f.z),h}static isFrontFacing(e,a,r,c){return Ni.subVectors(r,a),xa.subVectors(e,a),Ni.cross(xa).dot(c)<0}set(e,a,r){return this.a.copy(e),this.b.copy(a),this.c.copy(r),this}setFromPointsAndIndices(e,a,r,c){return this.a.copy(e[a]),this.b.copy(e[r]),this.c.copy(e[c]),this}setFromAttributeAndIndices(e,a,r,c){return this.a.fromBufferAttribute(e,a),this.b.fromBufferAttribute(e,r),this.c.fromBufferAttribute(e,c),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Ni.subVectors(this.c,this.b),xa.subVectors(this.a,this.b),Ni.cross(xa).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Ui.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,a){return Ui.getBarycoord(e,this.a,this.b,this.c,a)}getInterpolation(e,a,r,c,f){return Ui.getInterpolation(e,this.a,this.b,this.c,a,r,c,f)}containsPoint(e){return Ui.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Ui.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,a){const r=this.a,c=this.b,f=this.c;let h,d;qr.subVectors(c,r),Yr.subVectors(f,r),Md.subVectors(e,r);const _=qr.dot(Md),m=Yr.dot(Md);if(_<=0&&m<=0)return a.copy(r);Ed.subVectors(e,c);const x=qr.dot(Ed),p=Yr.dot(Ed);if(x>=0&&p<=x)return a.copy(c);const y=_*p-x*m;if(y<=0&&_>=0&&x<=0)return h=_/(_-x),a.copy(r).addScaledVector(qr,h);Td.subVectors(e,f);const M=qr.dot(Td),b=Yr.dot(Td);if(b>=0&&M<=b)return a.copy(f);const D=M*m-_*b;if(D<=0&&m>=0&&b<=0)return d=m/(m-b),a.copy(r).addScaledVector(Yr,d);const S=x*b-M*p;if(S<=0&&p-x>=0&&M-b>=0)return Av.subVectors(f,c),d=(p-x)/(p-x+(M-b)),a.copy(c).addScaledVector(Av,d);const v=1/(S+D+y);return h=D*v,d=y*v,a.copy(r).addScaledVector(qr,h).addScaledVector(Yr,d)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const wx={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},is={h:0,s:0,l:0},Jc={h:0,s:0,l:0};function Cd(o,e,a){return a<0&&(a+=1),a>1&&(a-=1),a<1/6?o+(e-o)*6*a:a<1/2?e:a<2/3?o+(e-o)*6*(2/3-a):o}class Te{constructor(e,a,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,a,r)}set(e,a,r){if(a===void 0&&r===void 0){const c=e;c&&c.isColor?this.copy(c):typeof c=="number"?this.setHex(c):typeof c=="string"&&this.setStyle(c)}else this.setRGB(e,a,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,a=Mi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Ne.colorSpaceToWorking(this,a),this}setRGB(e,a,r,c=Ne.workingColorSpace){return this.r=e,this.g=a,this.b=r,Ne.colorSpaceToWorking(this,c),this}setHSL(e,a,r,c=Ne.workingColorSpace){if(e=OE(e,1),a=be(a,0,1),r=be(r,0,1),a===0)this.r=this.g=this.b=r;else{const f=r<=.5?r*(1+a):r+a-r*a,h=2*r-f;this.r=Cd(h,f,e+1/3),this.g=Cd(h,f,e),this.b=Cd(h,f,e-1/3)}return Ne.colorSpaceToWorking(this,c),this}setStyle(e,a=Mi){function r(f){f!==void 0&&parseFloat(f)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let c;if(c=/^(\w+)\(([^\)]*)\)/.exec(e)){let f;const h=c[1],d=c[2];switch(h){case"rgb":case"rgba":if(f=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(f[4]),this.setRGB(Math.min(255,parseInt(f[1],10))/255,Math.min(255,parseInt(f[2],10))/255,Math.min(255,parseInt(f[3],10))/255,a);if(f=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(f[4]),this.setRGB(Math.min(100,parseInt(f[1],10))/100,Math.min(100,parseInt(f[2],10))/100,Math.min(100,parseInt(f[3],10))/100,a);break;case"hsl":case"hsla":if(f=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(f[4]),this.setHSL(parseFloat(f[1])/360,parseFloat(f[2])/100,parseFloat(f[3])/100,a);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(c=/^\#([A-Fa-f\d]+)$/.exec(e)){const f=c[1],h=f.length;if(h===3)return this.setRGB(parseInt(f.charAt(0),16)/15,parseInt(f.charAt(1),16)/15,parseInt(f.charAt(2),16)/15,a);if(h===6)return this.setHex(parseInt(f,16),a);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,a);return this}setColorName(e,a=Mi){const r=wx[e.toLowerCase()];return r!==void 0?this.setHex(r,a):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ta(e.r),this.g=Ta(e.g),this.b=Ta(e.b),this}copyLinearToSRGB(e){return this.r=eo(e.r),this.g=eo(e.g),this.b=eo(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Mi){return Ne.workingToColorSpace(Pn.copy(this),e),Math.round(be(Pn.r*255,0,255))*65536+Math.round(be(Pn.g*255,0,255))*256+Math.round(be(Pn.b*255,0,255))}getHexString(e=Mi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,a=Ne.workingColorSpace){Ne.workingToColorSpace(Pn.copy(this),a);const r=Pn.r,c=Pn.g,f=Pn.b,h=Math.max(r,c,f),d=Math.min(r,c,f);let _,m;const x=(d+h)/2;if(d===h)_=0,m=0;else{const p=h-d;switch(m=x<=.5?p/(h+d):p/(2-h-d),h){case r:_=(c-f)/p+(c<f?6:0);break;case c:_=(f-r)/p+2;break;case f:_=(r-c)/p+4;break}_/=6}return e.h=_,e.s=m,e.l=x,e}getRGB(e,a=Ne.workingColorSpace){return Ne.workingToColorSpace(Pn.copy(this),a),e.r=Pn.r,e.g=Pn.g,e.b=Pn.b,e}getStyle(e=Mi){Ne.workingToColorSpace(Pn.copy(this),e);const a=Pn.r,r=Pn.g,c=Pn.b;return e!==Mi?`color(${e} ${a.toFixed(3)} ${r.toFixed(3)} ${c.toFixed(3)})`:`rgb(${Math.round(a*255)},${Math.round(r*255)},${Math.round(c*255)})`}offsetHSL(e,a,r){return this.getHSL(is),this.setHSL(is.h+e,is.s+a,is.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,a){return this.r=e.r+a.r,this.g=e.g+a.g,this.b=e.b+a.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,a){return this.r+=(e.r-this.r)*a,this.g+=(e.g-this.g)*a,this.b+=(e.b-this.b)*a,this}lerpColors(e,a,r){return this.r=e.r+(a.r-e.r)*r,this.g=e.g+(a.g-e.g)*r,this.b=e.b+(a.b-e.b)*r,this}lerpHSL(e,a){this.getHSL(is),e.getHSL(Jc);const r=ud(is.h,Jc.h,a),c=ud(is.s,Jc.s,a),f=ud(is.l,Jc.l,a);return this.setHSL(r,c,f),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const a=this.r,r=this.g,c=this.b,f=e.elements;return this.r=f[0]*a+f[3]*r+f[6]*c,this.g=f[1]*a+f[4]*r+f[7]*c,this.b=f[2]*a+f[5]*r+f[8]*c,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,a=0){return this.r=e[a],this.g=e[a+1],this.b=e[a+2],this}toArray(e=[],a=0){return e[a]=this.r,e[a+1]=this.g,e[a+2]=this.b,e}fromBufferAttribute(e,a){return this.r=e.getX(a),this.g=e.getY(a),this.b=e.getZ(a),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Pn=new Te;Te.NAMES=wx;let KE=0;class lo extends oo{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:KE++}),this.uuid=vl(),this.name="",this.type="Material",this.blending=to,this.side=cs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Gd,this.blendDst=Vd,this.blendEquation=ks,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Te(0,0,0),this.blendAlpha=0,this.depthFunc=no,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=hv,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Br,this.stencilZFail=Br,this.stencilZPass=Br,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const a in e){const r=e[a];if(r===void 0){console.warn(`THREE.Material: parameter '${a}' has value of undefined.`);continue}const c=this[a];if(c===void 0){console.warn(`THREE.Material: '${a}' is not a property of THREE.${this.type}.`);continue}c&&c.isColor?c.set(r):c&&c.isVector3&&r&&r.isVector3?c.copy(r):this[a]=r}}toJSON(e){const a=e===void 0||typeof e=="string";a&&(e={textures:{},images:{}});const r={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(r.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(r.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.shadowSide!==null&&(r.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),this.blending!==to&&(r.blending=this.blending),this.side!==cs&&(r.side=this.side),this.vertexColors===!0&&(r.vertexColors=!0),this.opacity<1&&(r.opacity=this.opacity),this.transparent===!0&&(r.transparent=!0),this.blendSrc!==Gd&&(r.blendSrc=this.blendSrc),this.blendDst!==Vd&&(r.blendDst=this.blendDst),this.blendEquation!==ks&&(r.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(r.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(r.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(r.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(r.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(r.blendAlpha=this.blendAlpha),this.depthFunc!==no&&(r.depthFunc=this.depthFunc),this.depthTest===!1&&(r.depthTest=this.depthTest),this.depthWrite===!1&&(r.depthWrite=this.depthWrite),this.colorWrite===!1&&(r.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(r.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==hv&&(r.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(r.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(r.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Br&&(r.stencilFail=this.stencilFail),this.stencilZFail!==Br&&(r.stencilZFail=this.stencilZFail),this.stencilZPass!==Br&&(r.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(r.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(r.rotation=this.rotation),this.polygonOffset===!0&&(r.polygonOffset=!0),this.polygonOffsetFactor!==0&&(r.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(r.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(r.linewidth=this.linewidth),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.dithering===!0&&(r.dithering=!0),this.alphaTest>0&&(r.alphaTest=this.alphaTest),this.alphaHash===!0&&(r.alphaHash=!0),this.alphaToCoverage===!0&&(r.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(r.premultipliedAlpha=!0),this.forceSinglePass===!0&&(r.forceSinglePass=!0),this.wireframe===!0&&(r.wireframe=!0),this.wireframeLinewidth>1&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(r.flatShading=!0),this.visible===!1&&(r.visible=!1),this.toneMapped===!1&&(r.toneMapped=!1),this.fog===!1&&(r.fog=!1),Object.keys(this.userData).length>0&&(r.userData=this.userData);function c(f){const h=[];for(const d in f){const _=f[d];delete _.metadata,h.push(_)}return h}if(a){const f=c(e.textures),h=c(e.images);f.length>0&&(r.textures=f),h.length>0&&(r.images=h)}return r}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const a=e.clippingPlanes;let r=null;if(a!==null){const c=a.length;r=new Array(c);for(let f=0;f!==c;++f)r[f]=a[f].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Mu extends lo{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Te(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $i,this.combine=dx,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const mn=new et,$c=new Ue;let QE=0;class zi{constructor(e,a,r=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:QE++}),this.name="",this.array=e,this.itemSize=a,this.count=e!==void 0?e.length/a:0,this.normalized=r,this.usage=dv,this.updateRanges=[],this.gpuType=Ea,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,a){this.updateRanges.push({start:e,count:a})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,a,r){e*=this.itemSize,r*=a.itemSize;for(let c=0,f=this.itemSize;c<f;c++)this.array[e+c]=a.array[r+c];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let a=0,r=this.count;a<r;a++)$c.fromBufferAttribute(this,a),$c.applyMatrix3(e),this.setXY(a,$c.x,$c.y);else if(this.itemSize===3)for(let a=0,r=this.count;a<r;a++)mn.fromBufferAttribute(this,a),mn.applyMatrix3(e),this.setXYZ(a,mn.x,mn.y,mn.z);return this}applyMatrix4(e){for(let a=0,r=this.count;a<r;a++)mn.fromBufferAttribute(this,a),mn.applyMatrix4(e),this.setXYZ(a,mn.x,mn.y,mn.z);return this}applyNormalMatrix(e){for(let a=0,r=this.count;a<r;a++)mn.fromBufferAttribute(this,a),mn.applyNormalMatrix(e),this.setXYZ(a,mn.x,mn.y,mn.z);return this}transformDirection(e){for(let a=0,r=this.count;a<r;a++)mn.fromBufferAttribute(this,a),mn.transformDirection(e),this.setXYZ(a,mn.x,mn.y,mn.z);return this}set(e,a=0){return this.array.set(e,a),this}getComponent(e,a){let r=this.array[e*this.itemSize+a];return this.normalized&&(r=al(r,this.array)),r}setComponent(e,a,r){return this.normalized&&(r=Wn(r,this.array)),this.array[e*this.itemSize+a]=r,this}getX(e){let a=this.array[e*this.itemSize];return this.normalized&&(a=al(a,this.array)),a}setX(e,a){return this.normalized&&(a=Wn(a,this.array)),this.array[e*this.itemSize]=a,this}getY(e){let a=this.array[e*this.itemSize+1];return this.normalized&&(a=al(a,this.array)),a}setY(e,a){return this.normalized&&(a=Wn(a,this.array)),this.array[e*this.itemSize+1]=a,this}getZ(e){let a=this.array[e*this.itemSize+2];return this.normalized&&(a=al(a,this.array)),a}setZ(e,a){return this.normalized&&(a=Wn(a,this.array)),this.array[e*this.itemSize+2]=a,this}getW(e){let a=this.array[e*this.itemSize+3];return this.normalized&&(a=al(a,this.array)),a}setW(e,a){return this.normalized&&(a=Wn(a,this.array)),this.array[e*this.itemSize+3]=a,this}setXY(e,a,r){return e*=this.itemSize,this.normalized&&(a=Wn(a,this.array),r=Wn(r,this.array)),this.array[e+0]=a,this.array[e+1]=r,this}setXYZ(e,a,r,c){return e*=this.itemSize,this.normalized&&(a=Wn(a,this.array),r=Wn(r,this.array),c=Wn(c,this.array)),this.array[e+0]=a,this.array[e+1]=r,this.array[e+2]=c,this}setXYZW(e,a,r,c,f){return e*=this.itemSize,this.normalized&&(a=Wn(a,this.array),r=Wn(r,this.array),c=Wn(c,this.array),f=Wn(f,this.array)),this.array[e+0]=a,this.array[e+1]=r,this.array[e+2]=c,this.array[e+3]=f,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==dv&&(e.usage=this.usage),e}}class Dx extends zi{constructor(e,a,r){super(new Uint16Array(e),a,r)}}class Nx extends zi{constructor(e,a,r){super(new Uint32Array(e),a,r)}}class ui extends zi{constructor(e,a,r){super(new Float32Array(e),a,r)}}let JE=0;const Si=new sn,wd=new bn,Wr=new et,li=new yl,ll=new yl,Tn=new et;class Pi extends oo{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:JE++}),this.uuid=vl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(bx(e)?Nx:Dx)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,a){return this.attributes[e]=a,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,a,r=0){this.groups.push({start:e,count:a,materialIndex:r})}clearGroups(){this.groups=[]}setDrawRange(e,a){this.drawRange.start=e,this.drawRange.count=a}applyMatrix4(e){const a=this.attributes.position;a!==void 0&&(a.applyMatrix4(e),a.needsUpdate=!0);const r=this.attributes.normal;if(r!==void 0){const f=new de().getNormalMatrix(e);r.applyNormalMatrix(f),r.needsUpdate=!0}const c=this.attributes.tangent;return c!==void 0&&(c.transformDirection(e),c.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Si.makeRotationFromQuaternion(e),this.applyMatrix4(Si),this}rotateX(e){return Si.makeRotationX(e),this.applyMatrix4(Si),this}rotateY(e){return Si.makeRotationY(e),this.applyMatrix4(Si),this}rotateZ(e){return Si.makeRotationZ(e),this.applyMatrix4(Si),this}translate(e,a,r){return Si.makeTranslation(e,a,r),this.applyMatrix4(Si),this}scale(e,a,r){return Si.makeScale(e,a,r),this.applyMatrix4(Si),this}lookAt(e){return wd.lookAt(e),wd.updateMatrix(),this.applyMatrix4(wd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Wr).negate(),this.translate(Wr.x,Wr.y,Wr.z),this}setFromPoints(e){const a=this.getAttribute("position");if(a===void 0){const r=[];for(let c=0,f=e.length;c<f;c++){const h=e[c];r.push(h.x,h.y,h.z||0)}this.setAttribute("position",new ui(r,3))}else{const r=Math.min(e.length,a.count);for(let c=0;c<r;c++){const f=e[c];a.setXYZ(c,f.x,f.y,f.z||0)}e.length>a.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),a.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new yl);const e=this.attributes.position,a=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new et(-1/0,-1/0,-1/0),new et(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),a)for(let r=0,c=a.length;r<c;r++){const f=a[r];li.setFromBufferAttribute(f),this.morphTargetsRelative?(Tn.addVectors(this.boundingBox.min,li.min),this.boundingBox.expandByPoint(Tn),Tn.addVectors(this.boundingBox.max,li.max),this.boundingBox.expandByPoint(Tn)):(this.boundingBox.expandByPoint(li.min),this.boundingBox.expandByPoint(li.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new bu);const e=this.attributes.position,a=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new et,1/0);return}if(e){const r=this.boundingSphere.center;if(li.setFromBufferAttribute(e),a)for(let f=0,h=a.length;f<h;f++){const d=a[f];ll.setFromBufferAttribute(d),this.morphTargetsRelative?(Tn.addVectors(li.min,ll.min),li.expandByPoint(Tn),Tn.addVectors(li.max,ll.max),li.expandByPoint(Tn)):(li.expandByPoint(ll.min),li.expandByPoint(ll.max))}li.getCenter(r);let c=0;for(let f=0,h=e.count;f<h;f++)Tn.fromBufferAttribute(e,f),c=Math.max(c,r.distanceToSquared(Tn));if(a)for(let f=0,h=a.length;f<h;f++){const d=a[f],_=this.morphTargetsRelative;for(let m=0,x=d.count;m<x;m++)Tn.fromBufferAttribute(d,m),_&&(Wr.fromBufferAttribute(e,m),Tn.add(Wr)),c=Math.max(c,r.distanceToSquared(Tn))}this.boundingSphere.radius=Math.sqrt(c),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,a=this.attributes;if(e===null||a.position===void 0||a.normal===void 0||a.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const r=a.position,c=a.normal,f=a.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new zi(new Float32Array(4*r.count),4));const h=this.getAttribute("tangent"),d=[],_=[];for(let k=0;k<r.count;k++)d[k]=new et,_[k]=new et;const m=new et,x=new et,p=new et,y=new Ue,M=new Ue,b=new Ue,D=new et,S=new et;function v(k,C,w){m.fromBufferAttribute(r,k),x.fromBufferAttribute(r,C),p.fromBufferAttribute(r,w),y.fromBufferAttribute(f,k),M.fromBufferAttribute(f,C),b.fromBufferAttribute(f,w),x.sub(m),p.sub(m),M.sub(y),b.sub(y);const G=1/(M.x*b.y-b.x*M.y);isFinite(G)&&(D.copy(x).multiplyScalar(b.y).addScaledVector(p,-M.y).multiplyScalar(G),S.copy(p).multiplyScalar(M.x).addScaledVector(x,-b.x).multiplyScalar(G),d[k].add(D),d[C].add(D),d[w].add(D),_[k].add(S),_[C].add(S),_[w].add(S))}let L=this.groups;L.length===0&&(L=[{start:0,count:e.count}]);for(let k=0,C=L.length;k<C;++k){const w=L[k],G=w.start,it=w.count;for(let ct=G,gt=G+it;ct<gt;ct+=3)v(e.getX(ct+0),e.getX(ct+1),e.getX(ct+2))}const z=new et,N=new et,H=new et,F=new et;function P(k){H.fromBufferAttribute(c,k),F.copy(H);const C=d[k];z.copy(C),z.sub(H.multiplyScalar(H.dot(C))).normalize(),N.crossVectors(F,C);const G=N.dot(_[k])<0?-1:1;h.setXYZW(k,z.x,z.y,z.z,G)}for(let k=0,C=L.length;k<C;++k){const w=L[k],G=w.start,it=w.count;for(let ct=G,gt=G+it;ct<gt;ct+=3)P(e.getX(ct+0)),P(e.getX(ct+1)),P(e.getX(ct+2))}}computeVertexNormals(){const e=this.index,a=this.getAttribute("position");if(a!==void 0){let r=this.getAttribute("normal");if(r===void 0)r=new zi(new Float32Array(a.count*3),3),this.setAttribute("normal",r);else for(let y=0,M=r.count;y<M;y++)r.setXYZ(y,0,0,0);const c=new et,f=new et,h=new et,d=new et,_=new et,m=new et,x=new et,p=new et;if(e)for(let y=0,M=e.count;y<M;y+=3){const b=e.getX(y+0),D=e.getX(y+1),S=e.getX(y+2);c.fromBufferAttribute(a,b),f.fromBufferAttribute(a,D),h.fromBufferAttribute(a,S),x.subVectors(h,f),p.subVectors(c,f),x.cross(p),d.fromBufferAttribute(r,b),_.fromBufferAttribute(r,D),m.fromBufferAttribute(r,S),d.add(x),_.add(x),m.add(x),r.setXYZ(b,d.x,d.y,d.z),r.setXYZ(D,_.x,_.y,_.z),r.setXYZ(S,m.x,m.y,m.z)}else for(let y=0,M=a.count;y<M;y+=3)c.fromBufferAttribute(a,y+0),f.fromBufferAttribute(a,y+1),h.fromBufferAttribute(a,y+2),x.subVectors(h,f),p.subVectors(c,f),x.cross(p),r.setXYZ(y+0,x.x,x.y,x.z),r.setXYZ(y+1,x.x,x.y,x.z),r.setXYZ(y+2,x.x,x.y,x.z);this.normalizeNormals(),r.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let a=0,r=e.count;a<r;a++)Tn.fromBufferAttribute(e,a),Tn.normalize(),e.setXYZ(a,Tn.x,Tn.y,Tn.z)}toNonIndexed(){function e(d,_){const m=d.array,x=d.itemSize,p=d.normalized,y=new m.constructor(_.length*x);let M=0,b=0;for(let D=0,S=_.length;D<S;D++){d.isInterleavedBufferAttribute?M=_[D]*d.data.stride+d.offset:M=_[D]*x;for(let v=0;v<x;v++)y[b++]=m[M++]}return new zi(y,x,p)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const a=new Pi,r=this.index.array,c=this.attributes;for(const d in c){const _=c[d],m=e(_,r);a.setAttribute(d,m)}const f=this.morphAttributes;for(const d in f){const _=[],m=f[d];for(let x=0,p=m.length;x<p;x++){const y=m[x],M=e(y,r);_.push(M)}a.morphAttributes[d]=_}a.morphTargetsRelative=this.morphTargetsRelative;const h=this.groups;for(let d=0,_=h.length;d<_;d++){const m=h[d];a.addGroup(m.start,m.count,m.materialIndex)}return a}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const _=this.parameters;for(const m in _)_[m]!==void 0&&(e[m]=_[m]);return e}e.data={attributes:{}};const a=this.index;a!==null&&(e.data.index={type:a.array.constructor.name,array:Array.prototype.slice.call(a.array)});const r=this.attributes;for(const _ in r){const m=r[_];e.data.attributes[_]=m.toJSON(e.data)}const c={};let f=!1;for(const _ in this.morphAttributes){const m=this.morphAttributes[_],x=[];for(let p=0,y=m.length;p<y;p++){const M=m[p];x.push(M.toJSON(e.data))}x.length>0&&(c[_]=x,f=!0)}f&&(e.data.morphAttributes=c,e.data.morphTargetsRelative=this.morphTargetsRelative);const h=this.groups;h.length>0&&(e.data.groups=JSON.parse(JSON.stringify(h)));const d=this.boundingSphere;return d!==null&&(e.data.boundingSphere=d.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const a={};this.name=e.name;const r=e.index;r!==null&&this.setIndex(r.clone());const c=e.attributes;for(const m in c){const x=c[m];this.setAttribute(m,x.clone(a))}const f=e.morphAttributes;for(const m in f){const x=[],p=f[m];for(let y=0,M=p.length;y<M;y++)x.push(p[y].clone(a));this.morphAttributes[m]=x}this.morphTargetsRelative=e.morphTargetsRelative;const h=e.groups;for(let m=0,x=h.length;m<x;m++){const p=h[m];this.addGroup(p.start,p.count,p.materialIndex)}const d=e.boundingBox;d!==null&&(this.boundingBox=d.clone());const _=e.boundingSphere;return _!==null&&(this.boundingSphere=_.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Rv=new sn,Is=new Rx,tu=new bu,Cv=new et,eu=new et,nu=new et,iu=new et,Dd=new et,au=new et,wv=new et,su=new et;class tn extends bn{constructor(e=new Pi,a=new Mu){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=a,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,a){return super.copy(e,a),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const a=this.geometry.morphAttributes,r=Object.keys(a);if(r.length>0){const c=a[r[0]];if(c!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let f=0,h=c.length;f<h;f++){const d=c[f].name||String(f);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=f}}}}getVertexPosition(e,a){const r=this.geometry,c=r.attributes.position,f=r.morphAttributes.position,h=r.morphTargetsRelative;a.fromBufferAttribute(c,e);const d=this.morphTargetInfluences;if(f&&d){au.set(0,0,0);for(let _=0,m=f.length;_<m;_++){const x=d[_],p=f[_];x!==0&&(Dd.fromBufferAttribute(p,e),h?au.addScaledVector(Dd,x):au.addScaledVector(Dd.sub(a),x))}a.add(au)}return a}raycast(e,a){const r=this.geometry,c=this.material,f=this.matrixWorld;c!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),tu.copy(r.boundingSphere),tu.applyMatrix4(f),Is.copy(e.ray).recast(e.near),!(tu.containsPoint(Is.origin)===!1&&(Is.intersectSphere(tu,Cv)===null||Is.origin.distanceToSquared(Cv)>(e.far-e.near)**2))&&(Rv.copy(f).invert(),Is.copy(e.ray).applyMatrix4(Rv),!(r.boundingBox!==null&&Is.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,a,Is)))}_computeIntersections(e,a,r){let c;const f=this.geometry,h=this.material,d=f.index,_=f.attributes.position,m=f.attributes.uv,x=f.attributes.uv1,p=f.attributes.normal,y=f.groups,M=f.drawRange;if(d!==null)if(Array.isArray(h))for(let b=0,D=y.length;b<D;b++){const S=y[b],v=h[S.materialIndex],L=Math.max(S.start,M.start),z=Math.min(d.count,Math.min(S.start+S.count,M.start+M.count));for(let N=L,H=z;N<H;N+=3){const F=d.getX(N),P=d.getX(N+1),k=d.getX(N+2);c=ru(this,v,e,r,m,x,p,F,P,k),c&&(c.faceIndex=Math.floor(N/3),c.face.materialIndex=S.materialIndex,a.push(c))}}else{const b=Math.max(0,M.start),D=Math.min(d.count,M.start+M.count);for(let S=b,v=D;S<v;S+=3){const L=d.getX(S),z=d.getX(S+1),N=d.getX(S+2);c=ru(this,h,e,r,m,x,p,L,z,N),c&&(c.faceIndex=Math.floor(S/3),a.push(c))}}else if(_!==void 0)if(Array.isArray(h))for(let b=0,D=y.length;b<D;b++){const S=y[b],v=h[S.materialIndex],L=Math.max(S.start,M.start),z=Math.min(_.count,Math.min(S.start+S.count,M.start+M.count));for(let N=L,H=z;N<H;N+=3){const F=N,P=N+1,k=N+2;c=ru(this,v,e,r,m,x,p,F,P,k),c&&(c.faceIndex=Math.floor(N/3),c.face.materialIndex=S.materialIndex,a.push(c))}}else{const b=Math.max(0,M.start),D=Math.min(_.count,M.start+M.count);for(let S=b,v=D;S<v;S+=3){const L=S,z=S+1,N=S+2;c=ru(this,h,e,r,m,x,p,L,z,N),c&&(c.faceIndex=Math.floor(S/3),a.push(c))}}}}function $E(o,e,a,r,c,f,h,d){let _;if(e.side===Kn?_=r.intersectTriangle(h,f,c,!0,d):_=r.intersectTriangle(c,f,h,e.side===cs,d),_===null)return null;su.copy(d),su.applyMatrix4(o.matrixWorld);const m=a.ray.origin.distanceTo(su);return m<a.near||m>a.far?null:{distance:m,point:su.clone(),object:o}}function ru(o,e,a,r,c,f,h,d,_,m){o.getVertexPosition(d,eu),o.getVertexPosition(_,nu),o.getVertexPosition(m,iu);const x=$E(o,e,a,r,eu,nu,iu,wv);if(x){const p=new et;Ui.getBarycoord(wv,eu,nu,iu,p),c&&(x.uv=Ui.getInterpolatedAttribute(c,d,_,m,p,new Ue)),f&&(x.uv1=Ui.getInterpolatedAttribute(f,d,_,m,p,new Ue)),h&&(x.normal=Ui.getInterpolatedAttribute(h,d,_,m,p,new et),x.normal.dot(r.direction)>0&&x.normal.multiplyScalar(-1));const y={a:d,b:_,c:m,normal:new et,materialIndex:0};Ui.getNormal(eu,nu,iu,y.normal),x.face=y,x.barycoord=p}return x}class Qs extends Pi{constructor(e=1,a=1,r=1,c=1,f=1,h=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:a,depth:r,widthSegments:c,heightSegments:f,depthSegments:h};const d=this;c=Math.floor(c),f=Math.floor(f),h=Math.floor(h);const _=[],m=[],x=[],p=[];let y=0,M=0;b("z","y","x",-1,-1,r,a,e,h,f,0),b("z","y","x",1,-1,r,a,-e,h,f,1),b("x","z","y",1,1,e,r,a,c,h,2),b("x","z","y",1,-1,e,r,-a,c,h,3),b("x","y","z",1,-1,e,a,r,c,f,4),b("x","y","z",-1,-1,e,a,-r,c,f,5),this.setIndex(_),this.setAttribute("position",new ui(m,3)),this.setAttribute("normal",new ui(x,3)),this.setAttribute("uv",new ui(p,2));function b(D,S,v,L,z,N,H,F,P,k,C){const w=N/P,G=H/k,it=N/2,ct=H/2,gt=F/2,ut=P+1,W=k+1;let rt=0,K=0;const vt=new et;for(let yt=0;yt<W;yt++){const Gt=yt*G-ct;for(let re=0;re<ut;re++){const Ae=re*w-it;vt[D]=Ae*L,vt[S]=Gt*z,vt[v]=gt,m.push(vt.x,vt.y,vt.z),vt[D]=0,vt[S]=0,vt[v]=F>0?1:-1,x.push(vt.x,vt.y,vt.z),p.push(re/P),p.push(1-yt/k),rt+=1}}for(let yt=0;yt<k;yt++)for(let Gt=0;Gt<P;Gt++){const re=y+Gt+ut*yt,Ae=y+Gt+ut*(yt+1),B=y+(Gt+1)+ut*(yt+1),ft=y+(Gt+1)+ut*yt;_.push(re,Ae,ft),_.push(Ae,B,ft),K+=6}d.addGroup(M,K,C),M+=K,y+=rt}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Qs(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function ro(o){const e={};for(const a in o){e[a]={};for(const r in o[a]){const c=o[a][r];c&&(c.isColor||c.isMatrix3||c.isMatrix4||c.isVector2||c.isVector3||c.isVector4||c.isTexture||c.isQuaternion)?c.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[a][r]=null):e[a][r]=c.clone():Array.isArray(c)?e[a][r]=c.slice():e[a][r]=c}}return e}function Vn(o){const e={};for(let a=0;a<o.length;a++){const r=ro(o[a]);for(const c in r)e[c]=r[c]}return e}function t1(o){const e=[];for(let a=0;a<o.length;a++)e.push(o[a].clone());return e}function Ux(o){const e=o.getRenderTarget();return e===null?o.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Ne.workingColorSpace}const e1={clone:ro,merge:Vn};var n1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,i1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class us extends lo{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=n1,this.fragmentShader=i1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=ro(e.uniforms),this.uniformsGroups=t1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const a=super.toJSON(e);a.glslVersion=this.glslVersion,a.uniforms={};for(const c in this.uniforms){const h=this.uniforms[c].value;h&&h.isTexture?a.uniforms[c]={type:"t",value:h.toJSON(e).uuid}:h&&h.isColor?a.uniforms[c]={type:"c",value:h.getHex()}:h&&h.isVector2?a.uniforms[c]={type:"v2",value:h.toArray()}:h&&h.isVector3?a.uniforms[c]={type:"v3",value:h.toArray()}:h&&h.isVector4?a.uniforms[c]={type:"v4",value:h.toArray()}:h&&h.isMatrix3?a.uniforms[c]={type:"m3",value:h.toArray()}:h&&h.isMatrix4?a.uniforms[c]={type:"m4",value:h.toArray()}:a.uniforms[c]={value:h}}Object.keys(this.defines).length>0&&(a.defines=this.defines),a.vertexShader=this.vertexShader,a.fragmentShader=this.fragmentShader,a.lights=this.lights,a.clipping=this.clipping;const r={};for(const c in this.extensions)this.extensions[c]===!0&&(r[c]=!0);return Object.keys(r).length>0&&(a.extensions=r),a}}let Lx=class extends bn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new sn,this.projectionMatrix=new sn,this.projectionMatrixInverse=new sn,this.coordinateSystem=Qi,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,a){return super.copy(e,a),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,a){super.updateWorldMatrix(e,a),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}};const as=new et,Dv=new Ue,Nv=new Ue;class Zn extends Lx{constructor(e=50,a=1,r=.1,c=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=c,this.focus=10,this.aspect=a,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,a){return super.copy(e,a),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const a=.5*this.getFilmHeight()/e;this.fov=Cp*2*Math.atan(a),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(cd*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Cp*2*Math.atan(Math.tan(cd*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,a,r){as.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(as.x,as.y).multiplyScalar(-e/as.z),as.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(as.x,as.y).multiplyScalar(-e/as.z)}getViewSize(e,a){return this.getViewBounds(e,Dv,Nv),a.subVectors(Nv,Dv)}setViewOffset(e,a,r,c,f,h){this.aspect=e/a,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=a,this.view.offsetX=r,this.view.offsetY=c,this.view.width=f,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let a=e*Math.tan(cd*.5*this.fov)/this.zoom,r=2*a,c=this.aspect*r,f=-.5*c;const h=this.view;if(this.view!==null&&this.view.enabled){const _=h.fullWidth,m=h.fullHeight;f+=h.offsetX*c/_,a-=h.offsetY*r/m,c*=h.width/_,r*=h.height/m}const d=this.filmOffset;d!==0&&(f+=e*d/this.getFilmWidth()),this.projectionMatrix.makePerspective(f,f+c,a,a-r,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const a=super.toJSON(e);return a.object.fov=this.fov,a.object.zoom=this.zoom,a.object.near=this.near,a.object.far=this.far,a.object.focus=this.focus,a.object.aspect=this.aspect,this.view!==null&&(a.object.view=Object.assign({},this.view)),a.object.filmGauge=this.filmGauge,a.object.filmOffset=this.filmOffset,a}}const Zr=-90,Kr=1;class a1 extends bn{constructor(e,a,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;const c=new Zn(Zr,Kr,e,a);c.layers=this.layers,this.add(c);const f=new Zn(Zr,Kr,e,a);f.layers=this.layers,this.add(f);const h=new Zn(Zr,Kr,e,a);h.layers=this.layers,this.add(h);const d=new Zn(Zr,Kr,e,a);d.layers=this.layers,this.add(d);const _=new Zn(Zr,Kr,e,a);_.layers=this.layers,this.add(_);const m=new Zn(Zr,Kr,e,a);m.layers=this.layers,this.add(m)}updateCoordinateSystem(){const e=this.coordinateSystem,a=this.children.concat(),[r,c,f,h,d,_]=a;for(const m of a)this.remove(m);if(e===Qi)r.up.set(0,1,0),r.lookAt(1,0,0),c.up.set(0,1,0),c.lookAt(-1,0,0),f.up.set(0,0,-1),f.lookAt(0,1,0),h.up.set(0,0,1),h.lookAt(0,-1,0),d.up.set(0,1,0),d.lookAt(0,0,1),_.up.set(0,1,0),_.lookAt(0,0,-1);else if(e===yu)r.up.set(0,-1,0),r.lookAt(-1,0,0),c.up.set(0,-1,0),c.lookAt(1,0,0),f.up.set(0,0,1),f.lookAt(0,1,0),h.up.set(0,0,-1),h.lookAt(0,-1,0),d.up.set(0,-1,0),d.lookAt(0,0,1),_.up.set(0,-1,0),_.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const m of a)this.add(m),m.updateMatrixWorld()}update(e,a){this.parent===null&&this.updateMatrixWorld();const{renderTarget:r,activeMipmapLevel:c}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[f,h,d,_,m,x]=this.children,p=e.getRenderTarget(),y=e.getActiveCubeFace(),M=e.getActiveMipmapLevel(),b=e.xr.enabled;e.xr.enabled=!1;const D=r.texture.generateMipmaps;r.texture.generateMipmaps=!1,e.setRenderTarget(r,0,c),e.render(a,f),e.setRenderTarget(r,1,c),e.render(a,h),e.setRenderTarget(r,2,c),e.render(a,d),e.setRenderTarget(r,3,c),e.render(a,_),e.setRenderTarget(r,4,c),e.render(a,m),r.texture.generateMipmaps=D,e.setRenderTarget(r,5,c),e.render(a,x),e.setRenderTarget(p,y,M),e.xr.enabled=b,r.texture.needsPMREMUpdate=!0}}class Ox extends Qn{constructor(e=[],a=io,r,c,f,h,d,_,m,x){super(e,a,r,c,f,h,d,_,m,x),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class s1 extends Ks{constructor(e=1,a={}){super(e,e,a),this.isWebGLCubeRenderTarget=!0;const r={width:e,height:e,depth:1},c=[r,r,r,r,r,r];this.texture=new Ox(c),this._setTextureOptions(a),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,a){this.texture.type=a.type,this.texture.colorSpace=a.colorSpace,this.texture.generateMipmaps=a.generateMipmaps,this.texture.minFilter=a.minFilter,this.texture.magFilter=a.magFilter;const r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},c=new Qs(5,5,5),f=new us({name:"CubemapFromEquirect",uniforms:ro(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:Kn,blending:rs});f.uniforms.tEquirect.value=a;const h=new tn(c,f),d=a.minFilter;return a.minFilter===qs&&(a.minFilter=Ki),new a1(1,10,this).update(e,h),a.minFilter=d,h.geometry.dispose(),h.material.dispose(),this}clear(e,a=!0,r=!0,c=!0){const f=e.getRenderTarget();for(let h=0;h<6;h++)e.setRenderTarget(this,h),e.clear(a,r,c);e.setRenderTarget(f)}}class Jr extends bn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const r1={type:"move"};class Nd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Jr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Jr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new et,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new et),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Jr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new et,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new et),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const a=this._hand;if(a)for(const r of e.hand.values())this._getHandJoint(a,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,a,r){let c=null,f=null,h=null;const d=this._targetRay,_=this._grip,m=this._hand;if(e&&a.session.visibilityState!=="visible-blurred"){if(m&&e.hand){h=!0;for(const D of e.hand.values()){const S=a.getJointPose(D,r),v=this._getHandJoint(m,D);S!==null&&(v.matrix.fromArray(S.transform.matrix),v.matrix.decompose(v.position,v.rotation,v.scale),v.matrixWorldNeedsUpdate=!0,v.jointRadius=S.radius),v.visible=S!==null}const x=m.joints["index-finger-tip"],p=m.joints["thumb-tip"],y=x.position.distanceTo(p.position),M=.02,b=.005;m.inputState.pinching&&y>M+b?(m.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!m.inputState.pinching&&y<=M-b&&(m.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else _!==null&&e.gripSpace&&(f=a.getPose(e.gripSpace,r),f!==null&&(_.matrix.fromArray(f.transform.matrix),_.matrix.decompose(_.position,_.rotation,_.scale),_.matrixWorldNeedsUpdate=!0,f.linearVelocity?(_.hasLinearVelocity=!0,_.linearVelocity.copy(f.linearVelocity)):_.hasLinearVelocity=!1,f.angularVelocity?(_.hasAngularVelocity=!0,_.angularVelocity.copy(f.angularVelocity)):_.hasAngularVelocity=!1));d!==null&&(c=a.getPose(e.targetRaySpace,r),c===null&&f!==null&&(c=f),c!==null&&(d.matrix.fromArray(c.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,c.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(c.linearVelocity)):d.hasLinearVelocity=!1,c.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(c.angularVelocity)):d.hasAngularVelocity=!1,this.dispatchEvent(r1)))}return d!==null&&(d.visible=c!==null),_!==null&&(_.visible=f!==null),m!==null&&(m.visible=h!==null),this}_getHandJoint(e,a){if(e.joints[a.jointName]===void 0){const r=new Jr;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[a.jointName]=r,e.add(r)}return e.joints[a.jointName]}}class zx extends bn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new $i,this.environmentIntensity=1,this.environmentRotation=new $i,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,a){return super.copy(e,a),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const a=super.toJSON(e);return this.fog!==null&&(a.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(a.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(a.object.backgroundIntensity=this.backgroundIntensity),a.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(a.object.environmentIntensity=this.environmentIntensity),a.object.environmentRotation=this.environmentRotation.toArray(),a}}const Ud=new et,o1=new et,l1=new de;class Gs{constructor(e=new et(1,0,0),a=0){this.isPlane=!0,this.normal=e,this.constant=a}set(e,a){return this.normal.copy(e),this.constant=a,this}setComponents(e,a,r,c){return this.normal.set(e,a,r),this.constant=c,this}setFromNormalAndCoplanarPoint(e,a){return this.normal.copy(e),this.constant=-a.dot(this.normal),this}setFromCoplanarPoints(e,a,r){const c=Ud.subVectors(r,a).cross(o1.subVectors(e,a)).normalize();return this.setFromNormalAndCoplanarPoint(c,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,a){return a.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,a){const r=e.delta(Ud),c=this.normal.dot(r);if(c===0)return this.distanceToPoint(e.start)===0?a.copy(e.start):null;const f=-(e.start.dot(this.normal)+this.constant)/c;return f<0||f>1?null:a.copy(e.start).addScaledVector(r,f)}intersectsLine(e){const a=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return a<0&&r>0||r<0&&a>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,a){const r=a||l1.getNormalMatrix(e),c=this.coplanarPoint(Ud).applyMatrix4(e),f=this.normal.applyMatrix3(r).normalize();return this.constant=-c.dot(f),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Bs=new bu,c1=new Ue(.5,.5),ou=new et;class Vp{constructor(e=new Gs,a=new Gs,r=new Gs,c=new Gs,f=new Gs,h=new Gs){this.planes=[e,a,r,c,f,h]}set(e,a,r,c,f,h){const d=this.planes;return d[0].copy(e),d[1].copy(a),d[2].copy(r),d[3].copy(c),d[4].copy(f),d[5].copy(h),this}copy(e){const a=this.planes;for(let r=0;r<6;r++)a[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,a=Qi,r=!1){const c=this.planes,f=e.elements,h=f[0],d=f[1],_=f[2],m=f[3],x=f[4],p=f[5],y=f[6],M=f[7],b=f[8],D=f[9],S=f[10],v=f[11],L=f[12],z=f[13],N=f[14],H=f[15];if(c[0].setComponents(m-h,M-x,v-b,H-L).normalize(),c[1].setComponents(m+h,M+x,v+b,H+L).normalize(),c[2].setComponents(m+d,M+p,v+D,H+z).normalize(),c[3].setComponents(m-d,M-p,v-D,H-z).normalize(),r)c[4].setComponents(_,y,S,N).normalize(),c[5].setComponents(m-_,M-y,v-S,H-N).normalize();else if(c[4].setComponents(m-_,M-y,v-S,H-N).normalize(),a===Qi)c[5].setComponents(m+_,M+y,v+S,H+N).normalize();else if(a===yu)c[5].setComponents(_,y,S,N).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+a);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Bs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const a=e.geometry;a.boundingSphere===null&&a.computeBoundingSphere(),Bs.copy(a.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Bs)}intersectsSprite(e){Bs.center.set(0,0,0);const a=c1.distanceTo(e.center);return Bs.radius=.7071067811865476+a,Bs.applyMatrix4(e.matrixWorld),this.intersectsSphere(Bs)}intersectsSphere(e){const a=this.planes,r=e.center,c=-e.radius;for(let f=0;f<6;f++)if(a[f].distanceToPoint(r)<c)return!1;return!0}intersectsBox(e){const a=this.planes;for(let r=0;r<6;r++){const c=a[r];if(ou.x=c.normal.x>0?e.max.x:e.min.x,ou.y=c.normal.y>0?e.max.y:e.min.y,ou.z=c.normal.z>0?e.max.z:e.min.z,c.distanceToPoint(ou)<0)return!1}return!0}containsPoint(e){const a=this.planes;for(let r=0;r<6;r++)if(a[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Px extends lo{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Te(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Uv=new sn,wp=new Rx,lu=new bu,cu=new et;class u1 extends bn{constructor(e=new Pi,a=new Px){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=a,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,a){return super.copy(e,a),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,a){const r=this.geometry,c=this.matrixWorld,f=e.params.Points.threshold,h=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),lu.copy(r.boundingSphere),lu.applyMatrix4(c),lu.radius+=f,e.ray.intersectsSphere(lu)===!1)return;Uv.copy(c).invert(),wp.copy(e.ray).applyMatrix4(Uv);const d=f/((this.scale.x+this.scale.y+this.scale.z)/3),_=d*d,m=r.index,p=r.attributes.position;if(m!==null){const y=Math.max(0,h.start),M=Math.min(m.count,h.start+h.count);for(let b=y,D=M;b<D;b++){const S=m.getX(b);cu.fromBufferAttribute(p,S),Lv(cu,S,_,c,e,a,this)}}else{const y=Math.max(0,h.start),M=Math.min(p.count,h.start+h.count);for(let b=y,D=M;b<D;b++)cu.fromBufferAttribute(p,b),Lv(cu,b,_,c,e,a,this)}}updateMorphTargets(){const a=this.geometry.morphAttributes,r=Object.keys(a);if(r.length>0){const c=a[r[0]];if(c!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let f=0,h=c.length;f<h;f++){const d=c[f].name||String(f);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=f}}}}}function Lv(o,e,a,r,c,f,h){const d=wp.distanceSqToPoint(o);if(d<a){const _=new et;wp.closestPointToPoint(o,_),_.applyMatrix4(r);const m=c.ray.origin.distanceTo(_);if(m<c.near||m>c.far)return;f.push({distance:m,distanceToRay:Math.sqrt(d),point:_,index:e,face:null,faceIndex:null,barycoord:null,object:h})}}class Ix extends Qn{constructor(e,a,r=Zs,c,f,h,d=Oi,_=Oi,m,x=dl,p=1){if(x!==dl&&x!==pl)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const y={width:e,height:a,depth:p};super(y,c,f,h,d,_,x,r,m),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Gp(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const a=super.toJSON(e);return this.compareFunction!==null&&(a.compareFunction=this.compareFunction),a}}class Bx extends Qn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Ys extends Pi{constructor(e=1,a=1,r=4,c=8,f=1){super(),this.type="CapsuleGeometry",this.parameters={radius:e,height:a,capSegments:r,radialSegments:c,heightSegments:f},a=Math.max(0,a),r=Math.max(1,Math.floor(r)),c=Math.max(3,Math.floor(c)),f=Math.max(1,Math.floor(f));const h=[],d=[],_=[],m=[],x=a/2,p=Math.PI/2*e,y=a,M=2*p+y,b=r*2+f,D=c+1,S=new et,v=new et;for(let L=0;L<=b;L++){let z=0,N=0,H=0,F=0;if(L<=r){const C=L/r,w=C*Math.PI/2;N=-x-e*Math.cos(w),H=e*Math.sin(w),F=-e*Math.cos(w),z=C*p}else if(L<=r+f){const C=(L-r)/f;N=-x+C*a,H=e,F=0,z=p+C*y}else{const C=(L-r-f)/r,w=C*Math.PI/2;N=x+e*Math.sin(w),H=e*Math.cos(w),F=e*Math.sin(w),z=p+y+C*p}const P=Math.max(0,Math.min(1,z/M));let k=0;L===0?k=.5/c:L===b&&(k=-.5/c);for(let C=0;C<=c;C++){const w=C/c,G=w*Math.PI*2,it=Math.sin(G),ct=Math.cos(G);v.x=-H*ct,v.y=N,v.z=H*it,d.push(v.x,v.y,v.z),S.set(-H*ct,F,H*it),S.normalize(),_.push(S.x,S.y,S.z),m.push(w+k,P)}if(L>0){const C=(L-1)*D;for(let w=0;w<c;w++){const G=C+w,it=C+w+1,ct=L*D+w,gt=L*D+w+1;h.push(G,it,ct),h.push(it,gt,ct)}}}this.setIndex(h),this.setAttribute("position",new ui(d,3)),this.setAttribute("normal",new ui(_,3)),this.setAttribute("uv",new ui(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ys(e.radius,e.height,e.capSegments,e.radialSegments,e.heightSegments)}}class co extends Pi{constructor(e=1,a=1,r=1,c=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:a,widthSegments:r,heightSegments:c};const f=e/2,h=a/2,d=Math.floor(r),_=Math.floor(c),m=d+1,x=_+1,p=e/d,y=a/_,M=[],b=[],D=[],S=[];for(let v=0;v<x;v++){const L=v*y-h;for(let z=0;z<m;z++){const N=z*p-f;b.push(N,-L,0),D.push(0,0,1),S.push(z/d),S.push(1-v/_)}}for(let v=0;v<_;v++)for(let L=0;L<d;L++){const z=L+m*v,N=L+m*(v+1),H=L+1+m*(v+1),F=L+1+m*v;M.push(z,N,F),M.push(N,H,F)}this.setIndex(M),this.setAttribute("position",new ui(b,3)),this.setAttribute("normal",new ui(D,3)),this.setAttribute("uv",new ui(S,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new co(e.width,e.height,e.widthSegments,e.heightSegments)}}class ls extends Pi{constructor(e=1,a=32,r=16,c=0,f=Math.PI*2,h=0,d=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:a,heightSegments:r,phiStart:c,phiLength:f,thetaStart:h,thetaLength:d},a=Math.max(3,Math.floor(a)),r=Math.max(2,Math.floor(r));const _=Math.min(h+d,Math.PI);let m=0;const x=[],p=new et,y=new et,M=[],b=[],D=[],S=[];for(let v=0;v<=r;v++){const L=[],z=v/r;let N=0;v===0&&h===0?N=.5/a:v===r&&_===Math.PI&&(N=-.5/a);for(let H=0;H<=a;H++){const F=H/a;p.x=-e*Math.cos(c+F*f)*Math.sin(h+z*d),p.y=e*Math.cos(h+z*d),p.z=e*Math.sin(c+F*f)*Math.sin(h+z*d),b.push(p.x,p.y,p.z),y.copy(p).normalize(),D.push(y.x,y.y,y.z),S.push(F+N,1-z),L.push(m++)}x.push(L)}for(let v=0;v<r;v++)for(let L=0;L<a;L++){const z=x[v][L+1],N=x[v][L],H=x[v+1][L],F=x[v+1][L+1];(v!==0||h>0)&&M.push(z,N,F),(v!==r-1||_<Math.PI)&&M.push(N,H,F)}this.setIndex(M),this.setAttribute("position",new ui(b,3)),this.setAttribute("normal",new ui(D,3)),this.setAttribute("uv",new ui(S,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ls(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class ci extends lo{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Te(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Te(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Ex,this.normalScale=new Ue(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new $i,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class f1 extends lo{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=TE,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class h1 extends lo{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class kp extends bn{constructor(e,a=1){super(),this.isLight=!0,this.type="Light",this.color=new Te(e),this.intensity=a}dispose(){}copy(e,a){return super.copy(e,a),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const a=super.toJSON(e);return a.object.color=this.color.getHex(),a.object.intensity=this.intensity,this.groundColor!==void 0&&(a.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(a.object.distance=this.distance),this.angle!==void 0&&(a.object.angle=this.angle),this.decay!==void 0&&(a.object.decay=this.decay),this.penumbra!==void 0&&(a.object.penumbra=this.penumbra),this.shadow!==void 0&&(a.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(a.object.target=this.target.uuid),a}}class Fx extends kp{constructor(e,a,r){super(e,r),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(bn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Te(a)}copy(e,a){return super.copy(e,a),this.groundColor.copy(e.groundColor),this}}const Ld=new sn,Ov=new et,zv=new et;class Hx{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Ue(512,512),this.mapType=Ji,this.map=null,this.mapPass=null,this.matrix=new sn,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Vp,this._frameExtents=new Ue(1,1),this._viewportCount=1,this._viewports=[new je(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const a=this.camera,r=this.matrix;Ov.setFromMatrixPosition(e.matrixWorld),a.position.copy(Ov),zv.setFromMatrixPosition(e.target.matrixWorld),a.lookAt(zv),a.updateMatrixWorld(),Ld.multiplyMatrices(a.projectionMatrix,a.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ld,a.coordinateSystem,a.reversedDepth),a.reversedDepth?r.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):r.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),r.multiply(Ld)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Pv=new sn,cl=new et,Od=new et;class d1 extends Hx{constructor(){super(new Zn(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Ue(4,2),this._viewportCount=6,this._viewports=[new je(2,1,1,1),new je(0,1,1,1),new je(3,1,1,1),new je(1,1,1,1),new je(3,0,1,1),new je(1,0,1,1)],this._cubeDirections=[new et(1,0,0),new et(-1,0,0),new et(0,0,1),new et(0,0,-1),new et(0,1,0),new et(0,-1,0)],this._cubeUps=[new et(0,1,0),new et(0,1,0),new et(0,1,0),new et(0,1,0),new et(0,0,1),new et(0,0,-1)]}updateMatrices(e,a=0){const r=this.camera,c=this.matrix,f=e.distance||r.far;f!==r.far&&(r.far=f,r.updateProjectionMatrix()),cl.setFromMatrixPosition(e.matrixWorld),r.position.copy(cl),Od.copy(r.position),Od.add(this._cubeDirections[a]),r.up.copy(this._cubeUps[a]),r.lookAt(Od),r.updateMatrixWorld(),c.makeTranslation(-cl.x,-cl.y,-cl.z),Pv.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Pv,r.coordinateSystem,r.reversedDepth)}}class Dp extends kp{constructor(e,a,r=0,c=2){super(e,a),this.isPointLight=!0,this.type="PointLight",this.distance=r,this.decay=c,this.shadow=new d1}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,a){return super.copy(e,a),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Gx extends Lx{constructor(e=-1,a=1,r=1,c=-1,f=.1,h=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=a,this.top=r,this.bottom=c,this.near=f,this.far=h,this.updateProjectionMatrix()}copy(e,a){return super.copy(e,a),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,a,r,c,f,h){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=a,this.view.offsetX=r,this.view.offsetY=c,this.view.width=f,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),a=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,c=(this.top+this.bottom)/2;let f=r-e,h=r+e,d=c+a,_=c-a;if(this.view!==null&&this.view.enabled){const m=(this.right-this.left)/this.view.fullWidth/this.zoom,x=(this.top-this.bottom)/this.view.fullHeight/this.zoom;f+=m*this.view.offsetX,h=f+m*this.view.width,d-=x*this.view.offsetY,_=d-x*this.view.height}this.projectionMatrix.makeOrthographic(f,h,d,_,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const a=super.toJSON(e);return a.object.zoom=this.zoom,a.object.left=this.left,a.object.right=this.right,a.object.top=this.top,a.object.bottom=this.bottom,a.object.near=this.near,a.object.far=this.far,this.view!==null&&(a.object.view=Object.assign({},this.view)),a}}class p1 extends Hx{constructor(){super(new Gx(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Vx extends kp{constructor(e,a){super(e,a),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(bn.DEFAULT_UP),this.updateMatrix(),this.target=new bn,this.shadow=new p1}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class m1 extends Zn{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}function Iv(o,e,a,r){const c=g1(r);switch(a){case xx:return o*e;case Sx:return o*e/c.components*c.byteLength;case Bp:return o*e/c.components*c.byteLength;case Mx:return o*e*2/c.components*c.byteLength;case Fp:return o*e*2/c.components*c.byteLength;case yx:return o*e*3/c.components*c.byteLength;case Li:return o*e*4/c.components*c.byteLength;case Hp:return o*e*4/c.components*c.byteLength;case pu:case mu:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case gu:case _u:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case ep:case ip:return Math.max(o,16)*Math.max(e,8)/4;case tp:case np:return Math.max(o,8)*Math.max(e,8)/2;case ap:case sp:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case rp:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case op:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case lp:return Math.floor((o+4)/5)*Math.floor((e+3)/4)*16;case cp:return Math.floor((o+4)/5)*Math.floor((e+4)/5)*16;case up:return Math.floor((o+5)/6)*Math.floor((e+4)/5)*16;case fp:return Math.floor((o+5)/6)*Math.floor((e+5)/6)*16;case hp:return Math.floor((o+7)/8)*Math.floor((e+4)/5)*16;case dp:return Math.floor((o+7)/8)*Math.floor((e+5)/6)*16;case pp:return Math.floor((o+7)/8)*Math.floor((e+7)/8)*16;case mp:return Math.floor((o+9)/10)*Math.floor((e+4)/5)*16;case gp:return Math.floor((o+9)/10)*Math.floor((e+5)/6)*16;case _p:return Math.floor((o+9)/10)*Math.floor((e+7)/8)*16;case vp:return Math.floor((o+9)/10)*Math.floor((e+9)/10)*16;case xp:return Math.floor((o+11)/12)*Math.floor((e+9)/10)*16;case yp:return Math.floor((o+11)/12)*Math.floor((e+11)/12)*16;case Sp:case Mp:case Ep:return Math.ceil(o/4)*Math.ceil(e/4)*16;case Tp:case bp:return Math.ceil(o/4)*Math.ceil(e/4)*8;case Ap:case Rp:return Math.ceil(o/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${a} format.`)}function g1(o){switch(o){case Ji:case mx:return{byteLength:1,components:1};case fl:case gx:case _l:return{byteLength:2,components:1};case Pp:case Ip:return{byteLength:2,components:4};case Zs:case zp:case Ea:return{byteLength:4,components:1};case _x:case vx:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${o}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Lp}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Lp);function kx(){let o=null,e=!1,a=null,r=null;function c(f,h){a(f,h),r=o.requestAnimationFrame(c)}return{start:function(){e!==!0&&a!==null&&(r=o.requestAnimationFrame(c),e=!0)},stop:function(){o.cancelAnimationFrame(r),e=!1},setAnimationLoop:function(f){a=f},setContext:function(f){o=f}}}function _1(o){const e=new WeakMap;function a(d,_){const m=d.array,x=d.usage,p=m.byteLength,y=o.createBuffer();o.bindBuffer(_,y),o.bufferData(_,m,x),d.onUploadCallback();let M;if(m instanceof Float32Array)M=o.FLOAT;else if(typeof Float16Array<"u"&&m instanceof Float16Array)M=o.HALF_FLOAT;else if(m instanceof Uint16Array)d.isFloat16BufferAttribute?M=o.HALF_FLOAT:M=o.UNSIGNED_SHORT;else if(m instanceof Int16Array)M=o.SHORT;else if(m instanceof Uint32Array)M=o.UNSIGNED_INT;else if(m instanceof Int32Array)M=o.INT;else if(m instanceof Int8Array)M=o.BYTE;else if(m instanceof Uint8Array)M=o.UNSIGNED_BYTE;else if(m instanceof Uint8ClampedArray)M=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+m);return{buffer:y,type:M,bytesPerElement:m.BYTES_PER_ELEMENT,version:d.version,size:p}}function r(d,_,m){const x=_.array,p=_.updateRanges;if(o.bindBuffer(m,d),p.length===0)o.bufferSubData(m,0,x);else{p.sort((M,b)=>M.start-b.start);let y=0;for(let M=1;M<p.length;M++){const b=p[y],D=p[M];D.start<=b.start+b.count+1?b.count=Math.max(b.count,D.start+D.count-b.start):(++y,p[y]=D)}p.length=y+1;for(let M=0,b=p.length;M<b;M++){const D=p[M];o.bufferSubData(m,D.start*x.BYTES_PER_ELEMENT,x,D.start,D.count)}_.clearUpdateRanges()}_.onUploadCallback()}function c(d){return d.isInterleavedBufferAttribute&&(d=d.data),e.get(d)}function f(d){d.isInterleavedBufferAttribute&&(d=d.data);const _=e.get(d);_&&(o.deleteBuffer(_.buffer),e.delete(d))}function h(d,_){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const x=e.get(d);(!x||x.version<d.version)&&e.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const m=e.get(d);if(m===void 0)e.set(d,a(d,_));else if(m.version<d.version){if(m.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(m.buffer,d,_),m.version=d.version}}return{get:c,remove:f,update:h}}var v1=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,x1=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,y1=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,S1=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,M1=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,E1=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,T1=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,b1=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,A1=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,R1=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,C1=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,w1=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,D1=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,N1=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,U1=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,L1=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,O1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,z1=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,P1=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,I1=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,B1=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,F1=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,H1=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,G1=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,V1=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,k1=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,X1=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,j1=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,q1=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Y1=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,W1="gl_FragColor = linearToOutputTexel( gl_FragColor );",Z1=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,K1=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Q1=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,J1=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,$1=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,tT=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,eT=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,nT=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,iT=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,aT=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,sT=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,rT=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,oT=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lT=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,cT=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,uT=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,fT=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,hT=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,dT=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,pT=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,mT=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,gT=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,_T=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,vT=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,xT=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,yT=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,ST=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,MT=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,ET=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,TT=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,bT=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,AT=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,RT=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,CT=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,wT=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,DT=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,NT=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,UT=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,LT=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,OT=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,zT=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,PT=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,IT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,BT=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,FT=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,HT=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,GT=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,VT=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,kT=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,XT=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,jT=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,qT=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,YT=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,WT=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,ZT=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,KT=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,QT=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,JT=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,$T=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,tb=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,eb=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,nb=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,ib=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,ab=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,sb=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,rb=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,ob=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,lb=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,cb=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ub=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,fb=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,hb=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,db=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,pb=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,mb=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,gb=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const _b=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,vb=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,yb=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Sb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Mb=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Eb=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Tb=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,bb=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Ab=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Rb=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Cb=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,wb=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Db=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Nb=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Ub=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Lb=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ob=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zb=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Pb=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ib=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Bb=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Fb=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Hb=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gb=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Vb=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kb=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Xb=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jb=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,qb=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Yb=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Wb=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Zb=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Kb=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,pe={alphahash_fragment:v1,alphahash_pars_fragment:x1,alphamap_fragment:y1,alphamap_pars_fragment:S1,alphatest_fragment:M1,alphatest_pars_fragment:E1,aomap_fragment:T1,aomap_pars_fragment:b1,batching_pars_vertex:A1,batching_vertex:R1,begin_vertex:C1,beginnormal_vertex:w1,bsdfs:D1,iridescence_fragment:N1,bumpmap_pars_fragment:U1,clipping_planes_fragment:L1,clipping_planes_pars_fragment:O1,clipping_planes_pars_vertex:z1,clipping_planes_vertex:P1,color_fragment:I1,color_pars_fragment:B1,color_pars_vertex:F1,color_vertex:H1,common:G1,cube_uv_reflection_fragment:V1,defaultnormal_vertex:k1,displacementmap_pars_vertex:X1,displacementmap_vertex:j1,emissivemap_fragment:q1,emissivemap_pars_fragment:Y1,colorspace_fragment:W1,colorspace_pars_fragment:Z1,envmap_fragment:K1,envmap_common_pars_fragment:Q1,envmap_pars_fragment:J1,envmap_pars_vertex:$1,envmap_physical_pars_fragment:uT,envmap_vertex:tT,fog_vertex:eT,fog_pars_vertex:nT,fog_fragment:iT,fog_pars_fragment:aT,gradientmap_pars_fragment:sT,lightmap_pars_fragment:rT,lights_lambert_fragment:oT,lights_lambert_pars_fragment:lT,lights_pars_begin:cT,lights_toon_fragment:fT,lights_toon_pars_fragment:hT,lights_phong_fragment:dT,lights_phong_pars_fragment:pT,lights_physical_fragment:mT,lights_physical_pars_fragment:gT,lights_fragment_begin:_T,lights_fragment_maps:vT,lights_fragment_end:xT,logdepthbuf_fragment:yT,logdepthbuf_pars_fragment:ST,logdepthbuf_pars_vertex:MT,logdepthbuf_vertex:ET,map_fragment:TT,map_pars_fragment:bT,map_particle_fragment:AT,map_particle_pars_fragment:RT,metalnessmap_fragment:CT,metalnessmap_pars_fragment:wT,morphinstance_vertex:DT,morphcolor_vertex:NT,morphnormal_vertex:UT,morphtarget_pars_vertex:LT,morphtarget_vertex:OT,normal_fragment_begin:zT,normal_fragment_maps:PT,normal_pars_fragment:IT,normal_pars_vertex:BT,normal_vertex:FT,normalmap_pars_fragment:HT,clearcoat_normal_fragment_begin:GT,clearcoat_normal_fragment_maps:VT,clearcoat_pars_fragment:kT,iridescence_pars_fragment:XT,opaque_fragment:jT,packing:qT,premultiplied_alpha_fragment:YT,project_vertex:WT,dithering_fragment:ZT,dithering_pars_fragment:KT,roughnessmap_fragment:QT,roughnessmap_pars_fragment:JT,shadowmap_pars_fragment:$T,shadowmap_pars_vertex:tb,shadowmap_vertex:eb,shadowmask_pars_fragment:nb,skinbase_vertex:ib,skinning_pars_vertex:ab,skinning_vertex:sb,skinnormal_vertex:rb,specularmap_fragment:ob,specularmap_pars_fragment:lb,tonemapping_fragment:cb,tonemapping_pars_fragment:ub,transmission_fragment:fb,transmission_pars_fragment:hb,uv_pars_fragment:db,uv_pars_vertex:pb,uv_vertex:mb,worldpos_vertex:gb,background_vert:_b,background_frag:vb,backgroundCube_vert:xb,backgroundCube_frag:yb,cube_vert:Sb,cube_frag:Mb,depth_vert:Eb,depth_frag:Tb,distanceRGBA_vert:bb,distanceRGBA_frag:Ab,equirect_vert:Rb,equirect_frag:Cb,linedashed_vert:wb,linedashed_frag:Db,meshbasic_vert:Nb,meshbasic_frag:Ub,meshlambert_vert:Lb,meshlambert_frag:Ob,meshmatcap_vert:zb,meshmatcap_frag:Pb,meshnormal_vert:Ib,meshnormal_frag:Bb,meshphong_vert:Fb,meshphong_frag:Hb,meshphysical_vert:Gb,meshphysical_frag:Vb,meshtoon_vert:kb,meshtoon_frag:Xb,points_vert:jb,points_frag:qb,shadow_vert:Yb,shadow_frag:Wb,sprite_vert:Zb,sprite_frag:Kb},It={common:{diffuse:{value:new Te(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new de},alphaMap:{value:null},alphaMapTransform:{value:new de},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new de}},envmap:{envMap:{value:null},envMapRotation:{value:new de},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new de}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new de}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new de},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new de},normalScale:{value:new Ue(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new de},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new de}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new de}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new de}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Te(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Te(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new de},alphaTest:{value:0},uvTransform:{value:new de}},sprite:{diffuse:{value:new Te(16777215)},opacity:{value:1},center:{value:new Ue(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new de},alphaMap:{value:null},alphaMapTransform:{value:new de},alphaTest:{value:0}}},Zi={basic:{uniforms:Vn([It.common,It.specularmap,It.envmap,It.aomap,It.lightmap,It.fog]),vertexShader:pe.meshbasic_vert,fragmentShader:pe.meshbasic_frag},lambert:{uniforms:Vn([It.common,It.specularmap,It.envmap,It.aomap,It.lightmap,It.emissivemap,It.bumpmap,It.normalmap,It.displacementmap,It.fog,It.lights,{emissive:{value:new Te(0)}}]),vertexShader:pe.meshlambert_vert,fragmentShader:pe.meshlambert_frag},phong:{uniforms:Vn([It.common,It.specularmap,It.envmap,It.aomap,It.lightmap,It.emissivemap,It.bumpmap,It.normalmap,It.displacementmap,It.fog,It.lights,{emissive:{value:new Te(0)},specular:{value:new Te(1118481)},shininess:{value:30}}]),vertexShader:pe.meshphong_vert,fragmentShader:pe.meshphong_frag},standard:{uniforms:Vn([It.common,It.envmap,It.aomap,It.lightmap,It.emissivemap,It.bumpmap,It.normalmap,It.displacementmap,It.roughnessmap,It.metalnessmap,It.fog,It.lights,{emissive:{value:new Te(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:pe.meshphysical_vert,fragmentShader:pe.meshphysical_frag},toon:{uniforms:Vn([It.common,It.aomap,It.lightmap,It.emissivemap,It.bumpmap,It.normalmap,It.displacementmap,It.gradientmap,It.fog,It.lights,{emissive:{value:new Te(0)}}]),vertexShader:pe.meshtoon_vert,fragmentShader:pe.meshtoon_frag},matcap:{uniforms:Vn([It.common,It.bumpmap,It.normalmap,It.displacementmap,It.fog,{matcap:{value:null}}]),vertexShader:pe.meshmatcap_vert,fragmentShader:pe.meshmatcap_frag},points:{uniforms:Vn([It.points,It.fog]),vertexShader:pe.points_vert,fragmentShader:pe.points_frag},dashed:{uniforms:Vn([It.common,It.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:pe.linedashed_vert,fragmentShader:pe.linedashed_frag},depth:{uniforms:Vn([It.common,It.displacementmap]),vertexShader:pe.depth_vert,fragmentShader:pe.depth_frag},normal:{uniforms:Vn([It.common,It.bumpmap,It.normalmap,It.displacementmap,{opacity:{value:1}}]),vertexShader:pe.meshnormal_vert,fragmentShader:pe.meshnormal_frag},sprite:{uniforms:Vn([It.sprite,It.fog]),vertexShader:pe.sprite_vert,fragmentShader:pe.sprite_frag},background:{uniforms:{uvTransform:{value:new de},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:pe.background_vert,fragmentShader:pe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new de}},vertexShader:pe.backgroundCube_vert,fragmentShader:pe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:pe.cube_vert,fragmentShader:pe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:pe.equirect_vert,fragmentShader:pe.equirect_frag},distanceRGBA:{uniforms:Vn([It.common,It.displacementmap,{referencePosition:{value:new et},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:pe.distanceRGBA_vert,fragmentShader:pe.distanceRGBA_frag},shadow:{uniforms:Vn([It.lights,It.fog,{color:{value:new Te(0)},opacity:{value:1}}]),vertexShader:pe.shadow_vert,fragmentShader:pe.shadow_frag}};Zi.physical={uniforms:Vn([Zi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new de},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new de},clearcoatNormalScale:{value:new Ue(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new de},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new de},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new de},sheen:{value:0},sheenColor:{value:new Te(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new de},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new de},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new de},transmissionSamplerSize:{value:new Ue},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new de},attenuationDistance:{value:0},attenuationColor:{value:new Te(0)},specularColor:{value:new Te(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new de},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new de},anisotropyVector:{value:new Ue},anisotropyMap:{value:null},anisotropyMapTransform:{value:new de}}]),vertexShader:pe.meshphysical_vert,fragmentShader:pe.meshphysical_frag};const uu={r:0,b:0,g:0},Fs=new $i,Qb=new sn;function Jb(o,e,a,r,c,f,h){const d=new Te(0);let _=f===!0?0:1,m,x,p=null,y=0,M=null;function b(z){let N=z.isScene===!0?z.background:null;return N&&N.isTexture&&(N=(z.backgroundBlurriness>0?a:e).get(N)),N}function D(z){let N=!1;const H=b(z);H===null?v(d,_):H&&H.isColor&&(v(H,1),N=!0);const F=o.xr.getEnvironmentBlendMode();F==="additive"?r.buffers.color.setClear(0,0,0,1,h):F==="alpha-blend"&&r.buffers.color.setClear(0,0,0,0,h),(o.autoClear||N)&&(r.buffers.depth.setTest(!0),r.buffers.depth.setMask(!0),r.buffers.color.setMask(!0),o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil))}function S(z,N){const H=b(N);H&&(H.isCubeTexture||H.mapping===Tu)?(x===void 0&&(x=new tn(new Qs(1,1,1),new us({name:"BackgroundCubeMaterial",uniforms:ro(Zi.backgroundCube.uniforms),vertexShader:Zi.backgroundCube.vertexShader,fragmentShader:Zi.backgroundCube.fragmentShader,side:Kn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),x.geometry.deleteAttribute("normal"),x.geometry.deleteAttribute("uv"),x.onBeforeRender=function(F,P,k){this.matrixWorld.copyPosition(k.matrixWorld)},Object.defineProperty(x.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),c.update(x)),Fs.copy(N.backgroundRotation),Fs.x*=-1,Fs.y*=-1,Fs.z*=-1,H.isCubeTexture&&H.isRenderTargetTexture===!1&&(Fs.y*=-1,Fs.z*=-1),x.material.uniforms.envMap.value=H,x.material.uniforms.flipEnvMap.value=H.isCubeTexture&&H.isRenderTargetTexture===!1?-1:1,x.material.uniforms.backgroundBlurriness.value=N.backgroundBlurriness,x.material.uniforms.backgroundIntensity.value=N.backgroundIntensity,x.material.uniforms.backgroundRotation.value.setFromMatrix4(Qb.makeRotationFromEuler(Fs)),x.material.toneMapped=Ne.getTransfer(H.colorSpace)!==Xe,(p!==H||y!==H.version||M!==o.toneMapping)&&(x.material.needsUpdate=!0,p=H,y=H.version,M=o.toneMapping),x.layers.enableAll(),z.unshift(x,x.geometry,x.material,0,0,null)):H&&H.isTexture&&(m===void 0&&(m=new tn(new co(2,2),new us({name:"BackgroundMaterial",uniforms:ro(Zi.background.uniforms),vertexShader:Zi.background.vertexShader,fragmentShader:Zi.background.fragmentShader,side:cs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),m.geometry.deleteAttribute("normal"),Object.defineProperty(m.material,"map",{get:function(){return this.uniforms.t2D.value}}),c.update(m)),m.material.uniforms.t2D.value=H,m.material.uniforms.backgroundIntensity.value=N.backgroundIntensity,m.material.toneMapped=Ne.getTransfer(H.colorSpace)!==Xe,H.matrixAutoUpdate===!0&&H.updateMatrix(),m.material.uniforms.uvTransform.value.copy(H.matrix),(p!==H||y!==H.version||M!==o.toneMapping)&&(m.material.needsUpdate=!0,p=H,y=H.version,M=o.toneMapping),m.layers.enableAll(),z.unshift(m,m.geometry,m.material,0,0,null))}function v(z,N){z.getRGB(uu,Ux(o)),r.buffers.color.setClear(uu.r,uu.g,uu.b,N,h)}function L(){x!==void 0&&(x.geometry.dispose(),x.material.dispose(),x=void 0),m!==void 0&&(m.geometry.dispose(),m.material.dispose(),m=void 0)}return{getClearColor:function(){return d},setClearColor:function(z,N=1){d.set(z),_=N,v(d,_)},getClearAlpha:function(){return _},setClearAlpha:function(z){_=z,v(d,_)},render:D,addToRenderList:S,dispose:L}}function $b(o,e){const a=o.getParameter(o.MAX_VERTEX_ATTRIBS),r={},c=y(null);let f=c,h=!1;function d(w,G,it,ct,gt){let ut=!1;const W=p(ct,it,G);f!==W&&(f=W,m(f.object)),ut=M(w,ct,it,gt),ut&&b(w,ct,it,gt),gt!==null&&e.update(gt,o.ELEMENT_ARRAY_BUFFER),(ut||h)&&(h=!1,N(w,G,it,ct),gt!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(gt).buffer))}function _(){return o.createVertexArray()}function m(w){return o.bindVertexArray(w)}function x(w){return o.deleteVertexArray(w)}function p(w,G,it){const ct=it.wireframe===!0;let gt=r[w.id];gt===void 0&&(gt={},r[w.id]=gt);let ut=gt[G.id];ut===void 0&&(ut={},gt[G.id]=ut);let W=ut[ct];return W===void 0&&(W=y(_()),ut[ct]=W),W}function y(w){const G=[],it=[],ct=[];for(let gt=0;gt<a;gt++)G[gt]=0,it[gt]=0,ct[gt]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:G,enabledAttributes:it,attributeDivisors:ct,object:w,attributes:{},index:null}}function M(w,G,it,ct){const gt=f.attributes,ut=G.attributes;let W=0;const rt=it.getAttributes();for(const K in rt)if(rt[K].location>=0){const yt=gt[K];let Gt=ut[K];if(Gt===void 0&&(K==="instanceMatrix"&&w.instanceMatrix&&(Gt=w.instanceMatrix),K==="instanceColor"&&w.instanceColor&&(Gt=w.instanceColor)),yt===void 0||yt.attribute!==Gt||Gt&&yt.data!==Gt.data)return!0;W++}return f.attributesNum!==W||f.index!==ct}function b(w,G,it,ct){const gt={},ut=G.attributes;let W=0;const rt=it.getAttributes();for(const K in rt)if(rt[K].location>=0){let yt=ut[K];yt===void 0&&(K==="instanceMatrix"&&w.instanceMatrix&&(yt=w.instanceMatrix),K==="instanceColor"&&w.instanceColor&&(yt=w.instanceColor));const Gt={};Gt.attribute=yt,yt&&yt.data&&(Gt.data=yt.data),gt[K]=Gt,W++}f.attributes=gt,f.attributesNum=W,f.index=ct}function D(){const w=f.newAttributes;for(let G=0,it=w.length;G<it;G++)w[G]=0}function S(w){v(w,0)}function v(w,G){const it=f.newAttributes,ct=f.enabledAttributes,gt=f.attributeDivisors;it[w]=1,ct[w]===0&&(o.enableVertexAttribArray(w),ct[w]=1),gt[w]!==G&&(o.vertexAttribDivisor(w,G),gt[w]=G)}function L(){const w=f.newAttributes,G=f.enabledAttributes;for(let it=0,ct=G.length;it<ct;it++)G[it]!==w[it]&&(o.disableVertexAttribArray(it),G[it]=0)}function z(w,G,it,ct,gt,ut,W){W===!0?o.vertexAttribIPointer(w,G,it,gt,ut):o.vertexAttribPointer(w,G,it,ct,gt,ut)}function N(w,G,it,ct){D();const gt=ct.attributes,ut=it.getAttributes(),W=G.defaultAttributeValues;for(const rt in ut){const K=ut[rt];if(K.location>=0){let vt=gt[rt];if(vt===void 0&&(rt==="instanceMatrix"&&w.instanceMatrix&&(vt=w.instanceMatrix),rt==="instanceColor"&&w.instanceColor&&(vt=w.instanceColor)),vt!==void 0){const yt=vt.normalized,Gt=vt.itemSize,re=e.get(vt);if(re===void 0)continue;const Ae=re.buffer,B=re.type,ft=re.bytesPerElement,$=B===o.INT||B===o.UNSIGNED_INT||vt.gpuType===zp;if(vt.isInterleavedBufferAttribute){const st=vt.data,Mt=st.stride,Ut=vt.offset;if(st.isInstancedInterleavedBuffer){for(let Rt=0;Rt<K.locationSize;Rt++)v(K.location+Rt,st.meshPerAttribute);w.isInstancedMesh!==!0&&ct._maxInstanceCount===void 0&&(ct._maxInstanceCount=st.meshPerAttribute*st.count)}else for(let Rt=0;Rt<K.locationSize;Rt++)S(K.location+Rt);o.bindBuffer(o.ARRAY_BUFFER,Ae);for(let Rt=0;Rt<K.locationSize;Rt++)z(K.location+Rt,Gt/K.locationSize,B,yt,Mt*ft,(Ut+Gt/K.locationSize*Rt)*ft,$)}else{if(vt.isInstancedBufferAttribute){for(let st=0;st<K.locationSize;st++)v(K.location+st,vt.meshPerAttribute);w.isInstancedMesh!==!0&&ct._maxInstanceCount===void 0&&(ct._maxInstanceCount=vt.meshPerAttribute*vt.count)}else for(let st=0;st<K.locationSize;st++)S(K.location+st);o.bindBuffer(o.ARRAY_BUFFER,Ae);for(let st=0;st<K.locationSize;st++)z(K.location+st,Gt/K.locationSize,B,yt,Gt*ft,Gt/K.locationSize*st*ft,$)}}else if(W!==void 0){const yt=W[rt];if(yt!==void 0)switch(yt.length){case 2:o.vertexAttrib2fv(K.location,yt);break;case 3:o.vertexAttrib3fv(K.location,yt);break;case 4:o.vertexAttrib4fv(K.location,yt);break;default:o.vertexAttrib1fv(K.location,yt)}}}}L()}function H(){k();for(const w in r){const G=r[w];for(const it in G){const ct=G[it];for(const gt in ct)x(ct[gt].object),delete ct[gt];delete G[it]}delete r[w]}}function F(w){if(r[w.id]===void 0)return;const G=r[w.id];for(const it in G){const ct=G[it];for(const gt in ct)x(ct[gt].object),delete ct[gt];delete G[it]}delete r[w.id]}function P(w){for(const G in r){const it=r[G];if(it[w.id]===void 0)continue;const ct=it[w.id];for(const gt in ct)x(ct[gt].object),delete ct[gt];delete it[w.id]}}function k(){C(),h=!0,f!==c&&(f=c,m(f.object))}function C(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:d,reset:k,resetDefaultState:C,dispose:H,releaseStatesOfGeometry:F,releaseStatesOfProgram:P,initAttributes:D,enableAttribute:S,disableUnusedAttributes:L}}function tA(o,e,a){let r;function c(m){r=m}function f(m,x){o.drawArrays(r,m,x),a.update(x,r,1)}function h(m,x,p){p!==0&&(o.drawArraysInstanced(r,m,x,p),a.update(x,r,p))}function d(m,x,p){if(p===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,m,0,x,0,p);let M=0;for(let b=0;b<p;b++)M+=x[b];a.update(M,r,1)}function _(m,x,p,y){if(p===0)return;const M=e.get("WEBGL_multi_draw");if(M===null)for(let b=0;b<m.length;b++)h(m[b],x[b],y[b]);else{M.multiDrawArraysInstancedWEBGL(r,m,0,x,0,y,0,p);let b=0;for(let D=0;D<p;D++)b+=x[D]*y[D];a.update(b,r,1)}}this.setMode=c,this.render=f,this.renderInstances=h,this.renderMultiDraw=d,this.renderMultiDrawInstances=_}function eA(o,e,a,r){let c;function f(){if(c!==void 0)return c;if(e.has("EXT_texture_filter_anisotropic")===!0){const P=e.get("EXT_texture_filter_anisotropic");c=o.getParameter(P.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else c=0;return c}function h(P){return!(P!==Li&&r.convert(P)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(P){const k=P===_l&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(P!==Ji&&r.convert(P)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_TYPE)&&P!==Ea&&!k)}function _(P){if(P==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";P="mediump"}return P==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let m=a.precision!==void 0?a.precision:"highp";const x=_(m);x!==m&&(console.warn("THREE.WebGLRenderer:",m,"not supported, using",x,"instead."),m=x);const p=a.logarithmicDepthBuffer===!0,y=a.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),M=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),b=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),D=o.getParameter(o.MAX_TEXTURE_SIZE),S=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),v=o.getParameter(o.MAX_VERTEX_ATTRIBS),L=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),z=o.getParameter(o.MAX_VARYING_VECTORS),N=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),H=b>0,F=o.getParameter(o.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:f,getMaxPrecision:_,textureFormatReadable:h,textureTypeReadable:d,precision:m,logarithmicDepthBuffer:p,reversedDepthBuffer:y,maxTextures:M,maxVertexTextures:b,maxTextureSize:D,maxCubemapSize:S,maxAttributes:v,maxVertexUniforms:L,maxVaryings:z,maxFragmentUniforms:N,vertexTextures:H,maxSamples:F}}function nA(o){const e=this;let a=null,r=0,c=!1,f=!1;const h=new Gs,d=new de,_={value:null,needsUpdate:!1};this.uniform=_,this.numPlanes=0,this.numIntersection=0,this.init=function(p,y){const M=p.length!==0||y||r!==0||c;return c=y,r=p.length,M},this.beginShadows=function(){f=!0,x(null)},this.endShadows=function(){f=!1},this.setGlobalState=function(p,y){a=x(p,y,0)},this.setState=function(p,y,M){const b=p.clippingPlanes,D=p.clipIntersection,S=p.clipShadows,v=o.get(p);if(!c||b===null||b.length===0||f&&!S)f?x(null):m();else{const L=f?0:r,z=L*4;let N=v.clippingState||null;_.value=N,N=x(b,y,z,M);for(let H=0;H!==z;++H)N[H]=a[H];v.clippingState=N,this.numIntersection=D?this.numPlanes:0,this.numPlanes+=L}};function m(){_.value!==a&&(_.value=a,_.needsUpdate=r>0),e.numPlanes=r,e.numIntersection=0}function x(p,y,M,b){const D=p!==null?p.length:0;let S=null;if(D!==0){if(S=_.value,b!==!0||S===null){const v=M+D*4,L=y.matrixWorldInverse;d.getNormalMatrix(L),(S===null||S.length<v)&&(S=new Float32Array(v));for(let z=0,N=M;z!==D;++z,N+=4)h.copy(p[z]).applyMatrix4(L,d),h.normal.toArray(S,N),S[N+3]=h.constant}_.value=S,_.needsUpdate=!0}return e.numPlanes=D,e.numIntersection=0,S}}function iA(o){let e=new WeakMap;function a(h,d){return d===Kd?h.mapping=io:d===Qd&&(h.mapping=ao),h}function r(h){if(h&&h.isTexture){const d=h.mapping;if(d===Kd||d===Qd)if(e.has(h)){const _=e.get(h).texture;return a(_,h.mapping)}else{const _=h.image;if(_&&_.height>0){const m=new s1(_.height);return m.fromEquirectangularTexture(o,h),e.set(h,m),h.addEventListener("dispose",c),a(m.texture,h.mapping)}else return null}}return h}function c(h){const d=h.target;d.removeEventListener("dispose",c);const _=e.get(d);_!==void 0&&(e.delete(d),_.dispose())}function f(){e=new WeakMap}return{get:r,dispose:f}}const $r=4,Bv=[.125,.215,.35,.446,.526,.582],Xs=20,zd=new Gx,Fv=new Te;let Pd=null,Id=0,Bd=0,Fd=!1;const Vs=(1+Math.sqrt(5))/2,Qr=1/Vs,Hv=[new et(-Vs,Qr,0),new et(Vs,Qr,0),new et(-Qr,0,Vs),new et(Qr,0,Vs),new et(0,Vs,-Qr),new et(0,Vs,Qr),new et(-1,1,-1),new et(1,1,-1),new et(-1,1,1),new et(1,1,1)],aA=new et;class Gv{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,a=0,r=.1,c=100,f={}){const{size:h=256,position:d=aA}=f;Pd=this._renderer.getRenderTarget(),Id=this._renderer.getActiveCubeFace(),Bd=this._renderer.getActiveMipmapLevel(),Fd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(h);const _=this._allocateTargets();return _.depthBuffer=!0,this._sceneToCubeUV(e,r,c,_,d),a>0&&this._blur(_,0,0,a),this._applyPMREM(_),this._cleanup(_),_}fromEquirectangular(e,a=null){return this._fromTexture(e,a)}fromCubemap(e,a=null){return this._fromTexture(e,a)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Xv(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=kv(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Pd,Id,Bd),this._renderer.xr.enabled=Fd,e.scissorTest=!1,fu(e,0,0,e.width,e.height)}_fromTexture(e,a){e.mapping===io||e.mapping===ao?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Pd=this._renderer.getRenderTarget(),Id=this._renderer.getActiveCubeFace(),Bd=this._renderer.getActiveMipmapLevel(),Fd=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const r=a||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),a=4*this._cubeSize,r={magFilter:Ki,minFilter:Ki,generateMipmaps:!1,type:_l,format:Li,colorSpace:so,depthBuffer:!1},c=Vv(e,a,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==a){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Vv(e,a,r);const{_lodMax:f}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=sA(f)),this._blurMaterial=rA(f,e,a)}return c}_compileMaterial(e){const a=new tn(this._lodPlanes[0],e);this._renderer.compile(a,zd)}_sceneToCubeUV(e,a,r,c,f){const _=new Zn(90,1,a,r),m=[1,-1,1,1,1,1],x=[1,1,1,-1,-1,-1],p=this._renderer,y=p.autoClear,M=p.toneMapping;p.getClearColor(Fv),p.toneMapping=os,p.autoClear=!1,p.state.buffers.depth.getReversed()&&(p.setRenderTarget(c),p.clearDepth(),p.setRenderTarget(null));const D=new Mu({name:"PMREM.Background",side:Kn,depthWrite:!1,depthTest:!1}),S=new tn(new Qs,D);let v=!1;const L=e.background;L?L.isColor&&(D.color.copy(L),e.background=null,v=!0):(D.color.copy(Fv),v=!0);for(let z=0;z<6;z++){const N=z%3;N===0?(_.up.set(0,m[z],0),_.position.set(f.x,f.y,f.z),_.lookAt(f.x+x[z],f.y,f.z)):N===1?(_.up.set(0,0,m[z]),_.position.set(f.x,f.y,f.z),_.lookAt(f.x,f.y+x[z],f.z)):(_.up.set(0,m[z],0),_.position.set(f.x,f.y,f.z),_.lookAt(f.x,f.y,f.z+x[z]));const H=this._cubeSize;fu(c,N*H,z>2?H:0,H,H),p.setRenderTarget(c),v&&p.render(S,_),p.render(e,_)}S.geometry.dispose(),S.material.dispose(),p.toneMapping=M,p.autoClear=y,e.background=L}_textureToCubeUV(e,a){const r=this._renderer,c=e.mapping===io||e.mapping===ao;c?(this._cubemapMaterial===null&&(this._cubemapMaterial=Xv()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=kv());const f=c?this._cubemapMaterial:this._equirectMaterial,h=new tn(this._lodPlanes[0],f),d=f.uniforms;d.envMap.value=e;const _=this._cubeSize;fu(a,0,0,3*_,2*_),r.setRenderTarget(a),r.render(h,zd)}_applyPMREM(e){const a=this._renderer,r=a.autoClear;a.autoClear=!1;const c=this._lodPlanes.length;for(let f=1;f<c;f++){const h=Math.sqrt(this._sigmas[f]*this._sigmas[f]-this._sigmas[f-1]*this._sigmas[f-1]),d=Hv[(c-f-1)%Hv.length];this._blur(e,f-1,f,h,d)}a.autoClear=r}_blur(e,a,r,c,f){const h=this._pingPongRenderTarget;this._halfBlur(e,h,a,r,c,"latitudinal",f),this._halfBlur(h,e,r,r,c,"longitudinal",f)}_halfBlur(e,a,r,c,f,h,d){const _=this._renderer,m=this._blurMaterial;h!=="latitudinal"&&h!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const x=3,p=new tn(this._lodPlanes[c],m),y=m.uniforms,M=this._sizeLods[r]-1,b=isFinite(f)?Math.PI/(2*M):2*Math.PI/(2*Xs-1),D=f/b,S=isFinite(f)?1+Math.floor(x*D):Xs;S>Xs&&console.warn(`sigmaRadians, ${f}, is too large and will clip, as it requested ${S} samples when the maximum is set to ${Xs}`);const v=[];let L=0;for(let P=0;P<Xs;++P){const k=P/D,C=Math.exp(-k*k/2);v.push(C),P===0?L+=C:P<S&&(L+=2*C)}for(let P=0;P<v.length;P++)v[P]=v[P]/L;y.envMap.value=e.texture,y.samples.value=S,y.weights.value=v,y.latitudinal.value=h==="latitudinal",d&&(y.poleAxis.value=d);const{_lodMax:z}=this;y.dTheta.value=b,y.mipInt.value=z-r;const N=this._sizeLods[c],H=3*N*(c>z-$r?c-z+$r:0),F=4*(this._cubeSize-N);fu(a,H,F,3*N,2*N),_.setRenderTarget(a),_.render(p,zd)}}function sA(o){const e=[],a=[],r=[];let c=o;const f=o-$r+1+Bv.length;for(let h=0;h<f;h++){const d=Math.pow(2,c);a.push(d);let _=1/d;h>o-$r?_=Bv[h-o+$r-1]:h===0&&(_=0),r.push(_);const m=1/(d-2),x=-m,p=1+m,y=[x,x,p,x,p,p,x,x,p,p,x,p],M=6,b=6,D=3,S=2,v=1,L=new Float32Array(D*b*M),z=new Float32Array(S*b*M),N=new Float32Array(v*b*M);for(let F=0;F<M;F++){const P=F%3*2/3-1,k=F>2?0:-1,C=[P,k,0,P+2/3,k,0,P+2/3,k+1,0,P,k,0,P+2/3,k+1,0,P,k+1,0];L.set(C,D*b*F),z.set(y,S*b*F);const w=[F,F,F,F,F,F];N.set(w,v*b*F)}const H=new Pi;H.setAttribute("position",new zi(L,D)),H.setAttribute("uv",new zi(z,S)),H.setAttribute("faceIndex",new zi(N,v)),e.push(H),c>$r&&c--}return{lodPlanes:e,sizeLods:a,sigmas:r}}function Vv(o,e,a){const r=new Ks(o,e,a);return r.texture.mapping=Tu,r.texture.name="PMREM.cubeUv",r.scissorTest=!0,r}function fu(o,e,a,r,c){o.viewport.set(e,a,r,c),o.scissor.set(e,a,r,c)}function rA(o,e,a){const r=new Float32Array(Xs),c=new et(0,1,0);return new us({name:"SphericalGaussianBlur",defines:{n:Xs,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/a,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:c}},vertexShader:Xp(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:rs,depthTest:!1,depthWrite:!1})}function kv(){return new us({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Xp(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:rs,depthTest:!1,depthWrite:!1})}function Xv(){return new us({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Xp(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:rs,depthTest:!1,depthWrite:!1})}function Xp(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function oA(o){let e=new WeakMap,a=null;function r(d){if(d&&d.isTexture){const _=d.mapping,m=_===Kd||_===Qd,x=_===io||_===ao;if(m||x){let p=e.get(d);const y=p!==void 0?p.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==y)return a===null&&(a=new Gv(o)),p=m?a.fromEquirectangular(d,p):a.fromCubemap(d,p),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),p.texture;if(p!==void 0)return p.texture;{const M=d.image;return m&&M&&M.height>0||x&&M&&c(M)?(a===null&&(a=new Gv(o)),p=m?a.fromEquirectangular(d):a.fromCubemap(d),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),d.addEventListener("dispose",f),p.texture):null}}}return d}function c(d){let _=0;const m=6;for(let x=0;x<m;x++)d[x]!==void 0&&_++;return _===m}function f(d){const _=d.target;_.removeEventListener("dispose",f);const m=e.get(_);m!==void 0&&(e.delete(_),m.dispose())}function h(){e=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:r,dispose:h}}function lA(o){const e={};function a(r){if(e[r]!==void 0)return e[r];let c;switch(r){case"WEBGL_depth_texture":c=o.getExtension("WEBGL_depth_texture")||o.getExtension("MOZ_WEBGL_depth_texture")||o.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":c=o.getExtension("EXT_texture_filter_anisotropic")||o.getExtension("MOZ_EXT_texture_filter_anisotropic")||o.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":c=o.getExtension("WEBGL_compressed_texture_s3tc")||o.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":c=o.getExtension("WEBGL_compressed_texture_pvrtc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:c=o.getExtension(r)}return e[r]=c,c}return{has:function(r){return a(r)!==null},init:function(){a("EXT_color_buffer_float"),a("WEBGL_clip_cull_distance"),a("OES_texture_float_linear"),a("EXT_color_buffer_half_float"),a("WEBGL_multisampled_render_to_texture"),a("WEBGL_render_shared_exponent")},get:function(r){const c=a(r);return c===null&&ml("THREE.WebGLRenderer: "+r+" extension not supported."),c}}}function cA(o,e,a,r){const c={},f=new WeakMap;function h(p){const y=p.target;y.index!==null&&e.remove(y.index);for(const b in y.attributes)e.remove(y.attributes[b]);y.removeEventListener("dispose",h),delete c[y.id];const M=f.get(y);M&&(e.remove(M),f.delete(y)),r.releaseStatesOfGeometry(y),y.isInstancedBufferGeometry===!0&&delete y._maxInstanceCount,a.memory.geometries--}function d(p,y){return c[y.id]===!0||(y.addEventListener("dispose",h),c[y.id]=!0,a.memory.geometries++),y}function _(p){const y=p.attributes;for(const M in y)e.update(y[M],o.ARRAY_BUFFER)}function m(p){const y=[],M=p.index,b=p.attributes.position;let D=0;if(M!==null){const L=M.array;D=M.version;for(let z=0,N=L.length;z<N;z+=3){const H=L[z+0],F=L[z+1],P=L[z+2];y.push(H,F,F,P,P,H)}}else if(b!==void 0){const L=b.array;D=b.version;for(let z=0,N=L.length/3-1;z<N;z+=3){const H=z+0,F=z+1,P=z+2;y.push(H,F,F,P,P,H)}}else return;const S=new(bx(y)?Nx:Dx)(y,1);S.version=D;const v=f.get(p);v&&e.remove(v),f.set(p,S)}function x(p){const y=f.get(p);if(y){const M=p.index;M!==null&&y.version<M.version&&m(p)}else m(p);return f.get(p)}return{get:d,update:_,getWireframeAttribute:x}}function uA(o,e,a){let r;function c(y){r=y}let f,h;function d(y){f=y.type,h=y.bytesPerElement}function _(y,M){o.drawElements(r,M,f,y*h),a.update(M,r,1)}function m(y,M,b){b!==0&&(o.drawElementsInstanced(r,M,f,y*h,b),a.update(M,r,b))}function x(y,M,b){if(b===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,M,0,f,y,0,b);let S=0;for(let v=0;v<b;v++)S+=M[v];a.update(S,r,1)}function p(y,M,b,D){if(b===0)return;const S=e.get("WEBGL_multi_draw");if(S===null)for(let v=0;v<y.length;v++)m(y[v]/h,M[v],D[v]);else{S.multiDrawElementsInstancedWEBGL(r,M,0,f,y,0,D,0,b);let v=0;for(let L=0;L<b;L++)v+=M[L]*D[L];a.update(v,r,1)}}this.setMode=c,this.setIndex=d,this.render=_,this.renderInstances=m,this.renderMultiDraw=x,this.renderMultiDrawInstances=p}function fA(o){const e={geometries:0,textures:0},a={frame:0,calls:0,triangles:0,points:0,lines:0};function r(f,h,d){switch(a.calls++,h){case o.TRIANGLES:a.triangles+=d*(f/3);break;case o.LINES:a.lines+=d*(f/2);break;case o.LINE_STRIP:a.lines+=d*(f-1);break;case o.LINE_LOOP:a.lines+=d*f;break;case o.POINTS:a.points+=d*f;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",h);break}}function c(){a.calls=0,a.triangles=0,a.points=0,a.lines=0}return{memory:e,render:a,programs:null,autoReset:!0,reset:c,update:r}}function hA(o,e,a){const r=new WeakMap,c=new je;function f(h,d,_){const m=h.morphTargetInfluences,x=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,p=x!==void 0?x.length:0;let y=r.get(d);if(y===void 0||y.count!==p){let w=function(){k.dispose(),r.delete(d),d.removeEventListener("dispose",w)};var M=w;y!==void 0&&y.texture.dispose();const b=d.morphAttributes.position!==void 0,D=d.morphAttributes.normal!==void 0,S=d.morphAttributes.color!==void 0,v=d.morphAttributes.position||[],L=d.morphAttributes.normal||[],z=d.morphAttributes.color||[];let N=0;b===!0&&(N=1),D===!0&&(N=2),S===!0&&(N=3);let H=d.attributes.position.count*N,F=1;H>e.maxTextureSize&&(F=Math.ceil(H/e.maxTextureSize),H=e.maxTextureSize);const P=new Float32Array(H*F*4*p),k=new Ax(P,H,F,p);k.type=Ea,k.needsUpdate=!0;const C=N*4;for(let G=0;G<p;G++){const it=v[G],ct=L[G],gt=z[G],ut=H*F*4*G;for(let W=0;W<it.count;W++){const rt=W*C;b===!0&&(c.fromBufferAttribute(it,W),P[ut+rt+0]=c.x,P[ut+rt+1]=c.y,P[ut+rt+2]=c.z,P[ut+rt+3]=0),D===!0&&(c.fromBufferAttribute(ct,W),P[ut+rt+4]=c.x,P[ut+rt+5]=c.y,P[ut+rt+6]=c.z,P[ut+rt+7]=0),S===!0&&(c.fromBufferAttribute(gt,W),P[ut+rt+8]=c.x,P[ut+rt+9]=c.y,P[ut+rt+10]=c.z,P[ut+rt+11]=gt.itemSize===4?c.w:1)}}y={count:p,texture:k,size:new Ue(H,F)},r.set(d,y),d.addEventListener("dispose",w)}if(h.isInstancedMesh===!0&&h.morphTexture!==null)_.getUniforms().setValue(o,"morphTexture",h.morphTexture,a);else{let b=0;for(let S=0;S<m.length;S++)b+=m[S];const D=d.morphTargetsRelative?1:1-b;_.getUniforms().setValue(o,"morphTargetBaseInfluence",D),_.getUniforms().setValue(o,"morphTargetInfluences",m)}_.getUniforms().setValue(o,"morphTargetsTexture",y.texture,a),_.getUniforms().setValue(o,"morphTargetsTextureSize",y.size)}return{update:f}}function dA(o,e,a,r){let c=new WeakMap;function f(_){const m=r.render.frame,x=_.geometry,p=e.get(_,x);if(c.get(p)!==m&&(e.update(p),c.set(p,m)),_.isInstancedMesh&&(_.hasEventListener("dispose",d)===!1&&_.addEventListener("dispose",d),c.get(_)!==m&&(a.update(_.instanceMatrix,o.ARRAY_BUFFER),_.instanceColor!==null&&a.update(_.instanceColor,o.ARRAY_BUFFER),c.set(_,m))),_.isSkinnedMesh){const y=_.skeleton;c.get(y)!==m&&(y.update(),c.set(y,m))}return p}function h(){c=new WeakMap}function d(_){const m=_.target;m.removeEventListener("dispose",d),a.remove(m.instanceMatrix),m.instanceColor!==null&&a.remove(m.instanceColor)}return{update:f,dispose:h}}const Xx=new Qn,jv=new Ix(1,1),jx=new Ax,qx=new VE,Yx=new Ox,qv=[],Yv=[],Wv=new Float32Array(16),Zv=new Float32Array(9),Kv=new Float32Array(4);function uo(o,e,a){const r=o[0];if(r<=0||r>0)return o;const c=e*a;let f=qv[c];if(f===void 0&&(f=new Float32Array(c),qv[c]=f),e!==0){r.toArray(f,0);for(let h=1,d=0;h!==e;++h)d+=a,o[h].toArray(f,d)}return f}function xn(o,e){if(o.length!==e.length)return!1;for(let a=0,r=o.length;a<r;a++)if(o[a]!==e[a])return!1;return!0}function yn(o,e){for(let a=0,r=e.length;a<r;a++)o[a]=e[a]}function Au(o,e){let a=Yv[e];a===void 0&&(a=new Int32Array(e),Yv[e]=a);for(let r=0;r!==e;++r)a[r]=o.allocateTextureUnit();return a}function pA(o,e){const a=this.cache;a[0]!==e&&(o.uniform1f(this.addr,e),a[0]=e)}function mA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y)&&(o.uniform2f(this.addr,e.x,e.y),a[0]=e.x,a[1]=e.y);else{if(xn(a,e))return;o.uniform2fv(this.addr,e),yn(a,e)}}function gA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z)&&(o.uniform3f(this.addr,e.x,e.y,e.z),a[0]=e.x,a[1]=e.y,a[2]=e.z);else if(e.r!==void 0)(a[0]!==e.r||a[1]!==e.g||a[2]!==e.b)&&(o.uniform3f(this.addr,e.r,e.g,e.b),a[0]=e.r,a[1]=e.g,a[2]=e.b);else{if(xn(a,e))return;o.uniform3fv(this.addr,e),yn(a,e)}}function _A(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z||a[3]!==e.w)&&(o.uniform4f(this.addr,e.x,e.y,e.z,e.w),a[0]=e.x,a[1]=e.y,a[2]=e.z,a[3]=e.w);else{if(xn(a,e))return;o.uniform4fv(this.addr,e),yn(a,e)}}function vA(o,e){const a=this.cache,r=e.elements;if(r===void 0){if(xn(a,e))return;o.uniformMatrix2fv(this.addr,!1,e),yn(a,e)}else{if(xn(a,r))return;Kv.set(r),o.uniformMatrix2fv(this.addr,!1,Kv),yn(a,r)}}function xA(o,e){const a=this.cache,r=e.elements;if(r===void 0){if(xn(a,e))return;o.uniformMatrix3fv(this.addr,!1,e),yn(a,e)}else{if(xn(a,r))return;Zv.set(r),o.uniformMatrix3fv(this.addr,!1,Zv),yn(a,r)}}function yA(o,e){const a=this.cache,r=e.elements;if(r===void 0){if(xn(a,e))return;o.uniformMatrix4fv(this.addr,!1,e),yn(a,e)}else{if(xn(a,r))return;Wv.set(r),o.uniformMatrix4fv(this.addr,!1,Wv),yn(a,r)}}function SA(o,e){const a=this.cache;a[0]!==e&&(o.uniform1i(this.addr,e),a[0]=e)}function MA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y)&&(o.uniform2i(this.addr,e.x,e.y),a[0]=e.x,a[1]=e.y);else{if(xn(a,e))return;o.uniform2iv(this.addr,e),yn(a,e)}}function EA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z)&&(o.uniform3i(this.addr,e.x,e.y,e.z),a[0]=e.x,a[1]=e.y,a[2]=e.z);else{if(xn(a,e))return;o.uniform3iv(this.addr,e),yn(a,e)}}function TA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z||a[3]!==e.w)&&(o.uniform4i(this.addr,e.x,e.y,e.z,e.w),a[0]=e.x,a[1]=e.y,a[2]=e.z,a[3]=e.w);else{if(xn(a,e))return;o.uniform4iv(this.addr,e),yn(a,e)}}function bA(o,e){const a=this.cache;a[0]!==e&&(o.uniform1ui(this.addr,e),a[0]=e)}function AA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y)&&(o.uniform2ui(this.addr,e.x,e.y),a[0]=e.x,a[1]=e.y);else{if(xn(a,e))return;o.uniform2uiv(this.addr,e),yn(a,e)}}function RA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z)&&(o.uniform3ui(this.addr,e.x,e.y,e.z),a[0]=e.x,a[1]=e.y,a[2]=e.z);else{if(xn(a,e))return;o.uniform3uiv(this.addr,e),yn(a,e)}}function CA(o,e){const a=this.cache;if(e.x!==void 0)(a[0]!==e.x||a[1]!==e.y||a[2]!==e.z||a[3]!==e.w)&&(o.uniform4ui(this.addr,e.x,e.y,e.z,e.w),a[0]=e.x,a[1]=e.y,a[2]=e.z,a[3]=e.w);else{if(xn(a,e))return;o.uniform4uiv(this.addr,e),yn(a,e)}}function wA(o,e,a){const r=this.cache,c=a.allocateTextureUnit();r[0]!==c&&(o.uniform1i(this.addr,c),r[0]=c);let f;this.type===o.SAMPLER_2D_SHADOW?(jv.compareFunction=Tx,f=jv):f=Xx,a.setTexture2D(e||f,c)}function DA(o,e,a){const r=this.cache,c=a.allocateTextureUnit();r[0]!==c&&(o.uniform1i(this.addr,c),r[0]=c),a.setTexture3D(e||qx,c)}function NA(o,e,a){const r=this.cache,c=a.allocateTextureUnit();r[0]!==c&&(o.uniform1i(this.addr,c),r[0]=c),a.setTextureCube(e||Yx,c)}function UA(o,e,a){const r=this.cache,c=a.allocateTextureUnit();r[0]!==c&&(o.uniform1i(this.addr,c),r[0]=c),a.setTexture2DArray(e||jx,c)}function LA(o){switch(o){case 5126:return pA;case 35664:return mA;case 35665:return gA;case 35666:return _A;case 35674:return vA;case 35675:return xA;case 35676:return yA;case 5124:case 35670:return SA;case 35667:case 35671:return MA;case 35668:case 35672:return EA;case 35669:case 35673:return TA;case 5125:return bA;case 36294:return AA;case 36295:return RA;case 36296:return CA;case 35678:case 36198:case 36298:case 36306:case 35682:return wA;case 35679:case 36299:case 36307:return DA;case 35680:case 36300:case 36308:case 36293:return NA;case 36289:case 36303:case 36311:case 36292:return UA}}function OA(o,e){o.uniform1fv(this.addr,e)}function zA(o,e){const a=uo(e,this.size,2);o.uniform2fv(this.addr,a)}function PA(o,e){const a=uo(e,this.size,3);o.uniform3fv(this.addr,a)}function IA(o,e){const a=uo(e,this.size,4);o.uniform4fv(this.addr,a)}function BA(o,e){const a=uo(e,this.size,4);o.uniformMatrix2fv(this.addr,!1,a)}function FA(o,e){const a=uo(e,this.size,9);o.uniformMatrix3fv(this.addr,!1,a)}function HA(o,e){const a=uo(e,this.size,16);o.uniformMatrix4fv(this.addr,!1,a)}function GA(o,e){o.uniform1iv(this.addr,e)}function VA(o,e){o.uniform2iv(this.addr,e)}function kA(o,e){o.uniform3iv(this.addr,e)}function XA(o,e){o.uniform4iv(this.addr,e)}function jA(o,e){o.uniform1uiv(this.addr,e)}function qA(o,e){o.uniform2uiv(this.addr,e)}function YA(o,e){o.uniform3uiv(this.addr,e)}function WA(o,e){o.uniform4uiv(this.addr,e)}function ZA(o,e,a){const r=this.cache,c=e.length,f=Au(a,c);xn(r,f)||(o.uniform1iv(this.addr,f),yn(r,f));for(let h=0;h!==c;++h)a.setTexture2D(e[h]||Xx,f[h])}function KA(o,e,a){const r=this.cache,c=e.length,f=Au(a,c);xn(r,f)||(o.uniform1iv(this.addr,f),yn(r,f));for(let h=0;h!==c;++h)a.setTexture3D(e[h]||qx,f[h])}function QA(o,e,a){const r=this.cache,c=e.length,f=Au(a,c);xn(r,f)||(o.uniform1iv(this.addr,f),yn(r,f));for(let h=0;h!==c;++h)a.setTextureCube(e[h]||Yx,f[h])}function JA(o,e,a){const r=this.cache,c=e.length,f=Au(a,c);xn(r,f)||(o.uniform1iv(this.addr,f),yn(r,f));for(let h=0;h!==c;++h)a.setTexture2DArray(e[h]||jx,f[h])}function $A(o){switch(o){case 5126:return OA;case 35664:return zA;case 35665:return PA;case 35666:return IA;case 35674:return BA;case 35675:return FA;case 35676:return HA;case 5124:case 35670:return GA;case 35667:case 35671:return VA;case 35668:case 35672:return kA;case 35669:case 35673:return XA;case 5125:return jA;case 36294:return qA;case 36295:return YA;case 36296:return WA;case 35678:case 36198:case 36298:case 36306:case 35682:return ZA;case 35679:case 36299:case 36307:return KA;case 35680:case 36300:case 36308:case 36293:return QA;case 36289:case 36303:case 36311:case 36292:return JA}}class t2{constructor(e,a,r){this.id=e,this.addr=r,this.cache=[],this.type=a.type,this.setValue=LA(a.type)}}class e2{constructor(e,a,r){this.id=e,this.addr=r,this.cache=[],this.type=a.type,this.size=a.size,this.setValue=$A(a.type)}}class n2{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,a,r){const c=this.seq;for(let f=0,h=c.length;f!==h;++f){const d=c[f];d.setValue(e,a[d.id],r)}}}const Hd=/(\w+)(\])?(\[|\.)?/g;function Qv(o,e){o.seq.push(e),o.map[e.id]=e}function i2(o,e,a){const r=o.name,c=r.length;for(Hd.lastIndex=0;;){const f=Hd.exec(r),h=Hd.lastIndex;let d=f[1];const _=f[2]==="]",m=f[3];if(_&&(d=d|0),m===void 0||m==="["&&h+2===c){Qv(a,m===void 0?new t2(d,o,e):new e2(d,o,e));break}else{let p=a.map[d];p===void 0&&(p=new n2(d),Qv(a,p)),a=p}}}class vu{constructor(e,a){this.seq=[],this.map={};const r=e.getProgramParameter(a,e.ACTIVE_UNIFORMS);for(let c=0;c<r;++c){const f=e.getActiveUniform(a,c),h=e.getUniformLocation(a,f.name);i2(f,h,this)}}setValue(e,a,r,c){const f=this.map[a];f!==void 0&&f.setValue(e,r,c)}setOptional(e,a,r){const c=a[r];c!==void 0&&this.setValue(e,r,c)}static upload(e,a,r,c){for(let f=0,h=a.length;f!==h;++f){const d=a[f],_=r[d.id];_.needsUpdate!==!1&&d.setValue(e,_.value,c)}}static seqWithValue(e,a){const r=[];for(let c=0,f=e.length;c!==f;++c){const h=e[c];h.id in a&&r.push(h)}return r}}function Jv(o,e,a){const r=o.createShader(e);return o.shaderSource(r,a),o.compileShader(r),r}const a2=37297;let s2=0;function r2(o,e){const a=o.split(`
`),r=[],c=Math.max(e-6,0),f=Math.min(e+6,a.length);for(let h=c;h<f;h++){const d=h+1;r.push(`${d===e?">":" "} ${d}: ${a[h]}`)}return r.join(`
`)}const $v=new de;function o2(o){Ne._getMatrix($v,Ne.workingColorSpace,o);const e=`mat3( ${$v.elements.map(a=>a.toFixed(4))} )`;switch(Ne.getTransfer(o)){case xu:return[e,"LinearTransferOETF"];case Xe:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",o),[e,"LinearTransferOETF"]}}function tx(o,e,a){const r=o.getShaderParameter(e,o.COMPILE_STATUS),f=(o.getShaderInfoLog(e)||"").trim();if(r&&f==="")return"";const h=/ERROR: 0:(\d+)/.exec(f);if(h){const d=parseInt(h[1]);return a.toUpperCase()+`

`+f+`

`+r2(o.getShaderSource(e),d)}else return f}function l2(o,e){const a=o2(e);return[`vec4 ${o}( vec4 value ) {`,`	return ${a[1]}( vec4( value.rgb * ${a[0]}, value.a ) );`,"}"].join(`
`)}function c2(o,e){let a;switch(e){case _E:a="Linear";break;case vE:a="Reinhard";break;case xE:a="Cineon";break;case Op:a="ACESFilmic";break;case SE:a="AgX";break;case ME:a="Neutral";break;case yE:a="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),a="Linear"}return"vec3 "+o+"( vec3 color ) { return "+a+"ToneMapping( color ); }"}const hu=new et;function u2(){Ne.getLuminanceCoefficients(hu);const o=hu.x.toFixed(4),e=hu.y.toFixed(4),a=hu.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${o}, ${e}, ${a} );`,"	return dot( weights, rgb );","}"].join(`
`)}function f2(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",o.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ul).join(`
`)}function h2(o){const e=[];for(const a in o){const r=o[a];r!==!1&&e.push("#define "+a+" "+r)}return e.join(`
`)}function d2(o,e){const a={},r=o.getProgramParameter(e,o.ACTIVE_ATTRIBUTES);for(let c=0;c<r;c++){const f=o.getActiveAttrib(e,c),h=f.name;let d=1;f.type===o.FLOAT_MAT2&&(d=2),f.type===o.FLOAT_MAT3&&(d=3),f.type===o.FLOAT_MAT4&&(d=4),a[h]={type:f.type,location:o.getAttribLocation(e,h),locationSize:d}}return a}function ul(o){return o!==""}function ex(o,e){const a=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,a).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function nx(o,e){return o.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const p2=/^[ \t]*#include +<([\w\d./]+)>/gm;function Np(o){return o.replace(p2,g2)}const m2=new Map;function g2(o,e){let a=pe[e];if(a===void 0){const r=m2.get(e);if(r!==void 0)a=pe[r],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,r);else throw new Error("Can not resolve #include <"+e+">")}return Np(a)}const _2=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function ix(o){return o.replace(_2,v2)}function v2(o,e,a,r){let c="";for(let f=parseInt(e);f<parseInt(a);f++)c+=r.replace(/\[\s*i\s*\]/g,"[ "+f+" ]").replace(/UNROLLED_LOOP_INDEX/g,f);return c}function ax(o){let e=`precision ${o.precision} float;
	precision ${o.precision} int;
	precision ${o.precision} sampler2D;
	precision ${o.precision} samplerCube;
	precision ${o.precision} sampler3D;
	precision ${o.precision} sampler2DArray;
	precision ${o.precision} sampler2DShadow;
	precision ${o.precision} samplerCubeShadow;
	precision ${o.precision} sampler2DArrayShadow;
	precision ${o.precision} isampler2D;
	precision ${o.precision} isampler3D;
	precision ${o.precision} isamplerCube;
	precision ${o.precision} isampler2DArray;
	precision ${o.precision} usampler2D;
	precision ${o.precision} usampler3D;
	precision ${o.precision} usamplerCube;
	precision ${o.precision} usampler2DArray;
	`;return o.precision==="highp"?e+=`
#define HIGH_PRECISION`:o.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function x2(o){let e="SHADOWMAP_TYPE_BASIC";return o.shadowMapType===hx?e="SHADOWMAP_TYPE_PCF":o.shadowMapType===KM?e="SHADOWMAP_TYPE_PCF_SOFT":o.shadowMapType===Sa&&(e="SHADOWMAP_TYPE_VSM"),e}function y2(o){let e="ENVMAP_TYPE_CUBE";if(o.envMap)switch(o.envMapMode){case io:case ao:e="ENVMAP_TYPE_CUBE";break;case Tu:e="ENVMAP_TYPE_CUBE_UV";break}return e}function S2(o){let e="ENVMAP_MODE_REFLECTION";return o.envMap&&o.envMapMode===ao&&(e="ENVMAP_MODE_REFRACTION"),e}function M2(o){let e="ENVMAP_BLENDING_NONE";if(o.envMap)switch(o.combine){case dx:e="ENVMAP_BLENDING_MULTIPLY";break;case mE:e="ENVMAP_BLENDING_MIX";break;case gE:e="ENVMAP_BLENDING_ADD";break}return e}function E2(o){const e=o.envMapCubeUVHeight;if(e===null)return null;const a=Math.log2(e)-2,r=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,a),112)),texelHeight:r,maxMip:a}}function T2(o,e,a,r){const c=o.getContext(),f=a.defines;let h=a.vertexShader,d=a.fragmentShader;const _=x2(a),m=y2(a),x=S2(a),p=M2(a),y=E2(a),M=f2(a),b=h2(f),D=c.createProgram();let S,v,L=a.glslVersion?"#version "+a.glslVersion+`
`:"";a.isRawShaderMaterial?(S=["#define SHADER_TYPE "+a.shaderType,"#define SHADER_NAME "+a.shaderName,b].filter(ul).join(`
`),S.length>0&&(S+=`
`),v=["#define SHADER_TYPE "+a.shaderType,"#define SHADER_NAME "+a.shaderName,b].filter(ul).join(`
`),v.length>0&&(v+=`
`)):(S=[ax(a),"#define SHADER_TYPE "+a.shaderType,"#define SHADER_NAME "+a.shaderName,b,a.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",a.batching?"#define USE_BATCHING":"",a.batchingColor?"#define USE_BATCHING_COLOR":"",a.instancing?"#define USE_INSTANCING":"",a.instancingColor?"#define USE_INSTANCING_COLOR":"",a.instancingMorph?"#define USE_INSTANCING_MORPH":"",a.useFog&&a.fog?"#define USE_FOG":"",a.useFog&&a.fogExp2?"#define FOG_EXP2":"",a.map?"#define USE_MAP":"",a.envMap?"#define USE_ENVMAP":"",a.envMap?"#define "+x:"",a.lightMap?"#define USE_LIGHTMAP":"",a.aoMap?"#define USE_AOMAP":"",a.bumpMap?"#define USE_BUMPMAP":"",a.normalMap?"#define USE_NORMALMAP":"",a.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",a.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",a.displacementMap?"#define USE_DISPLACEMENTMAP":"",a.emissiveMap?"#define USE_EMISSIVEMAP":"",a.anisotropy?"#define USE_ANISOTROPY":"",a.anisotropyMap?"#define USE_ANISOTROPYMAP":"",a.clearcoatMap?"#define USE_CLEARCOATMAP":"",a.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",a.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",a.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",a.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",a.specularMap?"#define USE_SPECULARMAP":"",a.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",a.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",a.roughnessMap?"#define USE_ROUGHNESSMAP":"",a.metalnessMap?"#define USE_METALNESSMAP":"",a.alphaMap?"#define USE_ALPHAMAP":"",a.alphaHash?"#define USE_ALPHAHASH":"",a.transmission?"#define USE_TRANSMISSION":"",a.transmissionMap?"#define USE_TRANSMISSIONMAP":"",a.thicknessMap?"#define USE_THICKNESSMAP":"",a.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",a.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",a.mapUv?"#define MAP_UV "+a.mapUv:"",a.alphaMapUv?"#define ALPHAMAP_UV "+a.alphaMapUv:"",a.lightMapUv?"#define LIGHTMAP_UV "+a.lightMapUv:"",a.aoMapUv?"#define AOMAP_UV "+a.aoMapUv:"",a.emissiveMapUv?"#define EMISSIVEMAP_UV "+a.emissiveMapUv:"",a.bumpMapUv?"#define BUMPMAP_UV "+a.bumpMapUv:"",a.normalMapUv?"#define NORMALMAP_UV "+a.normalMapUv:"",a.displacementMapUv?"#define DISPLACEMENTMAP_UV "+a.displacementMapUv:"",a.metalnessMapUv?"#define METALNESSMAP_UV "+a.metalnessMapUv:"",a.roughnessMapUv?"#define ROUGHNESSMAP_UV "+a.roughnessMapUv:"",a.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+a.anisotropyMapUv:"",a.clearcoatMapUv?"#define CLEARCOATMAP_UV "+a.clearcoatMapUv:"",a.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+a.clearcoatNormalMapUv:"",a.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+a.clearcoatRoughnessMapUv:"",a.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+a.iridescenceMapUv:"",a.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+a.iridescenceThicknessMapUv:"",a.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+a.sheenColorMapUv:"",a.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+a.sheenRoughnessMapUv:"",a.specularMapUv?"#define SPECULARMAP_UV "+a.specularMapUv:"",a.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+a.specularColorMapUv:"",a.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+a.specularIntensityMapUv:"",a.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+a.transmissionMapUv:"",a.thicknessMapUv?"#define THICKNESSMAP_UV "+a.thicknessMapUv:"",a.vertexTangents&&a.flatShading===!1?"#define USE_TANGENT":"",a.vertexColors?"#define USE_COLOR":"",a.vertexAlphas?"#define USE_COLOR_ALPHA":"",a.vertexUv1s?"#define USE_UV1":"",a.vertexUv2s?"#define USE_UV2":"",a.vertexUv3s?"#define USE_UV3":"",a.pointsUvs?"#define USE_POINTS_UV":"",a.flatShading?"#define FLAT_SHADED":"",a.skinning?"#define USE_SKINNING":"",a.morphTargets?"#define USE_MORPHTARGETS":"",a.morphNormals&&a.flatShading===!1?"#define USE_MORPHNORMALS":"",a.morphColors?"#define USE_MORPHCOLORS":"",a.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+a.morphTextureStride:"",a.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+a.morphTargetsCount:"",a.doubleSided?"#define DOUBLE_SIDED":"",a.flipSided?"#define FLIP_SIDED":"",a.shadowMapEnabled?"#define USE_SHADOWMAP":"",a.shadowMapEnabled?"#define "+_:"",a.sizeAttenuation?"#define USE_SIZEATTENUATION":"",a.numLightProbes>0?"#define USE_LIGHT_PROBES":"",a.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",a.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(ul).join(`
`),v=[ax(a),"#define SHADER_TYPE "+a.shaderType,"#define SHADER_NAME "+a.shaderName,b,a.useFog&&a.fog?"#define USE_FOG":"",a.useFog&&a.fogExp2?"#define FOG_EXP2":"",a.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",a.map?"#define USE_MAP":"",a.matcap?"#define USE_MATCAP":"",a.envMap?"#define USE_ENVMAP":"",a.envMap?"#define "+m:"",a.envMap?"#define "+x:"",a.envMap?"#define "+p:"",y?"#define CUBEUV_TEXEL_WIDTH "+y.texelWidth:"",y?"#define CUBEUV_TEXEL_HEIGHT "+y.texelHeight:"",y?"#define CUBEUV_MAX_MIP "+y.maxMip+".0":"",a.lightMap?"#define USE_LIGHTMAP":"",a.aoMap?"#define USE_AOMAP":"",a.bumpMap?"#define USE_BUMPMAP":"",a.normalMap?"#define USE_NORMALMAP":"",a.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",a.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",a.emissiveMap?"#define USE_EMISSIVEMAP":"",a.anisotropy?"#define USE_ANISOTROPY":"",a.anisotropyMap?"#define USE_ANISOTROPYMAP":"",a.clearcoat?"#define USE_CLEARCOAT":"",a.clearcoatMap?"#define USE_CLEARCOATMAP":"",a.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",a.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",a.dispersion?"#define USE_DISPERSION":"",a.iridescence?"#define USE_IRIDESCENCE":"",a.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",a.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",a.specularMap?"#define USE_SPECULARMAP":"",a.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",a.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",a.roughnessMap?"#define USE_ROUGHNESSMAP":"",a.metalnessMap?"#define USE_METALNESSMAP":"",a.alphaMap?"#define USE_ALPHAMAP":"",a.alphaTest?"#define USE_ALPHATEST":"",a.alphaHash?"#define USE_ALPHAHASH":"",a.sheen?"#define USE_SHEEN":"",a.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",a.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",a.transmission?"#define USE_TRANSMISSION":"",a.transmissionMap?"#define USE_TRANSMISSIONMAP":"",a.thicknessMap?"#define USE_THICKNESSMAP":"",a.vertexTangents&&a.flatShading===!1?"#define USE_TANGENT":"",a.vertexColors||a.instancingColor||a.batchingColor?"#define USE_COLOR":"",a.vertexAlphas?"#define USE_COLOR_ALPHA":"",a.vertexUv1s?"#define USE_UV1":"",a.vertexUv2s?"#define USE_UV2":"",a.vertexUv3s?"#define USE_UV3":"",a.pointsUvs?"#define USE_POINTS_UV":"",a.gradientMap?"#define USE_GRADIENTMAP":"",a.flatShading?"#define FLAT_SHADED":"",a.doubleSided?"#define DOUBLE_SIDED":"",a.flipSided?"#define FLIP_SIDED":"",a.shadowMapEnabled?"#define USE_SHADOWMAP":"",a.shadowMapEnabled?"#define "+_:"",a.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",a.numLightProbes>0?"#define USE_LIGHT_PROBES":"",a.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",a.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",a.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",a.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",a.toneMapping!==os?"#define TONE_MAPPING":"",a.toneMapping!==os?pe.tonemapping_pars_fragment:"",a.toneMapping!==os?c2("toneMapping",a.toneMapping):"",a.dithering?"#define DITHERING":"",a.opaque?"#define OPAQUE":"",pe.colorspace_pars_fragment,l2("linearToOutputTexel",a.outputColorSpace),u2(),a.useDepthPacking?"#define DEPTH_PACKING "+a.depthPacking:"",`
`].filter(ul).join(`
`)),h=Np(h),h=ex(h,a),h=nx(h,a),d=Np(d),d=ex(d,a),d=nx(d,a),h=ix(h),d=ix(d),a.isRawShaderMaterial!==!0&&(L=`#version 300 es
`,S=[M,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+S,v=["#define varying in",a.glslVersion===pv?"":"layout(location = 0) out highp vec4 pc_fragColor;",a.glslVersion===pv?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+v);const z=L+S+h,N=L+v+d,H=Jv(c,c.VERTEX_SHADER,z),F=Jv(c,c.FRAGMENT_SHADER,N);c.attachShader(D,H),c.attachShader(D,F),a.index0AttributeName!==void 0?c.bindAttribLocation(D,0,a.index0AttributeName):a.morphTargets===!0&&c.bindAttribLocation(D,0,"position"),c.linkProgram(D);function P(G){if(o.debug.checkShaderErrors){const it=c.getProgramInfoLog(D)||"",ct=c.getShaderInfoLog(H)||"",gt=c.getShaderInfoLog(F)||"",ut=it.trim(),W=ct.trim(),rt=gt.trim();let K=!0,vt=!0;if(c.getProgramParameter(D,c.LINK_STATUS)===!1)if(K=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(c,D,H,F);else{const yt=tx(c,H,"vertex"),Gt=tx(c,F,"fragment");console.error("THREE.WebGLProgram: Shader Error "+c.getError()+" - VALIDATE_STATUS "+c.getProgramParameter(D,c.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+ut+`
`+yt+`
`+Gt)}else ut!==""?console.warn("THREE.WebGLProgram: Program Info Log:",ut):(W===""||rt==="")&&(vt=!1);vt&&(G.diagnostics={runnable:K,programLog:ut,vertexShader:{log:W,prefix:S},fragmentShader:{log:rt,prefix:v}})}c.deleteShader(H),c.deleteShader(F),k=new vu(c,D),C=d2(c,D)}let k;this.getUniforms=function(){return k===void 0&&P(this),k};let C;this.getAttributes=function(){return C===void 0&&P(this),C};let w=a.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return w===!1&&(w=c.getProgramParameter(D,a2)),w},this.destroy=function(){r.releaseStatesOfProgram(this),c.deleteProgram(D),this.program=void 0},this.type=a.shaderType,this.name=a.shaderName,this.id=s2++,this.cacheKey=e,this.usedTimes=1,this.program=D,this.vertexShader=H,this.fragmentShader=F,this}let b2=0;class A2{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const a=e.vertexShader,r=e.fragmentShader,c=this._getShaderStage(a),f=this._getShaderStage(r),h=this._getShaderCacheForMaterial(e);return h.has(c)===!1&&(h.add(c),c.usedTimes++),h.has(f)===!1&&(h.add(f),f.usedTimes++),this}remove(e){const a=this.materialCache.get(e);for(const r of a)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const a=this.materialCache;let r=a.get(e);return r===void 0&&(r=new Set,a.set(e,r)),r}_getShaderStage(e){const a=this.shaderCache;let r=a.get(e);return r===void 0&&(r=new R2(e),a.set(e,r)),r}}class R2{constructor(e){this.id=b2++,this.code=e,this.usedTimes=0}}function C2(o,e,a,r,c,f,h){const d=new Cx,_=new A2,m=new Set,x=[],p=c.logarithmicDepthBuffer,y=c.vertexTextures;let M=c.precision;const b={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function D(C){return m.add(C),C===0?"uv":`uv${C}`}function S(C,w,G,it,ct){const gt=it.fog,ut=ct.geometry,W=C.isMeshStandardMaterial?it.environment:null,rt=(C.isMeshStandardMaterial?a:e).get(C.envMap||W),K=rt&&rt.mapping===Tu?rt.image.height:null,vt=b[C.type];C.precision!==null&&(M=c.getMaxPrecision(C.precision),M!==C.precision&&console.warn("THREE.WebGLProgram.getParameters:",C.precision,"not supported, using",M,"instead."));const yt=ut.morphAttributes.position||ut.morphAttributes.normal||ut.morphAttributes.color,Gt=yt!==void 0?yt.length:0;let re=0;ut.morphAttributes.position!==void 0&&(re=1),ut.morphAttributes.normal!==void 0&&(re=2),ut.morphAttributes.color!==void 0&&(re=3);let Ae,B,ft,$;if(vt){const Se=Zi[vt];Ae=Se.vertexShader,B=Se.fragmentShader}else Ae=C.vertexShader,B=C.fragmentShader,_.update(C),ft=_.getVertexShaderID(C),$=_.getFragmentShaderID(C);const st=o.getRenderTarget(),Mt=o.state.buffers.depth.getReversed(),Ut=ct.isInstancedMesh===!0,Rt=ct.isBatchedMesh===!0,Et=!!C.map,qt=!!C.matcap,I=!!rt,Ge=!!C.aoMap,se=!!C.lightMap,Qt=!!C.bumpMap,Lt=!!C.normalMap,ie=!!C.displacementMap,Ft=!!C.emissiveMap,oe=!!C.metalnessMap,qe=!!C.roughnessMap,We=C.anisotropy>0,U=C.clearcoat>0,T=C.dispersion>0,nt=C.iridescence>0,pt=C.sheen>0,xt=C.transmission>0,ht=We&&!!C.anisotropyMap,kt=U&&!!C.clearcoatMap,Ct=U&&!!C.clearcoatNormalMap,Wt=U&&!!C.clearcoatRoughnessMap,Kt=nt&&!!C.iridescenceMap,bt=nt&&!!C.iridescenceThicknessMap,Ot=pt&&!!C.sheenColorMap,ne=pt&&!!C.sheenRoughnessMap,Zt=!!C.specularMap,zt=!!C.specularColorMap,ue=!!C.specularIntensityMap,X=xt&&!!C.transmissionMap,At=xt&&!!C.thicknessMap,Dt=!!C.gradientMap,Vt=!!C.alphaMap,St=C.alphaTest>0,_t=!!C.alphaHash,Yt=!!C.extensions;let ce=os;C.toneMapped&&(st===null||st.isXRRenderTarget===!0)&&(ce=o.toneMapping);const Ve={shaderID:vt,shaderType:C.type,shaderName:C.name,vertexShader:Ae,fragmentShader:B,defines:C.defines,customVertexShaderID:ft,customFragmentShaderID:$,isRawShaderMaterial:C.isRawShaderMaterial===!0,glslVersion:C.glslVersion,precision:M,batching:Rt,batchingColor:Rt&&ct._colorsTexture!==null,instancing:Ut,instancingColor:Ut&&ct.instanceColor!==null,instancingMorph:Ut&&ct.morphTexture!==null,supportsVertexTextures:y,outputColorSpace:st===null?o.outputColorSpace:st.isXRRenderTarget===!0?st.texture.colorSpace:so,alphaToCoverage:!!C.alphaToCoverage,map:Et,matcap:qt,envMap:I,envMapMode:I&&rt.mapping,envMapCubeUVHeight:K,aoMap:Ge,lightMap:se,bumpMap:Qt,normalMap:Lt,displacementMap:y&&ie,emissiveMap:Ft,normalMapObjectSpace:Lt&&C.normalMapType===AE,normalMapTangentSpace:Lt&&C.normalMapType===Ex,metalnessMap:oe,roughnessMap:qe,anisotropy:We,anisotropyMap:ht,clearcoat:U,clearcoatMap:kt,clearcoatNormalMap:Ct,clearcoatRoughnessMap:Wt,dispersion:T,iridescence:nt,iridescenceMap:Kt,iridescenceThicknessMap:bt,sheen:pt,sheenColorMap:Ot,sheenRoughnessMap:ne,specularMap:Zt,specularColorMap:zt,specularIntensityMap:ue,transmission:xt,transmissionMap:X,thicknessMap:At,gradientMap:Dt,opaque:C.transparent===!1&&C.blending===to&&C.alphaToCoverage===!1,alphaMap:Vt,alphaTest:St,alphaHash:_t,combine:C.combine,mapUv:Et&&D(C.map.channel),aoMapUv:Ge&&D(C.aoMap.channel),lightMapUv:se&&D(C.lightMap.channel),bumpMapUv:Qt&&D(C.bumpMap.channel),normalMapUv:Lt&&D(C.normalMap.channel),displacementMapUv:ie&&D(C.displacementMap.channel),emissiveMapUv:Ft&&D(C.emissiveMap.channel),metalnessMapUv:oe&&D(C.metalnessMap.channel),roughnessMapUv:qe&&D(C.roughnessMap.channel),anisotropyMapUv:ht&&D(C.anisotropyMap.channel),clearcoatMapUv:kt&&D(C.clearcoatMap.channel),clearcoatNormalMapUv:Ct&&D(C.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Wt&&D(C.clearcoatRoughnessMap.channel),iridescenceMapUv:Kt&&D(C.iridescenceMap.channel),iridescenceThicknessMapUv:bt&&D(C.iridescenceThicknessMap.channel),sheenColorMapUv:Ot&&D(C.sheenColorMap.channel),sheenRoughnessMapUv:ne&&D(C.sheenRoughnessMap.channel),specularMapUv:Zt&&D(C.specularMap.channel),specularColorMapUv:zt&&D(C.specularColorMap.channel),specularIntensityMapUv:ue&&D(C.specularIntensityMap.channel),transmissionMapUv:X&&D(C.transmissionMap.channel),thicknessMapUv:At&&D(C.thicknessMap.channel),alphaMapUv:Vt&&D(C.alphaMap.channel),vertexTangents:!!ut.attributes.tangent&&(Lt||We),vertexColors:C.vertexColors,vertexAlphas:C.vertexColors===!0&&!!ut.attributes.color&&ut.attributes.color.itemSize===4,pointsUvs:ct.isPoints===!0&&!!ut.attributes.uv&&(Et||Vt),fog:!!gt,useFog:C.fog===!0,fogExp2:!!gt&&gt.isFogExp2,flatShading:C.flatShading===!0&&C.wireframe===!1,sizeAttenuation:C.sizeAttenuation===!0,logarithmicDepthBuffer:p,reversedDepthBuffer:Mt,skinning:ct.isSkinnedMesh===!0,morphTargets:ut.morphAttributes.position!==void 0,morphNormals:ut.morphAttributes.normal!==void 0,morphColors:ut.morphAttributes.color!==void 0,morphTargetsCount:Gt,morphTextureStride:re,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:h.numPlanes,numClipIntersection:h.numIntersection,dithering:C.dithering,shadowMapEnabled:o.shadowMap.enabled&&G.length>0,shadowMapType:o.shadowMap.type,toneMapping:ce,decodeVideoTexture:Et&&C.map.isVideoTexture===!0&&Ne.getTransfer(C.map.colorSpace)===Xe,decodeVideoTextureEmissive:Ft&&C.emissiveMap.isVideoTexture===!0&&Ne.getTransfer(C.emissiveMap.colorSpace)===Xe,premultipliedAlpha:C.premultipliedAlpha,doubleSided:C.side===Ma,flipSided:C.side===Kn,useDepthPacking:C.depthPacking>=0,depthPacking:C.depthPacking||0,index0AttributeName:C.index0AttributeName,extensionClipCullDistance:Yt&&C.extensions.clipCullDistance===!0&&r.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Yt&&C.extensions.multiDraw===!0||Rt)&&r.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:r.has("KHR_parallel_shader_compile"),customProgramCacheKey:C.customProgramCacheKey()};return Ve.vertexUv1s=m.has(1),Ve.vertexUv2s=m.has(2),Ve.vertexUv3s=m.has(3),m.clear(),Ve}function v(C){const w=[];if(C.shaderID?w.push(C.shaderID):(w.push(C.customVertexShaderID),w.push(C.customFragmentShaderID)),C.defines!==void 0)for(const G in C.defines)w.push(G),w.push(C.defines[G]);return C.isRawShaderMaterial===!1&&(L(w,C),z(w,C),w.push(o.outputColorSpace)),w.push(C.customProgramCacheKey),w.join()}function L(C,w){C.push(w.precision),C.push(w.outputColorSpace),C.push(w.envMapMode),C.push(w.envMapCubeUVHeight),C.push(w.mapUv),C.push(w.alphaMapUv),C.push(w.lightMapUv),C.push(w.aoMapUv),C.push(w.bumpMapUv),C.push(w.normalMapUv),C.push(w.displacementMapUv),C.push(w.emissiveMapUv),C.push(w.metalnessMapUv),C.push(w.roughnessMapUv),C.push(w.anisotropyMapUv),C.push(w.clearcoatMapUv),C.push(w.clearcoatNormalMapUv),C.push(w.clearcoatRoughnessMapUv),C.push(w.iridescenceMapUv),C.push(w.iridescenceThicknessMapUv),C.push(w.sheenColorMapUv),C.push(w.sheenRoughnessMapUv),C.push(w.specularMapUv),C.push(w.specularColorMapUv),C.push(w.specularIntensityMapUv),C.push(w.transmissionMapUv),C.push(w.thicknessMapUv),C.push(w.combine),C.push(w.fogExp2),C.push(w.sizeAttenuation),C.push(w.morphTargetsCount),C.push(w.morphAttributeCount),C.push(w.numDirLights),C.push(w.numPointLights),C.push(w.numSpotLights),C.push(w.numSpotLightMaps),C.push(w.numHemiLights),C.push(w.numRectAreaLights),C.push(w.numDirLightShadows),C.push(w.numPointLightShadows),C.push(w.numSpotLightShadows),C.push(w.numSpotLightShadowsWithMaps),C.push(w.numLightProbes),C.push(w.shadowMapType),C.push(w.toneMapping),C.push(w.numClippingPlanes),C.push(w.numClipIntersection),C.push(w.depthPacking)}function z(C,w){d.disableAll(),w.supportsVertexTextures&&d.enable(0),w.instancing&&d.enable(1),w.instancingColor&&d.enable(2),w.instancingMorph&&d.enable(3),w.matcap&&d.enable(4),w.envMap&&d.enable(5),w.normalMapObjectSpace&&d.enable(6),w.normalMapTangentSpace&&d.enable(7),w.clearcoat&&d.enable(8),w.iridescence&&d.enable(9),w.alphaTest&&d.enable(10),w.vertexColors&&d.enable(11),w.vertexAlphas&&d.enable(12),w.vertexUv1s&&d.enable(13),w.vertexUv2s&&d.enable(14),w.vertexUv3s&&d.enable(15),w.vertexTangents&&d.enable(16),w.anisotropy&&d.enable(17),w.alphaHash&&d.enable(18),w.batching&&d.enable(19),w.dispersion&&d.enable(20),w.batchingColor&&d.enable(21),w.gradientMap&&d.enable(22),C.push(d.mask),d.disableAll(),w.fog&&d.enable(0),w.useFog&&d.enable(1),w.flatShading&&d.enable(2),w.logarithmicDepthBuffer&&d.enable(3),w.reversedDepthBuffer&&d.enable(4),w.skinning&&d.enable(5),w.morphTargets&&d.enable(6),w.morphNormals&&d.enable(7),w.morphColors&&d.enable(8),w.premultipliedAlpha&&d.enable(9),w.shadowMapEnabled&&d.enable(10),w.doubleSided&&d.enable(11),w.flipSided&&d.enable(12),w.useDepthPacking&&d.enable(13),w.dithering&&d.enable(14),w.transmission&&d.enable(15),w.sheen&&d.enable(16),w.opaque&&d.enable(17),w.pointsUvs&&d.enable(18),w.decodeVideoTexture&&d.enable(19),w.decodeVideoTextureEmissive&&d.enable(20),w.alphaToCoverage&&d.enable(21),C.push(d.mask)}function N(C){const w=b[C.type];let G;if(w){const it=Zi[w];G=e1.clone(it.uniforms)}else G=C.uniforms;return G}function H(C,w){let G;for(let it=0,ct=x.length;it<ct;it++){const gt=x[it];if(gt.cacheKey===w){G=gt,++G.usedTimes;break}}return G===void 0&&(G=new T2(o,w,C,f),x.push(G)),G}function F(C){if(--C.usedTimes===0){const w=x.indexOf(C);x[w]=x[x.length-1],x.pop(),C.destroy()}}function P(C){_.remove(C)}function k(){_.dispose()}return{getParameters:S,getProgramCacheKey:v,getUniforms:N,acquireProgram:H,releaseProgram:F,releaseShaderCache:P,programs:x,dispose:k}}function w2(){let o=new WeakMap;function e(h){return o.has(h)}function a(h){let d=o.get(h);return d===void 0&&(d={},o.set(h,d)),d}function r(h){o.delete(h)}function c(h,d,_){o.get(h)[d]=_}function f(){o=new WeakMap}return{has:e,get:a,remove:r,update:c,dispose:f}}function D2(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.material.id!==e.material.id?o.material.id-e.material.id:o.z!==e.z?o.z-e.z:o.id-e.id}function sx(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.z!==e.z?e.z-o.z:o.id-e.id}function rx(){const o=[];let e=0;const a=[],r=[],c=[];function f(){e=0,a.length=0,r.length=0,c.length=0}function h(p,y,M,b,D,S){let v=o[e];return v===void 0?(v={id:p.id,object:p,geometry:y,material:M,groupOrder:b,renderOrder:p.renderOrder,z:D,group:S},o[e]=v):(v.id=p.id,v.object=p,v.geometry=y,v.material=M,v.groupOrder=b,v.renderOrder=p.renderOrder,v.z=D,v.group=S),e++,v}function d(p,y,M,b,D,S){const v=h(p,y,M,b,D,S);M.transmission>0?r.push(v):M.transparent===!0?c.push(v):a.push(v)}function _(p,y,M,b,D,S){const v=h(p,y,M,b,D,S);M.transmission>0?r.unshift(v):M.transparent===!0?c.unshift(v):a.unshift(v)}function m(p,y){a.length>1&&a.sort(p||D2),r.length>1&&r.sort(y||sx),c.length>1&&c.sort(y||sx)}function x(){for(let p=e,y=o.length;p<y;p++){const M=o[p];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:a,transmissive:r,transparent:c,init:f,push:d,unshift:_,finish:x,sort:m}}function N2(){let o=new WeakMap;function e(r,c){const f=o.get(r);let h;return f===void 0?(h=new rx,o.set(r,[h])):c>=f.length?(h=new rx,f.push(h)):h=f[c],h}function a(){o=new WeakMap}return{get:e,dispose:a}}function U2(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let a;switch(e.type){case"DirectionalLight":a={direction:new et,color:new Te};break;case"SpotLight":a={position:new et,direction:new et,color:new Te,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":a={position:new et,color:new Te,distance:0,decay:0};break;case"HemisphereLight":a={direction:new et,skyColor:new Te,groundColor:new Te};break;case"RectAreaLight":a={color:new Te,position:new et,halfWidth:new et,halfHeight:new et};break}return o[e.id]=a,a}}}function L2(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let a;switch(e.type){case"DirectionalLight":a={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ue};break;case"SpotLight":a={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ue};break;case"PointLight":a={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Ue,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[e.id]=a,a}}}let O2=0;function z2(o,e){return(e.castShadow?2:0)-(o.castShadow?2:0)+(e.map?1:0)-(o.map?1:0)}function P2(o){const e=new U2,a=L2(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let m=0;m<9;m++)r.probe.push(new et);const c=new et,f=new sn,h=new sn;function d(m){let x=0,p=0,y=0;for(let C=0;C<9;C++)r.probe[C].set(0,0,0);let M=0,b=0,D=0,S=0,v=0,L=0,z=0,N=0,H=0,F=0,P=0;m.sort(z2);for(let C=0,w=m.length;C<w;C++){const G=m[C],it=G.color,ct=G.intensity,gt=G.distance,ut=G.shadow&&G.shadow.map?G.shadow.map.texture:null;if(G.isAmbientLight)x+=it.r*ct,p+=it.g*ct,y+=it.b*ct;else if(G.isLightProbe){for(let W=0;W<9;W++)r.probe[W].addScaledVector(G.sh.coefficients[W],ct);P++}else if(G.isDirectionalLight){const W=e.get(G);if(W.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const rt=G.shadow,K=a.get(G);K.shadowIntensity=rt.intensity,K.shadowBias=rt.bias,K.shadowNormalBias=rt.normalBias,K.shadowRadius=rt.radius,K.shadowMapSize=rt.mapSize,r.directionalShadow[M]=K,r.directionalShadowMap[M]=ut,r.directionalShadowMatrix[M]=G.shadow.matrix,L++}r.directional[M]=W,M++}else if(G.isSpotLight){const W=e.get(G);W.position.setFromMatrixPosition(G.matrixWorld),W.color.copy(it).multiplyScalar(ct),W.distance=gt,W.coneCos=Math.cos(G.angle),W.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),W.decay=G.decay,r.spot[D]=W;const rt=G.shadow;if(G.map&&(r.spotLightMap[H]=G.map,H++,rt.updateMatrices(G),G.castShadow&&F++),r.spotLightMatrix[D]=rt.matrix,G.castShadow){const K=a.get(G);K.shadowIntensity=rt.intensity,K.shadowBias=rt.bias,K.shadowNormalBias=rt.normalBias,K.shadowRadius=rt.radius,K.shadowMapSize=rt.mapSize,r.spotShadow[D]=K,r.spotShadowMap[D]=ut,N++}D++}else if(G.isRectAreaLight){const W=e.get(G);W.color.copy(it).multiplyScalar(ct),W.halfWidth.set(G.width*.5,0,0),W.halfHeight.set(0,G.height*.5,0),r.rectArea[S]=W,S++}else if(G.isPointLight){const W=e.get(G);if(W.color.copy(G.color).multiplyScalar(G.intensity),W.distance=G.distance,W.decay=G.decay,G.castShadow){const rt=G.shadow,K=a.get(G);K.shadowIntensity=rt.intensity,K.shadowBias=rt.bias,K.shadowNormalBias=rt.normalBias,K.shadowRadius=rt.radius,K.shadowMapSize=rt.mapSize,K.shadowCameraNear=rt.camera.near,K.shadowCameraFar=rt.camera.far,r.pointShadow[b]=K,r.pointShadowMap[b]=ut,r.pointShadowMatrix[b]=G.shadow.matrix,z++}r.point[b]=W,b++}else if(G.isHemisphereLight){const W=e.get(G);W.skyColor.copy(G.color).multiplyScalar(ct),W.groundColor.copy(G.groundColor).multiplyScalar(ct),r.hemi[v]=W,v++}}S>0&&(o.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=It.LTC_FLOAT_1,r.rectAreaLTC2=It.LTC_FLOAT_2):(r.rectAreaLTC1=It.LTC_HALF_1,r.rectAreaLTC2=It.LTC_HALF_2)),r.ambient[0]=x,r.ambient[1]=p,r.ambient[2]=y;const k=r.hash;(k.directionalLength!==M||k.pointLength!==b||k.spotLength!==D||k.rectAreaLength!==S||k.hemiLength!==v||k.numDirectionalShadows!==L||k.numPointShadows!==z||k.numSpotShadows!==N||k.numSpotMaps!==H||k.numLightProbes!==P)&&(r.directional.length=M,r.spot.length=D,r.rectArea.length=S,r.point.length=b,r.hemi.length=v,r.directionalShadow.length=L,r.directionalShadowMap.length=L,r.pointShadow.length=z,r.pointShadowMap.length=z,r.spotShadow.length=N,r.spotShadowMap.length=N,r.directionalShadowMatrix.length=L,r.pointShadowMatrix.length=z,r.spotLightMatrix.length=N+H-F,r.spotLightMap.length=H,r.numSpotLightShadowsWithMaps=F,r.numLightProbes=P,k.directionalLength=M,k.pointLength=b,k.spotLength=D,k.rectAreaLength=S,k.hemiLength=v,k.numDirectionalShadows=L,k.numPointShadows=z,k.numSpotShadows=N,k.numSpotMaps=H,k.numLightProbes=P,r.version=O2++)}function _(m,x){let p=0,y=0,M=0,b=0,D=0;const S=x.matrixWorldInverse;for(let v=0,L=m.length;v<L;v++){const z=m[v];if(z.isDirectionalLight){const N=r.directional[p];N.direction.setFromMatrixPosition(z.matrixWorld),c.setFromMatrixPosition(z.target.matrixWorld),N.direction.sub(c),N.direction.transformDirection(S),p++}else if(z.isSpotLight){const N=r.spot[M];N.position.setFromMatrixPosition(z.matrixWorld),N.position.applyMatrix4(S),N.direction.setFromMatrixPosition(z.matrixWorld),c.setFromMatrixPosition(z.target.matrixWorld),N.direction.sub(c),N.direction.transformDirection(S),M++}else if(z.isRectAreaLight){const N=r.rectArea[b];N.position.setFromMatrixPosition(z.matrixWorld),N.position.applyMatrix4(S),h.identity(),f.copy(z.matrixWorld),f.premultiply(S),h.extractRotation(f),N.halfWidth.set(z.width*.5,0,0),N.halfHeight.set(0,z.height*.5,0),N.halfWidth.applyMatrix4(h),N.halfHeight.applyMatrix4(h),b++}else if(z.isPointLight){const N=r.point[y];N.position.setFromMatrixPosition(z.matrixWorld),N.position.applyMatrix4(S),y++}else if(z.isHemisphereLight){const N=r.hemi[D];N.direction.setFromMatrixPosition(z.matrixWorld),N.direction.transformDirection(S),D++}}}return{setup:d,setupView:_,state:r}}function ox(o){const e=new P2(o),a=[],r=[];function c(x){m.camera=x,a.length=0,r.length=0}function f(x){a.push(x)}function h(x){r.push(x)}function d(){e.setup(a)}function _(x){e.setupView(a,x)}const m={lightsArray:a,shadowsArray:r,camera:null,lights:e,transmissionRenderTarget:{}};return{init:c,state:m,setupLights:d,setupLightsView:_,pushLight:f,pushShadow:h}}function I2(o){let e=new WeakMap;function a(c,f=0){const h=e.get(c);let d;return h===void 0?(d=new ox(o),e.set(c,[d])):f>=h.length?(d=new ox(o),h.push(d)):d=h[f],d}function r(){e=new WeakMap}return{get:a,dispose:r}}const B2=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,F2=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function H2(o,e,a){let r=new Vp;const c=new Ue,f=new Ue,h=new je,d=new f1({depthPacking:bE}),_=new h1,m={},x=a.maxTextureSize,p={[cs]:Kn,[Kn]:cs,[Ma]:Ma},y=new us({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Ue},radius:{value:4}},vertexShader:B2,fragmentShader:F2}),M=y.clone();M.defines.HORIZONTAL_PASS=1;const b=new Pi;b.setAttribute("position",new zi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const D=new tn(b,y),S=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=hx;let v=this.type;this.render=function(F,P,k){if(S.enabled===!1||S.autoUpdate===!1&&S.needsUpdate===!1||F.length===0)return;const C=o.getRenderTarget(),w=o.getActiveCubeFace(),G=o.getActiveMipmapLevel(),it=o.state;it.setBlending(rs),it.buffers.depth.getReversed()===!0?it.buffers.color.setClear(0,0,0,0):it.buffers.color.setClear(1,1,1,1),it.buffers.depth.setTest(!0),it.setScissorTest(!1);const ct=v!==Sa&&this.type===Sa,gt=v===Sa&&this.type!==Sa;for(let ut=0,W=F.length;ut<W;ut++){const rt=F[ut],K=rt.shadow;if(K===void 0){console.warn("THREE.WebGLShadowMap:",rt,"has no shadow.");continue}if(K.autoUpdate===!1&&K.needsUpdate===!1)continue;c.copy(K.mapSize);const vt=K.getFrameExtents();if(c.multiply(vt),f.copy(K.mapSize),(c.x>x||c.y>x)&&(c.x>x&&(f.x=Math.floor(x/vt.x),c.x=f.x*vt.x,K.mapSize.x=f.x),c.y>x&&(f.y=Math.floor(x/vt.y),c.y=f.y*vt.y,K.mapSize.y=f.y)),K.map===null||ct===!0||gt===!0){const Gt=this.type!==Sa?{minFilter:Oi,magFilter:Oi}:{};K.map!==null&&K.map.dispose(),K.map=new Ks(c.x,c.y,Gt),K.map.texture.name=rt.name+".shadowMap",K.camera.updateProjectionMatrix()}o.setRenderTarget(K.map),o.clear();const yt=K.getViewportCount();for(let Gt=0;Gt<yt;Gt++){const re=K.getViewport(Gt);h.set(f.x*re.x,f.y*re.y,f.x*re.z,f.y*re.w),it.viewport(h),K.updateMatrices(rt,Gt),r=K.getFrustum(),N(P,k,K.camera,rt,this.type)}K.isPointLightShadow!==!0&&this.type===Sa&&L(K,k),K.needsUpdate=!1}v=this.type,S.needsUpdate=!1,o.setRenderTarget(C,w,G)};function L(F,P){const k=e.update(D);y.defines.VSM_SAMPLES!==F.blurSamples&&(y.defines.VSM_SAMPLES=F.blurSamples,M.defines.VSM_SAMPLES=F.blurSamples,y.needsUpdate=!0,M.needsUpdate=!0),F.mapPass===null&&(F.mapPass=new Ks(c.x,c.y)),y.uniforms.shadow_pass.value=F.map.texture,y.uniforms.resolution.value=F.mapSize,y.uniforms.radius.value=F.radius,o.setRenderTarget(F.mapPass),o.clear(),o.renderBufferDirect(P,null,k,y,D,null),M.uniforms.shadow_pass.value=F.mapPass.texture,M.uniforms.resolution.value=F.mapSize,M.uniforms.radius.value=F.radius,o.setRenderTarget(F.map),o.clear(),o.renderBufferDirect(P,null,k,M,D,null)}function z(F,P,k,C){let w=null;const G=k.isPointLight===!0?F.customDistanceMaterial:F.customDepthMaterial;if(G!==void 0)w=G;else if(w=k.isPointLight===!0?_:d,o.localClippingEnabled&&P.clipShadows===!0&&Array.isArray(P.clippingPlanes)&&P.clippingPlanes.length!==0||P.displacementMap&&P.displacementScale!==0||P.alphaMap&&P.alphaTest>0||P.map&&P.alphaTest>0||P.alphaToCoverage===!0){const it=w.uuid,ct=P.uuid;let gt=m[it];gt===void 0&&(gt={},m[it]=gt);let ut=gt[ct];ut===void 0&&(ut=w.clone(),gt[ct]=ut,P.addEventListener("dispose",H)),w=ut}if(w.visible=P.visible,w.wireframe=P.wireframe,C===Sa?w.side=P.shadowSide!==null?P.shadowSide:P.side:w.side=P.shadowSide!==null?P.shadowSide:p[P.side],w.alphaMap=P.alphaMap,w.alphaTest=P.alphaToCoverage===!0?.5:P.alphaTest,w.map=P.map,w.clipShadows=P.clipShadows,w.clippingPlanes=P.clippingPlanes,w.clipIntersection=P.clipIntersection,w.displacementMap=P.displacementMap,w.displacementScale=P.displacementScale,w.displacementBias=P.displacementBias,w.wireframeLinewidth=P.wireframeLinewidth,w.linewidth=P.linewidth,k.isPointLight===!0&&w.isMeshDistanceMaterial===!0){const it=o.properties.get(w);it.light=k}return w}function N(F,P,k,C,w){if(F.visible===!1)return;if(F.layers.test(P.layers)&&(F.isMesh||F.isLine||F.isPoints)&&(F.castShadow||F.receiveShadow&&w===Sa)&&(!F.frustumCulled||r.intersectsObject(F))){F.modelViewMatrix.multiplyMatrices(k.matrixWorldInverse,F.matrixWorld);const ct=e.update(F),gt=F.material;if(Array.isArray(gt)){const ut=ct.groups;for(let W=0,rt=ut.length;W<rt;W++){const K=ut[W],vt=gt[K.materialIndex];if(vt&&vt.visible){const yt=z(F,vt,C,w);F.onBeforeShadow(o,F,P,k,ct,yt,K),o.renderBufferDirect(k,null,ct,yt,F,K),F.onAfterShadow(o,F,P,k,ct,yt,K)}}}else if(gt.visible){const ut=z(F,gt,C,w);F.onBeforeShadow(o,F,P,k,ct,ut,null),o.renderBufferDirect(k,null,ct,ut,F,null),F.onAfterShadow(o,F,P,k,ct,ut,null)}}const it=F.children;for(let ct=0,gt=it.length;ct<gt;ct++)N(it[ct],P,k,C,w)}function H(F){F.target.removeEventListener("dispose",H);for(const k in m){const C=m[k],w=F.target.uuid;w in C&&(C[w].dispose(),delete C[w])}}}const G2={[kd]:Xd,[jd]:Wd,[qd]:Zd,[no]:Yd,[Xd]:kd,[Wd]:jd,[Zd]:qd,[Yd]:no};function V2(o,e){function a(){let X=!1;const At=new je;let Dt=null;const Vt=new je(0,0,0,0);return{setMask:function(St){Dt!==St&&!X&&(o.colorMask(St,St,St,St),Dt=St)},setLocked:function(St){X=St},setClear:function(St,_t,Yt,ce,Ve){Ve===!0&&(St*=ce,_t*=ce,Yt*=ce),At.set(St,_t,Yt,ce),Vt.equals(At)===!1&&(o.clearColor(St,_t,Yt,ce),Vt.copy(At))},reset:function(){X=!1,Dt=null,Vt.set(-1,0,0,0)}}}function r(){let X=!1,At=!1,Dt=null,Vt=null,St=null;return{setReversed:function(_t){if(At!==_t){const Yt=e.get("EXT_clip_control");_t?Yt.clipControlEXT(Yt.LOWER_LEFT_EXT,Yt.ZERO_TO_ONE_EXT):Yt.clipControlEXT(Yt.LOWER_LEFT_EXT,Yt.NEGATIVE_ONE_TO_ONE_EXT),At=_t;const ce=St;St=null,this.setClear(ce)}},getReversed:function(){return At},setTest:function(_t){_t?st(o.DEPTH_TEST):Mt(o.DEPTH_TEST)},setMask:function(_t){Dt!==_t&&!X&&(o.depthMask(_t),Dt=_t)},setFunc:function(_t){if(At&&(_t=G2[_t]),Vt!==_t){switch(_t){case kd:o.depthFunc(o.NEVER);break;case Xd:o.depthFunc(o.ALWAYS);break;case jd:o.depthFunc(o.LESS);break;case no:o.depthFunc(o.LEQUAL);break;case qd:o.depthFunc(o.EQUAL);break;case Yd:o.depthFunc(o.GEQUAL);break;case Wd:o.depthFunc(o.GREATER);break;case Zd:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}Vt=_t}},setLocked:function(_t){X=_t},setClear:function(_t){St!==_t&&(At&&(_t=1-_t),o.clearDepth(_t),St=_t)},reset:function(){X=!1,Dt=null,Vt=null,St=null,At=!1}}}function c(){let X=!1,At=null,Dt=null,Vt=null,St=null,_t=null,Yt=null,ce=null,Ve=null;return{setTest:function(Se){X||(Se?st(o.STENCIL_TEST):Mt(o.STENCIL_TEST))},setMask:function(Se){At!==Se&&!X&&(o.stencilMask(Se),At=Se)},setFunc:function(Se,en,gn){(Dt!==Se||Vt!==en||St!==gn)&&(o.stencilFunc(Se,en,gn),Dt=Se,Vt=en,St=gn)},setOp:function(Se,en,gn){(_t!==Se||Yt!==en||ce!==gn)&&(o.stencilOp(Se,en,gn),_t=Se,Yt=en,ce=gn)},setLocked:function(Se){X=Se},setClear:function(Se){Ve!==Se&&(o.clearStencil(Se),Ve=Se)},reset:function(){X=!1,At=null,Dt=null,Vt=null,St=null,_t=null,Yt=null,ce=null,Ve=null}}}const f=new a,h=new r,d=new c,_=new WeakMap,m=new WeakMap;let x={},p={},y=new WeakMap,M=[],b=null,D=!1,S=null,v=null,L=null,z=null,N=null,H=null,F=null,P=new Te(0,0,0),k=0,C=!1,w=null,G=null,it=null,ct=null,gt=null;const ut=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let W=!1,rt=0;const K=o.getParameter(o.VERSION);K.indexOf("WebGL")!==-1?(rt=parseFloat(/^WebGL (\d)/.exec(K)[1]),W=rt>=1):K.indexOf("OpenGL ES")!==-1&&(rt=parseFloat(/^OpenGL ES (\d)/.exec(K)[1]),W=rt>=2);let vt=null,yt={};const Gt=o.getParameter(o.SCISSOR_BOX),re=o.getParameter(o.VIEWPORT),Ae=new je().fromArray(Gt),B=new je().fromArray(re);function ft(X,At,Dt,Vt){const St=new Uint8Array(4),_t=o.createTexture();o.bindTexture(X,_t),o.texParameteri(X,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(X,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let Yt=0;Yt<Dt;Yt++)X===o.TEXTURE_3D||X===o.TEXTURE_2D_ARRAY?o.texImage3D(At,0,o.RGBA,1,1,Vt,0,o.RGBA,o.UNSIGNED_BYTE,St):o.texImage2D(At+Yt,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,St);return _t}const $={};$[o.TEXTURE_2D]=ft(o.TEXTURE_2D,o.TEXTURE_2D,1),$[o.TEXTURE_CUBE_MAP]=ft(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),$[o.TEXTURE_2D_ARRAY]=ft(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),$[o.TEXTURE_3D]=ft(o.TEXTURE_3D,o.TEXTURE_3D,1,1),f.setClear(0,0,0,1),h.setClear(1),d.setClear(0),st(o.DEPTH_TEST),h.setFunc(no),Qt(!1),Lt(lv),st(o.CULL_FACE),Ge(rs);function st(X){x[X]!==!0&&(o.enable(X),x[X]=!0)}function Mt(X){x[X]!==!1&&(o.disable(X),x[X]=!1)}function Ut(X,At){return p[X]!==At?(o.bindFramebuffer(X,At),p[X]=At,X===o.DRAW_FRAMEBUFFER&&(p[o.FRAMEBUFFER]=At),X===o.FRAMEBUFFER&&(p[o.DRAW_FRAMEBUFFER]=At),!0):!1}function Rt(X,At){let Dt=M,Vt=!1;if(X){Dt=y.get(At),Dt===void 0&&(Dt=[],y.set(At,Dt));const St=X.textures;if(Dt.length!==St.length||Dt[0]!==o.COLOR_ATTACHMENT0){for(let _t=0,Yt=St.length;_t<Yt;_t++)Dt[_t]=o.COLOR_ATTACHMENT0+_t;Dt.length=St.length,Vt=!0}}else Dt[0]!==o.BACK&&(Dt[0]=o.BACK,Vt=!0);Vt&&o.drawBuffers(Dt)}function Et(X){return b!==X?(o.useProgram(X),b=X,!0):!1}const qt={[ks]:o.FUNC_ADD,[JM]:o.FUNC_SUBTRACT,[$M]:o.FUNC_REVERSE_SUBTRACT};qt[tE]=o.MIN,qt[eE]=o.MAX;const I={[nE]:o.ZERO,[iE]:o.ONE,[aE]:o.SRC_COLOR,[Gd]:o.SRC_ALPHA,[uE]:o.SRC_ALPHA_SATURATE,[lE]:o.DST_COLOR,[rE]:o.DST_ALPHA,[sE]:o.ONE_MINUS_SRC_COLOR,[Vd]:o.ONE_MINUS_SRC_ALPHA,[cE]:o.ONE_MINUS_DST_COLOR,[oE]:o.ONE_MINUS_DST_ALPHA,[fE]:o.CONSTANT_COLOR,[hE]:o.ONE_MINUS_CONSTANT_COLOR,[dE]:o.CONSTANT_ALPHA,[pE]:o.ONE_MINUS_CONSTANT_ALPHA};function Ge(X,At,Dt,Vt,St,_t,Yt,ce,Ve,Se){if(X===rs){D===!0&&(Mt(o.BLEND),D=!1);return}if(D===!1&&(st(o.BLEND),D=!0),X!==QM){if(X!==S||Se!==C){if((v!==ks||N!==ks)&&(o.blendEquation(o.FUNC_ADD),v=ks,N=ks),Se)switch(X){case to:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case cv:o.blendFunc(o.ONE,o.ONE);break;case uv:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case fv:o.blendFuncSeparate(o.DST_COLOR,o.ONE_MINUS_SRC_ALPHA,o.ZERO,o.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}else switch(X){case to:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case cv:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE,o.ONE,o.ONE);break;case uv:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case fv:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}L=null,z=null,H=null,F=null,P.set(0,0,0),k=0,S=X,C=Se}return}St=St||At,_t=_t||Dt,Yt=Yt||Vt,(At!==v||St!==N)&&(o.blendEquationSeparate(qt[At],qt[St]),v=At,N=St),(Dt!==L||Vt!==z||_t!==H||Yt!==F)&&(o.blendFuncSeparate(I[Dt],I[Vt],I[_t],I[Yt]),L=Dt,z=Vt,H=_t,F=Yt),(ce.equals(P)===!1||Ve!==k)&&(o.blendColor(ce.r,ce.g,ce.b,Ve),P.copy(ce),k=Ve),S=X,C=!1}function se(X,At){X.side===Ma?Mt(o.CULL_FACE):st(o.CULL_FACE);let Dt=X.side===Kn;At&&(Dt=!Dt),Qt(Dt),X.blending===to&&X.transparent===!1?Ge(rs):Ge(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),h.setFunc(X.depthFunc),h.setTest(X.depthTest),h.setMask(X.depthWrite),f.setMask(X.colorWrite);const Vt=X.stencilWrite;d.setTest(Vt),Vt&&(d.setMask(X.stencilWriteMask),d.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),d.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),Ft(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?st(o.SAMPLE_ALPHA_TO_COVERAGE):Mt(o.SAMPLE_ALPHA_TO_COVERAGE)}function Qt(X){w!==X&&(X?o.frontFace(o.CW):o.frontFace(o.CCW),w=X)}function Lt(X){X!==WM?(st(o.CULL_FACE),X!==G&&(X===lv?o.cullFace(o.BACK):X===ZM?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):Mt(o.CULL_FACE),G=X}function ie(X){X!==it&&(W&&o.lineWidth(X),it=X)}function Ft(X,At,Dt){X?(st(o.POLYGON_OFFSET_FILL),(ct!==At||gt!==Dt)&&(o.polygonOffset(At,Dt),ct=At,gt=Dt)):Mt(o.POLYGON_OFFSET_FILL)}function oe(X){X?st(o.SCISSOR_TEST):Mt(o.SCISSOR_TEST)}function qe(X){X===void 0&&(X=o.TEXTURE0+ut-1),vt!==X&&(o.activeTexture(X),vt=X)}function We(X,At,Dt){Dt===void 0&&(vt===null?Dt=o.TEXTURE0+ut-1:Dt=vt);let Vt=yt[Dt];Vt===void 0&&(Vt={type:void 0,texture:void 0},yt[Dt]=Vt),(Vt.type!==X||Vt.texture!==At)&&(vt!==Dt&&(o.activeTexture(Dt),vt=Dt),o.bindTexture(X,At||$[X]),Vt.type=X,Vt.texture=At)}function U(){const X=yt[vt];X!==void 0&&X.type!==void 0&&(o.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function T(){try{o.compressedTexImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function nt(){try{o.compressedTexImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function pt(){try{o.texSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function xt(){try{o.texSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function ht(){try{o.compressedTexSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function kt(){try{o.compressedTexSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Ct(){try{o.texStorage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Wt(){try{o.texStorage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Kt(){try{o.texImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function bt(){try{o.texImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Ot(X){Ae.equals(X)===!1&&(o.scissor(X.x,X.y,X.z,X.w),Ae.copy(X))}function ne(X){B.equals(X)===!1&&(o.viewport(X.x,X.y,X.z,X.w),B.copy(X))}function Zt(X,At){let Dt=m.get(At);Dt===void 0&&(Dt=new WeakMap,m.set(At,Dt));let Vt=Dt.get(X);Vt===void 0&&(Vt=o.getUniformBlockIndex(At,X.name),Dt.set(X,Vt))}function zt(X,At){const Vt=m.get(At).get(X);_.get(At)!==Vt&&(o.uniformBlockBinding(At,Vt,X.__bindingPointIndex),_.set(At,Vt))}function ue(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),h.setReversed(!1),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),x={},vt=null,yt={},p={},y=new WeakMap,M=[],b=null,D=!1,S=null,v=null,L=null,z=null,N=null,H=null,F=null,P=new Te(0,0,0),k=0,C=!1,w=null,G=null,it=null,ct=null,gt=null,Ae.set(0,0,o.canvas.width,o.canvas.height),B.set(0,0,o.canvas.width,o.canvas.height),f.reset(),h.reset(),d.reset()}return{buffers:{color:f,depth:h,stencil:d},enable:st,disable:Mt,bindFramebuffer:Ut,drawBuffers:Rt,useProgram:Et,setBlending:Ge,setMaterial:se,setFlipSided:Qt,setCullFace:Lt,setLineWidth:ie,setPolygonOffset:Ft,setScissorTest:oe,activeTexture:qe,bindTexture:We,unbindTexture:U,compressedTexImage2D:T,compressedTexImage3D:nt,texImage2D:Kt,texImage3D:bt,updateUBOMapping:Zt,uniformBlockBinding:zt,texStorage2D:Ct,texStorage3D:Wt,texSubImage2D:pt,texSubImage3D:xt,compressedTexSubImage2D:ht,compressedTexSubImage3D:kt,scissor:Ot,viewport:ne,reset:ue}}function k2(o,e,a,r,c,f,h){const d=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,_=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),m=new Ue,x=new WeakMap;let p;const y=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function b(U,T){return M?new OffscreenCanvas(U,T):Su("canvas")}function D(U,T,nt){let pt=1;const xt=We(U);if((xt.width>nt||xt.height>nt)&&(pt=nt/Math.max(xt.width,xt.height)),pt<1)if(typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&U instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&U instanceof ImageBitmap||typeof VideoFrame<"u"&&U instanceof VideoFrame){const ht=Math.floor(pt*xt.width),kt=Math.floor(pt*xt.height);p===void 0&&(p=b(ht,kt));const Ct=T?b(ht,kt):p;return Ct.width=ht,Ct.height=kt,Ct.getContext("2d").drawImage(U,0,0,ht,kt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+xt.width+"x"+xt.height+") to ("+ht+"x"+kt+")."),Ct}else return"data"in U&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+xt.width+"x"+xt.height+")."),U;return U}function S(U){return U.generateMipmaps}function v(U){o.generateMipmap(U)}function L(U){return U.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:U.isWebGL3DRenderTarget?o.TEXTURE_3D:U.isWebGLArrayRenderTarget||U.isCompressedArrayTexture?o.TEXTURE_2D_ARRAY:o.TEXTURE_2D}function z(U,T,nt,pt,xt=!1){if(U!==null){if(o[U]!==void 0)return o[U];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+U+"'")}let ht=T;if(T===o.RED&&(nt===o.FLOAT&&(ht=o.R32F),nt===o.HALF_FLOAT&&(ht=o.R16F),nt===o.UNSIGNED_BYTE&&(ht=o.R8)),T===o.RED_INTEGER&&(nt===o.UNSIGNED_BYTE&&(ht=o.R8UI),nt===o.UNSIGNED_SHORT&&(ht=o.R16UI),nt===o.UNSIGNED_INT&&(ht=o.R32UI),nt===o.BYTE&&(ht=o.R8I),nt===o.SHORT&&(ht=o.R16I),nt===o.INT&&(ht=o.R32I)),T===o.RG&&(nt===o.FLOAT&&(ht=o.RG32F),nt===o.HALF_FLOAT&&(ht=o.RG16F),nt===o.UNSIGNED_BYTE&&(ht=o.RG8)),T===o.RG_INTEGER&&(nt===o.UNSIGNED_BYTE&&(ht=o.RG8UI),nt===o.UNSIGNED_SHORT&&(ht=o.RG16UI),nt===o.UNSIGNED_INT&&(ht=o.RG32UI),nt===o.BYTE&&(ht=o.RG8I),nt===o.SHORT&&(ht=o.RG16I),nt===o.INT&&(ht=o.RG32I)),T===o.RGB_INTEGER&&(nt===o.UNSIGNED_BYTE&&(ht=o.RGB8UI),nt===o.UNSIGNED_SHORT&&(ht=o.RGB16UI),nt===o.UNSIGNED_INT&&(ht=o.RGB32UI),nt===o.BYTE&&(ht=o.RGB8I),nt===o.SHORT&&(ht=o.RGB16I),nt===o.INT&&(ht=o.RGB32I)),T===o.RGBA_INTEGER&&(nt===o.UNSIGNED_BYTE&&(ht=o.RGBA8UI),nt===o.UNSIGNED_SHORT&&(ht=o.RGBA16UI),nt===o.UNSIGNED_INT&&(ht=o.RGBA32UI),nt===o.BYTE&&(ht=o.RGBA8I),nt===o.SHORT&&(ht=o.RGBA16I),nt===o.INT&&(ht=o.RGBA32I)),T===o.RGB&&(nt===o.UNSIGNED_INT_5_9_9_9_REV&&(ht=o.RGB9_E5),nt===o.UNSIGNED_INT_10F_11F_11F_REV&&(ht=o.R11F_G11F_B10F)),T===o.RGBA){const kt=xt?xu:Ne.getTransfer(pt);nt===o.FLOAT&&(ht=o.RGBA32F),nt===o.HALF_FLOAT&&(ht=o.RGBA16F),nt===o.UNSIGNED_BYTE&&(ht=kt===Xe?o.SRGB8_ALPHA8:o.RGBA8),nt===o.UNSIGNED_SHORT_4_4_4_4&&(ht=o.RGBA4),nt===o.UNSIGNED_SHORT_5_5_5_1&&(ht=o.RGB5_A1)}return(ht===o.R16F||ht===o.R32F||ht===o.RG16F||ht===o.RG32F||ht===o.RGBA16F||ht===o.RGBA32F)&&e.get("EXT_color_buffer_float"),ht}function N(U,T){let nt;return U?T===null||T===Zs||T===hl?nt=o.DEPTH24_STENCIL8:T===Ea?nt=o.DEPTH32F_STENCIL8:T===fl&&(nt=o.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===Zs||T===hl?nt=o.DEPTH_COMPONENT24:T===Ea?nt=o.DEPTH_COMPONENT32F:T===fl&&(nt=o.DEPTH_COMPONENT16),nt}function H(U,T){return S(U)===!0||U.isFramebufferTexture&&U.minFilter!==Oi&&U.minFilter!==Ki?Math.log2(Math.max(T.width,T.height))+1:U.mipmaps!==void 0&&U.mipmaps.length>0?U.mipmaps.length:U.isCompressedTexture&&Array.isArray(U.image)?T.mipmaps.length:1}function F(U){const T=U.target;T.removeEventListener("dispose",F),k(T),T.isVideoTexture&&x.delete(T)}function P(U){const T=U.target;T.removeEventListener("dispose",P),w(T)}function k(U){const T=r.get(U);if(T.__webglInit===void 0)return;const nt=U.source,pt=y.get(nt);if(pt){const xt=pt[T.__cacheKey];xt.usedTimes--,xt.usedTimes===0&&C(U),Object.keys(pt).length===0&&y.delete(nt)}r.remove(U)}function C(U){const T=r.get(U);o.deleteTexture(T.__webglTexture);const nt=U.source,pt=y.get(nt);delete pt[T.__cacheKey],h.memory.textures--}function w(U){const T=r.get(U);if(U.depthTexture&&(U.depthTexture.dispose(),r.remove(U.depthTexture)),U.isWebGLCubeRenderTarget)for(let pt=0;pt<6;pt++){if(Array.isArray(T.__webglFramebuffer[pt]))for(let xt=0;xt<T.__webglFramebuffer[pt].length;xt++)o.deleteFramebuffer(T.__webglFramebuffer[pt][xt]);else o.deleteFramebuffer(T.__webglFramebuffer[pt]);T.__webglDepthbuffer&&o.deleteRenderbuffer(T.__webglDepthbuffer[pt])}else{if(Array.isArray(T.__webglFramebuffer))for(let pt=0;pt<T.__webglFramebuffer.length;pt++)o.deleteFramebuffer(T.__webglFramebuffer[pt]);else o.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&o.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&o.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let pt=0;pt<T.__webglColorRenderbuffer.length;pt++)T.__webglColorRenderbuffer[pt]&&o.deleteRenderbuffer(T.__webglColorRenderbuffer[pt]);T.__webglDepthRenderbuffer&&o.deleteRenderbuffer(T.__webglDepthRenderbuffer)}const nt=U.textures;for(let pt=0,xt=nt.length;pt<xt;pt++){const ht=r.get(nt[pt]);ht.__webglTexture&&(o.deleteTexture(ht.__webglTexture),h.memory.textures--),r.remove(nt[pt])}r.remove(U)}let G=0;function it(){G=0}function ct(){const U=G;return U>=c.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+U+" texture units while this GPU supports only "+c.maxTextures),G+=1,U}function gt(U){const T=[];return T.push(U.wrapS),T.push(U.wrapT),T.push(U.wrapR||0),T.push(U.magFilter),T.push(U.minFilter),T.push(U.anisotropy),T.push(U.internalFormat),T.push(U.format),T.push(U.type),T.push(U.generateMipmaps),T.push(U.premultiplyAlpha),T.push(U.flipY),T.push(U.unpackAlignment),T.push(U.colorSpace),T.join()}function ut(U,T){const nt=r.get(U);if(U.isVideoTexture&&oe(U),U.isRenderTargetTexture===!1&&U.isExternalTexture!==!0&&U.version>0&&nt.__version!==U.version){const pt=U.image;if(pt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(pt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{$(nt,U,T);return}}else U.isExternalTexture&&(nt.__webglTexture=U.sourceTexture?U.sourceTexture:null);a.bindTexture(o.TEXTURE_2D,nt.__webglTexture,o.TEXTURE0+T)}function W(U,T){const nt=r.get(U);if(U.isRenderTargetTexture===!1&&U.version>0&&nt.__version!==U.version){$(nt,U,T);return}a.bindTexture(o.TEXTURE_2D_ARRAY,nt.__webglTexture,o.TEXTURE0+T)}function rt(U,T){const nt=r.get(U);if(U.isRenderTargetTexture===!1&&U.version>0&&nt.__version!==U.version){$(nt,U,T);return}a.bindTexture(o.TEXTURE_3D,nt.__webglTexture,o.TEXTURE0+T)}function K(U,T){const nt=r.get(U);if(U.version>0&&nt.__version!==U.version){st(nt,U,T);return}a.bindTexture(o.TEXTURE_CUBE_MAP,nt.__webglTexture,o.TEXTURE0+T)}const vt={[Jd]:o.REPEAT,[js]:o.CLAMP_TO_EDGE,[$d]:o.MIRRORED_REPEAT},yt={[Oi]:o.NEAREST,[EE]:o.NEAREST_MIPMAP_NEAREST,[Xc]:o.NEAREST_MIPMAP_LINEAR,[Ki]:o.LINEAR,[ld]:o.LINEAR_MIPMAP_NEAREST,[qs]:o.LINEAR_MIPMAP_LINEAR},Gt={[RE]:o.NEVER,[LE]:o.ALWAYS,[CE]:o.LESS,[Tx]:o.LEQUAL,[wE]:o.EQUAL,[UE]:o.GEQUAL,[DE]:o.GREATER,[NE]:o.NOTEQUAL};function re(U,T){if(T.type===Ea&&e.has("OES_texture_float_linear")===!1&&(T.magFilter===Ki||T.magFilter===ld||T.magFilter===Xc||T.magFilter===qs||T.minFilter===Ki||T.minFilter===ld||T.minFilter===Xc||T.minFilter===qs)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),o.texParameteri(U,o.TEXTURE_WRAP_S,vt[T.wrapS]),o.texParameteri(U,o.TEXTURE_WRAP_T,vt[T.wrapT]),(U===o.TEXTURE_3D||U===o.TEXTURE_2D_ARRAY)&&o.texParameteri(U,o.TEXTURE_WRAP_R,vt[T.wrapR]),o.texParameteri(U,o.TEXTURE_MAG_FILTER,yt[T.magFilter]),o.texParameteri(U,o.TEXTURE_MIN_FILTER,yt[T.minFilter]),T.compareFunction&&(o.texParameteri(U,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(U,o.TEXTURE_COMPARE_FUNC,Gt[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===Oi||T.minFilter!==Xc&&T.minFilter!==qs||T.type===Ea&&e.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||r.get(T).__currentAnisotropy){const nt=e.get("EXT_texture_filter_anisotropic");o.texParameterf(U,nt.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,c.getMaxAnisotropy())),r.get(T).__currentAnisotropy=T.anisotropy}}}function Ae(U,T){let nt=!1;U.__webglInit===void 0&&(U.__webglInit=!0,T.addEventListener("dispose",F));const pt=T.source;let xt=y.get(pt);xt===void 0&&(xt={},y.set(pt,xt));const ht=gt(T);if(ht!==U.__cacheKey){xt[ht]===void 0&&(xt[ht]={texture:o.createTexture(),usedTimes:0},h.memory.textures++,nt=!0),xt[ht].usedTimes++;const kt=xt[U.__cacheKey];kt!==void 0&&(xt[U.__cacheKey].usedTimes--,kt.usedTimes===0&&C(T)),U.__cacheKey=ht,U.__webglTexture=xt[ht].texture}return nt}function B(U,T,nt){return Math.floor(Math.floor(U/nt)/T)}function ft(U,T,nt,pt){const ht=U.updateRanges;if(ht.length===0)a.texSubImage2D(o.TEXTURE_2D,0,0,0,T.width,T.height,nt,pt,T.data);else{ht.sort((bt,Ot)=>bt.start-Ot.start);let kt=0;for(let bt=1;bt<ht.length;bt++){const Ot=ht[kt],ne=ht[bt],Zt=Ot.start+Ot.count,zt=B(ne.start,T.width,4),ue=B(Ot.start,T.width,4);ne.start<=Zt+1&&zt===ue&&B(ne.start+ne.count-1,T.width,4)===zt?Ot.count=Math.max(Ot.count,ne.start+ne.count-Ot.start):(++kt,ht[kt]=ne)}ht.length=kt+1;const Ct=o.getParameter(o.UNPACK_ROW_LENGTH),Wt=o.getParameter(o.UNPACK_SKIP_PIXELS),Kt=o.getParameter(o.UNPACK_SKIP_ROWS);o.pixelStorei(o.UNPACK_ROW_LENGTH,T.width);for(let bt=0,Ot=ht.length;bt<Ot;bt++){const ne=ht[bt],Zt=Math.floor(ne.start/4),zt=Math.ceil(ne.count/4),ue=Zt%T.width,X=Math.floor(Zt/T.width),At=zt,Dt=1;o.pixelStorei(o.UNPACK_SKIP_PIXELS,ue),o.pixelStorei(o.UNPACK_SKIP_ROWS,X),a.texSubImage2D(o.TEXTURE_2D,0,ue,X,At,Dt,nt,pt,T.data)}U.clearUpdateRanges(),o.pixelStorei(o.UNPACK_ROW_LENGTH,Ct),o.pixelStorei(o.UNPACK_SKIP_PIXELS,Wt),o.pixelStorei(o.UNPACK_SKIP_ROWS,Kt)}}function $(U,T,nt){let pt=o.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(pt=o.TEXTURE_2D_ARRAY),T.isData3DTexture&&(pt=o.TEXTURE_3D);const xt=Ae(U,T),ht=T.source;a.bindTexture(pt,U.__webglTexture,o.TEXTURE0+nt);const kt=r.get(ht);if(ht.version!==kt.__version||xt===!0){a.activeTexture(o.TEXTURE0+nt);const Ct=Ne.getPrimaries(Ne.workingColorSpace),Wt=T.colorSpace===ss?null:Ne.getPrimaries(T.colorSpace),Kt=T.colorSpace===ss||Ct===Wt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,T.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,T.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Kt);let bt=D(T.image,!1,c.maxTextureSize);bt=qe(T,bt);const Ot=f.convert(T.format,T.colorSpace),ne=f.convert(T.type);let Zt=z(T.internalFormat,Ot,ne,T.colorSpace,T.isVideoTexture);re(pt,T);let zt;const ue=T.mipmaps,X=T.isVideoTexture!==!0,At=kt.__version===void 0||xt===!0,Dt=ht.dataReady,Vt=H(T,bt);if(T.isDepthTexture)Zt=N(T.format===pl,T.type),At&&(X?a.texStorage2D(o.TEXTURE_2D,1,Zt,bt.width,bt.height):a.texImage2D(o.TEXTURE_2D,0,Zt,bt.width,bt.height,0,Ot,ne,null));else if(T.isDataTexture)if(ue.length>0){X&&At&&a.texStorage2D(o.TEXTURE_2D,Vt,Zt,ue[0].width,ue[0].height);for(let St=0,_t=ue.length;St<_t;St++)zt=ue[St],X?Dt&&a.texSubImage2D(o.TEXTURE_2D,St,0,0,zt.width,zt.height,Ot,ne,zt.data):a.texImage2D(o.TEXTURE_2D,St,Zt,zt.width,zt.height,0,Ot,ne,zt.data);T.generateMipmaps=!1}else X?(At&&a.texStorage2D(o.TEXTURE_2D,Vt,Zt,bt.width,bt.height),Dt&&ft(T,bt,Ot,ne)):a.texImage2D(o.TEXTURE_2D,0,Zt,bt.width,bt.height,0,Ot,ne,bt.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){X&&At&&a.texStorage3D(o.TEXTURE_2D_ARRAY,Vt,Zt,ue[0].width,ue[0].height,bt.depth);for(let St=0,_t=ue.length;St<_t;St++)if(zt=ue[St],T.format!==Li)if(Ot!==null)if(X){if(Dt)if(T.layerUpdates.size>0){const Yt=Iv(zt.width,zt.height,T.format,T.type);for(const ce of T.layerUpdates){const Ve=zt.data.subarray(ce*Yt/zt.data.BYTES_PER_ELEMENT,(ce+1)*Yt/zt.data.BYTES_PER_ELEMENT);a.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,St,0,0,ce,zt.width,zt.height,1,Ot,Ve)}T.clearLayerUpdates()}else a.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,St,0,0,0,zt.width,zt.height,bt.depth,Ot,zt.data)}else a.compressedTexImage3D(o.TEXTURE_2D_ARRAY,St,Zt,zt.width,zt.height,bt.depth,0,zt.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else X?Dt&&a.texSubImage3D(o.TEXTURE_2D_ARRAY,St,0,0,0,zt.width,zt.height,bt.depth,Ot,ne,zt.data):a.texImage3D(o.TEXTURE_2D_ARRAY,St,Zt,zt.width,zt.height,bt.depth,0,Ot,ne,zt.data)}else{X&&At&&a.texStorage2D(o.TEXTURE_2D,Vt,Zt,ue[0].width,ue[0].height);for(let St=0,_t=ue.length;St<_t;St++)zt=ue[St],T.format!==Li?Ot!==null?X?Dt&&a.compressedTexSubImage2D(o.TEXTURE_2D,St,0,0,zt.width,zt.height,Ot,zt.data):a.compressedTexImage2D(o.TEXTURE_2D,St,Zt,zt.width,zt.height,0,zt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):X?Dt&&a.texSubImage2D(o.TEXTURE_2D,St,0,0,zt.width,zt.height,Ot,ne,zt.data):a.texImage2D(o.TEXTURE_2D,St,Zt,zt.width,zt.height,0,Ot,ne,zt.data)}else if(T.isDataArrayTexture)if(X){if(At&&a.texStorage3D(o.TEXTURE_2D_ARRAY,Vt,Zt,bt.width,bt.height,bt.depth),Dt)if(T.layerUpdates.size>0){const St=Iv(bt.width,bt.height,T.format,T.type);for(const _t of T.layerUpdates){const Yt=bt.data.subarray(_t*St/bt.data.BYTES_PER_ELEMENT,(_t+1)*St/bt.data.BYTES_PER_ELEMENT);a.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,_t,bt.width,bt.height,1,Ot,ne,Yt)}T.clearLayerUpdates()}else a.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,bt.width,bt.height,bt.depth,Ot,ne,bt.data)}else a.texImage3D(o.TEXTURE_2D_ARRAY,0,Zt,bt.width,bt.height,bt.depth,0,Ot,ne,bt.data);else if(T.isData3DTexture)X?(At&&a.texStorage3D(o.TEXTURE_3D,Vt,Zt,bt.width,bt.height,bt.depth),Dt&&a.texSubImage3D(o.TEXTURE_3D,0,0,0,0,bt.width,bt.height,bt.depth,Ot,ne,bt.data)):a.texImage3D(o.TEXTURE_3D,0,Zt,bt.width,bt.height,bt.depth,0,Ot,ne,bt.data);else if(T.isFramebufferTexture){if(At)if(X)a.texStorage2D(o.TEXTURE_2D,Vt,Zt,bt.width,bt.height);else{let St=bt.width,_t=bt.height;for(let Yt=0;Yt<Vt;Yt++)a.texImage2D(o.TEXTURE_2D,Yt,Zt,St,_t,0,Ot,ne,null),St>>=1,_t>>=1}}else if(ue.length>0){if(X&&At){const St=We(ue[0]);a.texStorage2D(o.TEXTURE_2D,Vt,Zt,St.width,St.height)}for(let St=0,_t=ue.length;St<_t;St++)zt=ue[St],X?Dt&&a.texSubImage2D(o.TEXTURE_2D,St,0,0,Ot,ne,zt):a.texImage2D(o.TEXTURE_2D,St,Zt,Ot,ne,zt);T.generateMipmaps=!1}else if(X){if(At){const St=We(bt);a.texStorage2D(o.TEXTURE_2D,Vt,Zt,St.width,St.height)}Dt&&a.texSubImage2D(o.TEXTURE_2D,0,0,0,Ot,ne,bt)}else a.texImage2D(o.TEXTURE_2D,0,Zt,Ot,ne,bt);S(T)&&v(pt),kt.__version=ht.version,T.onUpdate&&T.onUpdate(T)}U.__version=T.version}function st(U,T,nt){if(T.image.length!==6)return;const pt=Ae(U,T),xt=T.source;a.bindTexture(o.TEXTURE_CUBE_MAP,U.__webglTexture,o.TEXTURE0+nt);const ht=r.get(xt);if(xt.version!==ht.__version||pt===!0){a.activeTexture(o.TEXTURE0+nt);const kt=Ne.getPrimaries(Ne.workingColorSpace),Ct=T.colorSpace===ss?null:Ne.getPrimaries(T.colorSpace),Wt=T.colorSpace===ss||kt===Ct?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,T.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,T.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Wt);const Kt=T.isCompressedTexture||T.image[0].isCompressedTexture,bt=T.image[0]&&T.image[0].isDataTexture,Ot=[];for(let _t=0;_t<6;_t++)!Kt&&!bt?Ot[_t]=D(T.image[_t],!0,c.maxCubemapSize):Ot[_t]=bt?T.image[_t].image:T.image[_t],Ot[_t]=qe(T,Ot[_t]);const ne=Ot[0],Zt=f.convert(T.format,T.colorSpace),zt=f.convert(T.type),ue=z(T.internalFormat,Zt,zt,T.colorSpace),X=T.isVideoTexture!==!0,At=ht.__version===void 0||pt===!0,Dt=xt.dataReady;let Vt=H(T,ne);re(o.TEXTURE_CUBE_MAP,T);let St;if(Kt){X&&At&&a.texStorage2D(o.TEXTURE_CUBE_MAP,Vt,ue,ne.width,ne.height);for(let _t=0;_t<6;_t++){St=Ot[_t].mipmaps;for(let Yt=0;Yt<St.length;Yt++){const ce=St[Yt];T.format!==Li?Zt!==null?X?Dt&&a.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt,0,0,ce.width,ce.height,Zt,ce.data):a.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt,ue,ce.width,ce.height,0,ce.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):X?Dt&&a.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt,0,0,ce.width,ce.height,Zt,zt,ce.data):a.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt,ue,ce.width,ce.height,0,Zt,zt,ce.data)}}}else{if(St=T.mipmaps,X&&At){St.length>0&&Vt++;const _t=We(Ot[0]);a.texStorage2D(o.TEXTURE_CUBE_MAP,Vt,ue,_t.width,_t.height)}for(let _t=0;_t<6;_t++)if(bt){X?Dt&&a.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,Ot[_t].width,Ot[_t].height,Zt,zt,Ot[_t].data):a.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,ue,Ot[_t].width,Ot[_t].height,0,Zt,zt,Ot[_t].data);for(let Yt=0;Yt<St.length;Yt++){const Ve=St[Yt].image[_t].image;X?Dt&&a.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt+1,0,0,Ve.width,Ve.height,Zt,zt,Ve.data):a.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt+1,ue,Ve.width,Ve.height,0,Zt,zt,Ve.data)}}else{X?Dt&&a.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,0,0,Zt,zt,Ot[_t]):a.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,0,ue,Zt,zt,Ot[_t]);for(let Yt=0;Yt<St.length;Yt++){const ce=St[Yt];X?Dt&&a.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt+1,0,0,Zt,zt,ce.image[_t]):a.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+_t,Yt+1,ue,Zt,zt,ce.image[_t])}}}S(T)&&v(o.TEXTURE_CUBE_MAP),ht.__version=xt.version,T.onUpdate&&T.onUpdate(T)}U.__version=T.version}function Mt(U,T,nt,pt,xt,ht){const kt=f.convert(nt.format,nt.colorSpace),Ct=f.convert(nt.type),Wt=z(nt.internalFormat,kt,Ct,nt.colorSpace),Kt=r.get(T),bt=r.get(nt);if(bt.__renderTarget=T,!Kt.__hasExternalTextures){const Ot=Math.max(1,T.width>>ht),ne=Math.max(1,T.height>>ht);xt===o.TEXTURE_3D||xt===o.TEXTURE_2D_ARRAY?a.texImage3D(xt,ht,Wt,Ot,ne,T.depth,0,kt,Ct,null):a.texImage2D(xt,ht,Wt,Ot,ne,0,kt,Ct,null)}a.bindFramebuffer(o.FRAMEBUFFER,U),Ft(T)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,pt,xt,bt.__webglTexture,0,ie(T)):(xt===o.TEXTURE_2D||xt>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&xt<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,pt,xt,bt.__webglTexture,ht),a.bindFramebuffer(o.FRAMEBUFFER,null)}function Ut(U,T,nt){if(o.bindRenderbuffer(o.RENDERBUFFER,U),T.depthBuffer){const pt=T.depthTexture,xt=pt&&pt.isDepthTexture?pt.type:null,ht=N(T.stencilBuffer,xt),kt=T.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Ct=ie(T);Ft(T)?d.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,Ct,ht,T.width,T.height):nt?o.renderbufferStorageMultisample(o.RENDERBUFFER,Ct,ht,T.width,T.height):o.renderbufferStorage(o.RENDERBUFFER,ht,T.width,T.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,kt,o.RENDERBUFFER,U)}else{const pt=T.textures;for(let xt=0;xt<pt.length;xt++){const ht=pt[xt],kt=f.convert(ht.format,ht.colorSpace),Ct=f.convert(ht.type),Wt=z(ht.internalFormat,kt,Ct,ht.colorSpace),Kt=ie(T);nt&&Ft(T)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,Kt,Wt,T.width,T.height):Ft(T)?d.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,Kt,Wt,T.width,T.height):o.renderbufferStorage(o.RENDERBUFFER,Wt,T.width,T.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function Rt(U,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(a.bindFramebuffer(o.FRAMEBUFFER,U),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const pt=r.get(T.depthTexture);pt.__renderTarget=T,(!pt.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),ut(T.depthTexture,0);const xt=pt.__webglTexture,ht=ie(T);if(T.depthTexture.format===dl)Ft(T)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,xt,0,ht):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,xt,0);else if(T.depthTexture.format===pl)Ft(T)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,xt,0,ht):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,xt,0);else throw new Error("Unknown depthTexture format")}function Et(U){const T=r.get(U),nt=U.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==U.depthTexture){const pt=U.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),pt){const xt=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,pt.removeEventListener("dispose",xt)};pt.addEventListener("dispose",xt),T.__depthDisposeCallback=xt}T.__boundDepthTexture=pt}if(U.depthTexture&&!T.__autoAllocateDepthBuffer){if(nt)throw new Error("target.depthTexture not supported in Cube render targets");const pt=U.texture.mipmaps;pt&&pt.length>0?Rt(T.__webglFramebuffer[0],U):Rt(T.__webglFramebuffer,U)}else if(nt){T.__webglDepthbuffer=[];for(let pt=0;pt<6;pt++)if(a.bindFramebuffer(o.FRAMEBUFFER,T.__webglFramebuffer[pt]),T.__webglDepthbuffer[pt]===void 0)T.__webglDepthbuffer[pt]=o.createRenderbuffer(),Ut(T.__webglDepthbuffer[pt],U,!1);else{const xt=U.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,ht=T.__webglDepthbuffer[pt];o.bindRenderbuffer(o.RENDERBUFFER,ht),o.framebufferRenderbuffer(o.FRAMEBUFFER,xt,o.RENDERBUFFER,ht)}}else{const pt=U.texture.mipmaps;if(pt&&pt.length>0?a.bindFramebuffer(o.FRAMEBUFFER,T.__webglFramebuffer[0]):a.bindFramebuffer(o.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=o.createRenderbuffer(),Ut(T.__webglDepthbuffer,U,!1);else{const xt=U.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,ht=T.__webglDepthbuffer;o.bindRenderbuffer(o.RENDERBUFFER,ht),o.framebufferRenderbuffer(o.FRAMEBUFFER,xt,o.RENDERBUFFER,ht)}}a.bindFramebuffer(o.FRAMEBUFFER,null)}function qt(U,T,nt){const pt=r.get(U);T!==void 0&&Mt(pt.__webglFramebuffer,U,U.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),nt!==void 0&&Et(U)}function I(U){const T=U.texture,nt=r.get(U),pt=r.get(T);U.addEventListener("dispose",P);const xt=U.textures,ht=U.isWebGLCubeRenderTarget===!0,kt=xt.length>1;if(kt||(pt.__webglTexture===void 0&&(pt.__webglTexture=o.createTexture()),pt.__version=T.version,h.memory.textures++),ht){nt.__webglFramebuffer=[];for(let Ct=0;Ct<6;Ct++)if(T.mipmaps&&T.mipmaps.length>0){nt.__webglFramebuffer[Ct]=[];for(let Wt=0;Wt<T.mipmaps.length;Wt++)nt.__webglFramebuffer[Ct][Wt]=o.createFramebuffer()}else nt.__webglFramebuffer[Ct]=o.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){nt.__webglFramebuffer=[];for(let Ct=0;Ct<T.mipmaps.length;Ct++)nt.__webglFramebuffer[Ct]=o.createFramebuffer()}else nt.__webglFramebuffer=o.createFramebuffer();if(kt)for(let Ct=0,Wt=xt.length;Ct<Wt;Ct++){const Kt=r.get(xt[Ct]);Kt.__webglTexture===void 0&&(Kt.__webglTexture=o.createTexture(),h.memory.textures++)}if(U.samples>0&&Ft(U)===!1){nt.__webglMultisampledFramebuffer=o.createFramebuffer(),nt.__webglColorRenderbuffer=[],a.bindFramebuffer(o.FRAMEBUFFER,nt.__webglMultisampledFramebuffer);for(let Ct=0;Ct<xt.length;Ct++){const Wt=xt[Ct];nt.__webglColorRenderbuffer[Ct]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,nt.__webglColorRenderbuffer[Ct]);const Kt=f.convert(Wt.format,Wt.colorSpace),bt=f.convert(Wt.type),Ot=z(Wt.internalFormat,Kt,bt,Wt.colorSpace,U.isXRRenderTarget===!0),ne=ie(U);o.renderbufferStorageMultisample(o.RENDERBUFFER,ne,Ot,U.width,U.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ct,o.RENDERBUFFER,nt.__webglColorRenderbuffer[Ct])}o.bindRenderbuffer(o.RENDERBUFFER,null),U.depthBuffer&&(nt.__webglDepthRenderbuffer=o.createRenderbuffer(),Ut(nt.__webglDepthRenderbuffer,U,!0)),a.bindFramebuffer(o.FRAMEBUFFER,null)}}if(ht){a.bindTexture(o.TEXTURE_CUBE_MAP,pt.__webglTexture),re(o.TEXTURE_CUBE_MAP,T);for(let Ct=0;Ct<6;Ct++)if(T.mipmaps&&T.mipmaps.length>0)for(let Wt=0;Wt<T.mipmaps.length;Wt++)Mt(nt.__webglFramebuffer[Ct][Wt],U,T,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+Ct,Wt);else Mt(nt.__webglFramebuffer[Ct],U,T,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+Ct,0);S(T)&&v(o.TEXTURE_CUBE_MAP),a.unbindTexture()}else if(kt){for(let Ct=0,Wt=xt.length;Ct<Wt;Ct++){const Kt=xt[Ct],bt=r.get(Kt);let Ot=o.TEXTURE_2D;(U.isWebGL3DRenderTarget||U.isWebGLArrayRenderTarget)&&(Ot=U.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),a.bindTexture(Ot,bt.__webglTexture),re(Ot,Kt),Mt(nt.__webglFramebuffer,U,Kt,o.COLOR_ATTACHMENT0+Ct,Ot,0),S(Kt)&&v(Ot)}a.unbindTexture()}else{let Ct=o.TEXTURE_2D;if((U.isWebGL3DRenderTarget||U.isWebGLArrayRenderTarget)&&(Ct=U.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),a.bindTexture(Ct,pt.__webglTexture),re(Ct,T),T.mipmaps&&T.mipmaps.length>0)for(let Wt=0;Wt<T.mipmaps.length;Wt++)Mt(nt.__webglFramebuffer[Wt],U,T,o.COLOR_ATTACHMENT0,Ct,Wt);else Mt(nt.__webglFramebuffer,U,T,o.COLOR_ATTACHMENT0,Ct,0);S(T)&&v(Ct),a.unbindTexture()}U.depthBuffer&&Et(U)}function Ge(U){const T=U.textures;for(let nt=0,pt=T.length;nt<pt;nt++){const xt=T[nt];if(S(xt)){const ht=L(U),kt=r.get(xt).__webglTexture;a.bindTexture(ht,kt),v(ht),a.unbindTexture()}}}const se=[],Qt=[];function Lt(U){if(U.samples>0){if(Ft(U)===!1){const T=U.textures,nt=U.width,pt=U.height;let xt=o.COLOR_BUFFER_BIT;const ht=U.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,kt=r.get(U),Ct=T.length>1;if(Ct)for(let Kt=0;Kt<T.length;Kt++)a.bindFramebuffer(o.FRAMEBUFFER,kt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Kt,o.RENDERBUFFER,null),a.bindFramebuffer(o.FRAMEBUFFER,kt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Kt,o.TEXTURE_2D,null,0);a.bindFramebuffer(o.READ_FRAMEBUFFER,kt.__webglMultisampledFramebuffer);const Wt=U.texture.mipmaps;Wt&&Wt.length>0?a.bindFramebuffer(o.DRAW_FRAMEBUFFER,kt.__webglFramebuffer[0]):a.bindFramebuffer(o.DRAW_FRAMEBUFFER,kt.__webglFramebuffer);for(let Kt=0;Kt<T.length;Kt++){if(U.resolveDepthBuffer&&(U.depthBuffer&&(xt|=o.DEPTH_BUFFER_BIT),U.stencilBuffer&&U.resolveStencilBuffer&&(xt|=o.STENCIL_BUFFER_BIT)),Ct){o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,kt.__webglColorRenderbuffer[Kt]);const bt=r.get(T[Kt]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,bt,0)}o.blitFramebuffer(0,0,nt,pt,0,0,nt,pt,xt,o.NEAREST),_===!0&&(se.length=0,Qt.length=0,se.push(o.COLOR_ATTACHMENT0+Kt),U.depthBuffer&&U.resolveDepthBuffer===!1&&(se.push(ht),Qt.push(ht),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,Qt)),o.invalidateFramebuffer(o.READ_FRAMEBUFFER,se))}if(a.bindFramebuffer(o.READ_FRAMEBUFFER,null),a.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),Ct)for(let Kt=0;Kt<T.length;Kt++){a.bindFramebuffer(o.FRAMEBUFFER,kt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Kt,o.RENDERBUFFER,kt.__webglColorRenderbuffer[Kt]);const bt=r.get(T[Kt]).__webglTexture;a.bindFramebuffer(o.FRAMEBUFFER,kt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Kt,o.TEXTURE_2D,bt,0)}a.bindFramebuffer(o.DRAW_FRAMEBUFFER,kt.__webglMultisampledFramebuffer)}else if(U.depthBuffer&&U.resolveDepthBuffer===!1&&_){const T=U.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[T])}}}function ie(U){return Math.min(c.maxSamples,U.samples)}function Ft(U){const T=r.get(U);return U.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function oe(U){const T=h.render.frame;x.get(U)!==T&&(x.set(U,T),U.update())}function qe(U,T){const nt=U.colorSpace,pt=U.format,xt=U.type;return U.isCompressedTexture===!0||U.isVideoTexture===!0||nt!==so&&nt!==ss&&(Ne.getTransfer(nt)===Xe?(pt!==Li||xt!==Ji)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",nt)),T}function We(U){return typeof HTMLImageElement<"u"&&U instanceof HTMLImageElement?(m.width=U.naturalWidth||U.width,m.height=U.naturalHeight||U.height):typeof VideoFrame<"u"&&U instanceof VideoFrame?(m.width=U.displayWidth,m.height=U.displayHeight):(m.width=U.width,m.height=U.height),m}this.allocateTextureUnit=ct,this.resetTextureUnits=it,this.setTexture2D=ut,this.setTexture2DArray=W,this.setTexture3D=rt,this.setTextureCube=K,this.rebindTextures=qt,this.setupRenderTarget=I,this.updateRenderTargetMipmap=Ge,this.updateMultisampleRenderTarget=Lt,this.setupDepthRenderbuffer=Et,this.setupFrameBufferTexture=Mt,this.useMultisampledRTT=Ft}function X2(o,e){function a(r,c=ss){let f;const h=Ne.getTransfer(c);if(r===Ji)return o.UNSIGNED_BYTE;if(r===Pp)return o.UNSIGNED_SHORT_4_4_4_4;if(r===Ip)return o.UNSIGNED_SHORT_5_5_5_1;if(r===_x)return o.UNSIGNED_INT_5_9_9_9_REV;if(r===vx)return o.UNSIGNED_INT_10F_11F_11F_REV;if(r===mx)return o.BYTE;if(r===gx)return o.SHORT;if(r===fl)return o.UNSIGNED_SHORT;if(r===zp)return o.INT;if(r===Zs)return o.UNSIGNED_INT;if(r===Ea)return o.FLOAT;if(r===_l)return o.HALF_FLOAT;if(r===xx)return o.ALPHA;if(r===yx)return o.RGB;if(r===Li)return o.RGBA;if(r===dl)return o.DEPTH_COMPONENT;if(r===pl)return o.DEPTH_STENCIL;if(r===Sx)return o.RED;if(r===Bp)return o.RED_INTEGER;if(r===Mx)return o.RG;if(r===Fp)return o.RG_INTEGER;if(r===Hp)return o.RGBA_INTEGER;if(r===pu||r===mu||r===gu||r===_u)if(h===Xe)if(f=e.get("WEBGL_compressed_texture_s3tc_srgb"),f!==null){if(r===pu)return f.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===mu)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===gu)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===_u)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(f=e.get("WEBGL_compressed_texture_s3tc"),f!==null){if(r===pu)return f.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===mu)return f.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===gu)return f.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===_u)return f.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===tp||r===ep||r===np||r===ip)if(f=e.get("WEBGL_compressed_texture_pvrtc"),f!==null){if(r===tp)return f.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===ep)return f.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===np)return f.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===ip)return f.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===ap||r===sp||r===rp)if(f=e.get("WEBGL_compressed_texture_etc"),f!==null){if(r===ap||r===sp)return h===Xe?f.COMPRESSED_SRGB8_ETC2:f.COMPRESSED_RGB8_ETC2;if(r===rp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:f.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===op||r===lp||r===cp||r===up||r===fp||r===hp||r===dp||r===pp||r===mp||r===gp||r===_p||r===vp||r===xp||r===yp)if(f=e.get("WEBGL_compressed_texture_astc"),f!==null){if(r===op)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:f.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===lp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:f.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===cp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:f.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===up)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:f.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===fp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:f.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===hp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:f.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===dp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:f.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===pp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:f.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===mp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:f.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===gp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:f.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===_p)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:f.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===vp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:f.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===xp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:f.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===yp)return h===Xe?f.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:f.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===Sp||r===Mp||r===Ep)if(f=e.get("EXT_texture_compression_bptc"),f!==null){if(r===Sp)return h===Xe?f.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:f.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Mp)return f.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Ep)return f.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===Tp||r===bp||r===Ap||r===Rp)if(f=e.get("EXT_texture_compression_rgtc"),f!==null){if(r===Tp)return f.COMPRESSED_RED_RGTC1_EXT;if(r===bp)return f.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Ap)return f.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Rp)return f.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===hl?o.UNSIGNED_INT_24_8:o[r]!==void 0?o[r]:null}return{convert:a}}const j2=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,q2=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Y2{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,a){if(this.texture===null){const r=new Bx(e.texture);(e.depthNear!==a.depthNear||e.depthFar!==a.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const a=e.cameras[0].viewport,r=new us({vertexShader:j2,fragmentShader:q2,uniforms:{depthColor:{value:this.texture},depthWidth:{value:a.z},depthHeight:{value:a.w}}});this.mesh=new tn(new co(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class W2 extends oo{constructor(e,a){super();const r=this;let c=null,f=1,h=null,d="local-floor",_=1,m=null,x=null,p=null,y=null,M=null,b=null;const D=typeof XRWebGLBinding<"u",S=new Y2,v={},L=a.getContextAttributes();let z=null,N=null;const H=[],F=[],P=new Ue;let k=null;const C=new Zn;C.viewport=new je;const w=new Zn;w.viewport=new je;const G=[C,w],it=new m1;let ct=null,gt=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let st=H[$];return st===void 0&&(st=new Nd,H[$]=st),st.getTargetRaySpace()},this.getControllerGrip=function($){let st=H[$];return st===void 0&&(st=new Nd,H[$]=st),st.getGripSpace()},this.getHand=function($){let st=H[$];return st===void 0&&(st=new Nd,H[$]=st),st.getHandSpace()};function ut($){const st=F.indexOf($.inputSource);if(st===-1)return;const Mt=H[st];Mt!==void 0&&(Mt.update($.inputSource,$.frame,m||h),Mt.dispatchEvent({type:$.type,data:$.inputSource}))}function W(){c.removeEventListener("select",ut),c.removeEventListener("selectstart",ut),c.removeEventListener("selectend",ut),c.removeEventListener("squeeze",ut),c.removeEventListener("squeezestart",ut),c.removeEventListener("squeezeend",ut),c.removeEventListener("end",W),c.removeEventListener("inputsourceschange",rt);for(let $=0;$<H.length;$++){const st=F[$];st!==null&&(F[$]=null,H[$].disconnect(st))}ct=null,gt=null,S.reset();for(const $ in v)delete v[$];e.setRenderTarget(z),M=null,y=null,p=null,c=null,N=null,ft.stop(),r.isPresenting=!1,e.setPixelRatio(k),e.setSize(P.width,P.height,!1),r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){f=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){d=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return m||h},this.setReferenceSpace=function($){m=$},this.getBaseLayer=function(){return y!==null?y:M},this.getBinding=function(){return p===null&&D&&(p=new XRWebGLBinding(c,a)),p},this.getFrame=function(){return b},this.getSession=function(){return c},this.setSession=async function($){if(c=$,c!==null){if(z=e.getRenderTarget(),c.addEventListener("select",ut),c.addEventListener("selectstart",ut),c.addEventListener("selectend",ut),c.addEventListener("squeeze",ut),c.addEventListener("squeezestart",ut),c.addEventListener("squeezeend",ut),c.addEventListener("end",W),c.addEventListener("inputsourceschange",rt),L.xrCompatible!==!0&&await a.makeXRCompatible(),k=e.getPixelRatio(),e.getSize(P),D&&"createProjectionLayer"in XRWebGLBinding.prototype){let Mt=null,Ut=null,Rt=null;L.depth&&(Rt=L.stencil?a.DEPTH24_STENCIL8:a.DEPTH_COMPONENT24,Mt=L.stencil?pl:dl,Ut=L.stencil?hl:Zs);const Et={colorFormat:a.RGBA8,depthFormat:Rt,scaleFactor:f};p=this.getBinding(),y=p.createProjectionLayer(Et),c.updateRenderState({layers:[y]}),e.setPixelRatio(1),e.setSize(y.textureWidth,y.textureHeight,!1),N=new Ks(y.textureWidth,y.textureHeight,{format:Li,type:Ji,depthTexture:new Ix(y.textureWidth,y.textureHeight,Ut,void 0,void 0,void 0,void 0,void 0,void 0,Mt),stencilBuffer:L.stencil,colorSpace:e.outputColorSpace,samples:L.antialias?4:0,resolveDepthBuffer:y.ignoreDepthValues===!1,resolveStencilBuffer:y.ignoreDepthValues===!1})}else{const Mt={antialias:L.antialias,alpha:!0,depth:L.depth,stencil:L.stencil,framebufferScaleFactor:f};M=new XRWebGLLayer(c,a,Mt),c.updateRenderState({baseLayer:M}),e.setPixelRatio(1),e.setSize(M.framebufferWidth,M.framebufferHeight,!1),N=new Ks(M.framebufferWidth,M.framebufferHeight,{format:Li,type:Ji,colorSpace:e.outputColorSpace,stencilBuffer:L.stencil,resolveDepthBuffer:M.ignoreDepthValues===!1,resolveStencilBuffer:M.ignoreDepthValues===!1})}N.isXRRenderTarget=!0,this.setFoveation(_),m=null,h=await c.requestReferenceSpace(d),ft.setContext(c),ft.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(c!==null)return c.environmentBlendMode},this.getDepthTexture=function(){return S.getDepthTexture()};function rt($){for(let st=0;st<$.removed.length;st++){const Mt=$.removed[st],Ut=F.indexOf(Mt);Ut>=0&&(F[Ut]=null,H[Ut].disconnect(Mt))}for(let st=0;st<$.added.length;st++){const Mt=$.added[st];let Ut=F.indexOf(Mt);if(Ut===-1){for(let Et=0;Et<H.length;Et++)if(Et>=F.length){F.push(Mt),Ut=Et;break}else if(F[Et]===null){F[Et]=Mt,Ut=Et;break}if(Ut===-1)break}const Rt=H[Ut];Rt&&Rt.connect(Mt)}}const K=new et,vt=new et;function yt($,st,Mt){K.setFromMatrixPosition(st.matrixWorld),vt.setFromMatrixPosition(Mt.matrixWorld);const Ut=K.distanceTo(vt),Rt=st.projectionMatrix.elements,Et=Mt.projectionMatrix.elements,qt=Rt[14]/(Rt[10]-1),I=Rt[14]/(Rt[10]+1),Ge=(Rt[9]+1)/Rt[5],se=(Rt[9]-1)/Rt[5],Qt=(Rt[8]-1)/Rt[0],Lt=(Et[8]+1)/Et[0],ie=qt*Qt,Ft=qt*Lt,oe=Ut/(-Qt+Lt),qe=oe*-Qt;if(st.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(qe),$.translateZ(oe),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert(),Rt[10]===-1)$.projectionMatrix.copy(st.projectionMatrix),$.projectionMatrixInverse.copy(st.projectionMatrixInverse);else{const We=qt+oe,U=I+oe,T=ie-qe,nt=Ft+(Ut-qe),pt=Ge*I/U*We,xt=se*I/U*We;$.projectionMatrix.makePerspective(T,nt,pt,xt,We,U),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}}function Gt($,st){st===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(st.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(c===null)return;let st=$.near,Mt=$.far;S.texture!==null&&(S.depthNear>0&&(st=S.depthNear),S.depthFar>0&&(Mt=S.depthFar)),it.near=w.near=C.near=st,it.far=w.far=C.far=Mt,(ct!==it.near||gt!==it.far)&&(c.updateRenderState({depthNear:it.near,depthFar:it.far}),ct=it.near,gt=it.far),it.layers.mask=$.layers.mask|6,C.layers.mask=it.layers.mask&3,w.layers.mask=it.layers.mask&5;const Ut=$.parent,Rt=it.cameras;Gt(it,Ut);for(let Et=0;Et<Rt.length;Et++)Gt(Rt[Et],Ut);Rt.length===2?yt(it,C,w):it.projectionMatrix.copy(C.projectionMatrix),re($,it,Ut)};function re($,st,Mt){Mt===null?$.matrix.copy(st.matrixWorld):($.matrix.copy(Mt.matrixWorld),$.matrix.invert(),$.matrix.multiply(st.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(st.projectionMatrix),$.projectionMatrixInverse.copy(st.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=Cp*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return it},this.getFoveation=function(){if(!(y===null&&M===null))return _},this.setFoveation=function($){_=$,y!==null&&(y.fixedFoveation=$),M!==null&&M.fixedFoveation!==void 0&&(M.fixedFoveation=$)},this.hasDepthSensing=function(){return S.texture!==null},this.getDepthSensingMesh=function(){return S.getMesh(it)},this.getCameraTexture=function($){return v[$]};let Ae=null;function B($,st){if(x=st.getViewerPose(m||h),b=st,x!==null){const Mt=x.views;M!==null&&(e.setRenderTargetFramebuffer(N,M.framebuffer),e.setRenderTarget(N));let Ut=!1;Mt.length!==it.cameras.length&&(it.cameras.length=0,Ut=!0);for(let I=0;I<Mt.length;I++){const Ge=Mt[I];let se=null;if(M!==null)se=M.getViewport(Ge);else{const Lt=p.getViewSubImage(y,Ge);se=Lt.viewport,I===0&&(e.setRenderTargetTextures(N,Lt.colorTexture,Lt.depthStencilTexture),e.setRenderTarget(N))}let Qt=G[I];Qt===void 0&&(Qt=new Zn,Qt.layers.enable(I),Qt.viewport=new je,G[I]=Qt),Qt.matrix.fromArray(Ge.transform.matrix),Qt.matrix.decompose(Qt.position,Qt.quaternion,Qt.scale),Qt.projectionMatrix.fromArray(Ge.projectionMatrix),Qt.projectionMatrixInverse.copy(Qt.projectionMatrix).invert(),Qt.viewport.set(se.x,se.y,se.width,se.height),I===0&&(it.matrix.copy(Qt.matrix),it.matrix.decompose(it.position,it.quaternion,it.scale)),Ut===!0&&it.cameras.push(Qt)}const Rt=c.enabledFeatures;if(Rt&&Rt.includes("depth-sensing")&&c.depthUsage=="gpu-optimized"&&D){p=r.getBinding();const I=p.getDepthInformation(Mt[0]);I&&I.isValid&&I.texture&&S.init(I,c.renderState)}if(Rt&&Rt.includes("camera-access")&&D){e.state.unbindTexture(),p=r.getBinding();for(let I=0;I<Mt.length;I++){const Ge=Mt[I].camera;if(Ge){let se=v[Ge];se||(se=new Bx,v[Ge]=se);const Qt=p.getCameraImage(Ge);se.sourceTexture=Qt}}}}for(let Mt=0;Mt<H.length;Mt++){const Ut=F[Mt],Rt=H[Mt];Ut!==null&&Rt!==void 0&&Rt.update(Ut,st,m||h)}Ae&&Ae($,st),st.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:st}),b=null}const ft=new kx;ft.setAnimationLoop(B),this.setAnimationLoop=function($){Ae=$},this.dispose=function(){}}}const Hs=new $i,Z2=new sn;function K2(o,e){function a(S,v){S.matrixAutoUpdate===!0&&S.updateMatrix(),v.value.copy(S.matrix)}function r(S,v){v.color.getRGB(S.fogColor.value,Ux(o)),v.isFog?(S.fogNear.value=v.near,S.fogFar.value=v.far):v.isFogExp2&&(S.fogDensity.value=v.density)}function c(S,v,L,z,N){v.isMeshBasicMaterial||v.isMeshLambertMaterial?f(S,v):v.isMeshToonMaterial?(f(S,v),p(S,v)):v.isMeshPhongMaterial?(f(S,v),x(S,v)):v.isMeshStandardMaterial?(f(S,v),y(S,v),v.isMeshPhysicalMaterial&&M(S,v,N)):v.isMeshMatcapMaterial?(f(S,v),b(S,v)):v.isMeshDepthMaterial?f(S,v):v.isMeshDistanceMaterial?(f(S,v),D(S,v)):v.isMeshNormalMaterial?f(S,v):v.isLineBasicMaterial?(h(S,v),v.isLineDashedMaterial&&d(S,v)):v.isPointsMaterial?_(S,v,L,z):v.isSpriteMaterial?m(S,v):v.isShadowMaterial?(S.color.value.copy(v.color),S.opacity.value=v.opacity):v.isShaderMaterial&&(v.uniformsNeedUpdate=!1)}function f(S,v){S.opacity.value=v.opacity,v.color&&S.diffuse.value.copy(v.color),v.emissive&&S.emissive.value.copy(v.emissive).multiplyScalar(v.emissiveIntensity),v.map&&(S.map.value=v.map,a(v.map,S.mapTransform)),v.alphaMap&&(S.alphaMap.value=v.alphaMap,a(v.alphaMap,S.alphaMapTransform)),v.bumpMap&&(S.bumpMap.value=v.bumpMap,a(v.bumpMap,S.bumpMapTransform),S.bumpScale.value=v.bumpScale,v.side===Kn&&(S.bumpScale.value*=-1)),v.normalMap&&(S.normalMap.value=v.normalMap,a(v.normalMap,S.normalMapTransform),S.normalScale.value.copy(v.normalScale),v.side===Kn&&S.normalScale.value.negate()),v.displacementMap&&(S.displacementMap.value=v.displacementMap,a(v.displacementMap,S.displacementMapTransform),S.displacementScale.value=v.displacementScale,S.displacementBias.value=v.displacementBias),v.emissiveMap&&(S.emissiveMap.value=v.emissiveMap,a(v.emissiveMap,S.emissiveMapTransform)),v.specularMap&&(S.specularMap.value=v.specularMap,a(v.specularMap,S.specularMapTransform)),v.alphaTest>0&&(S.alphaTest.value=v.alphaTest);const L=e.get(v),z=L.envMap,N=L.envMapRotation;z&&(S.envMap.value=z,Hs.copy(N),Hs.x*=-1,Hs.y*=-1,Hs.z*=-1,z.isCubeTexture&&z.isRenderTargetTexture===!1&&(Hs.y*=-1,Hs.z*=-1),S.envMapRotation.value.setFromMatrix4(Z2.makeRotationFromEuler(Hs)),S.flipEnvMap.value=z.isCubeTexture&&z.isRenderTargetTexture===!1?-1:1,S.reflectivity.value=v.reflectivity,S.ior.value=v.ior,S.refractionRatio.value=v.refractionRatio),v.lightMap&&(S.lightMap.value=v.lightMap,S.lightMapIntensity.value=v.lightMapIntensity,a(v.lightMap,S.lightMapTransform)),v.aoMap&&(S.aoMap.value=v.aoMap,S.aoMapIntensity.value=v.aoMapIntensity,a(v.aoMap,S.aoMapTransform))}function h(S,v){S.diffuse.value.copy(v.color),S.opacity.value=v.opacity,v.map&&(S.map.value=v.map,a(v.map,S.mapTransform))}function d(S,v){S.dashSize.value=v.dashSize,S.totalSize.value=v.dashSize+v.gapSize,S.scale.value=v.scale}function _(S,v,L,z){S.diffuse.value.copy(v.color),S.opacity.value=v.opacity,S.size.value=v.size*L,S.scale.value=z*.5,v.map&&(S.map.value=v.map,a(v.map,S.uvTransform)),v.alphaMap&&(S.alphaMap.value=v.alphaMap,a(v.alphaMap,S.alphaMapTransform)),v.alphaTest>0&&(S.alphaTest.value=v.alphaTest)}function m(S,v){S.diffuse.value.copy(v.color),S.opacity.value=v.opacity,S.rotation.value=v.rotation,v.map&&(S.map.value=v.map,a(v.map,S.mapTransform)),v.alphaMap&&(S.alphaMap.value=v.alphaMap,a(v.alphaMap,S.alphaMapTransform)),v.alphaTest>0&&(S.alphaTest.value=v.alphaTest)}function x(S,v){S.specular.value.copy(v.specular),S.shininess.value=Math.max(v.shininess,1e-4)}function p(S,v){v.gradientMap&&(S.gradientMap.value=v.gradientMap)}function y(S,v){S.metalness.value=v.metalness,v.metalnessMap&&(S.metalnessMap.value=v.metalnessMap,a(v.metalnessMap,S.metalnessMapTransform)),S.roughness.value=v.roughness,v.roughnessMap&&(S.roughnessMap.value=v.roughnessMap,a(v.roughnessMap,S.roughnessMapTransform)),v.envMap&&(S.envMapIntensity.value=v.envMapIntensity)}function M(S,v,L){S.ior.value=v.ior,v.sheen>0&&(S.sheenColor.value.copy(v.sheenColor).multiplyScalar(v.sheen),S.sheenRoughness.value=v.sheenRoughness,v.sheenColorMap&&(S.sheenColorMap.value=v.sheenColorMap,a(v.sheenColorMap,S.sheenColorMapTransform)),v.sheenRoughnessMap&&(S.sheenRoughnessMap.value=v.sheenRoughnessMap,a(v.sheenRoughnessMap,S.sheenRoughnessMapTransform))),v.clearcoat>0&&(S.clearcoat.value=v.clearcoat,S.clearcoatRoughness.value=v.clearcoatRoughness,v.clearcoatMap&&(S.clearcoatMap.value=v.clearcoatMap,a(v.clearcoatMap,S.clearcoatMapTransform)),v.clearcoatRoughnessMap&&(S.clearcoatRoughnessMap.value=v.clearcoatRoughnessMap,a(v.clearcoatRoughnessMap,S.clearcoatRoughnessMapTransform)),v.clearcoatNormalMap&&(S.clearcoatNormalMap.value=v.clearcoatNormalMap,a(v.clearcoatNormalMap,S.clearcoatNormalMapTransform),S.clearcoatNormalScale.value.copy(v.clearcoatNormalScale),v.side===Kn&&S.clearcoatNormalScale.value.negate())),v.dispersion>0&&(S.dispersion.value=v.dispersion),v.iridescence>0&&(S.iridescence.value=v.iridescence,S.iridescenceIOR.value=v.iridescenceIOR,S.iridescenceThicknessMinimum.value=v.iridescenceThicknessRange[0],S.iridescenceThicknessMaximum.value=v.iridescenceThicknessRange[1],v.iridescenceMap&&(S.iridescenceMap.value=v.iridescenceMap,a(v.iridescenceMap,S.iridescenceMapTransform)),v.iridescenceThicknessMap&&(S.iridescenceThicknessMap.value=v.iridescenceThicknessMap,a(v.iridescenceThicknessMap,S.iridescenceThicknessMapTransform))),v.transmission>0&&(S.transmission.value=v.transmission,S.transmissionSamplerMap.value=L.texture,S.transmissionSamplerSize.value.set(L.width,L.height),v.transmissionMap&&(S.transmissionMap.value=v.transmissionMap,a(v.transmissionMap,S.transmissionMapTransform)),S.thickness.value=v.thickness,v.thicknessMap&&(S.thicknessMap.value=v.thicknessMap,a(v.thicknessMap,S.thicknessMapTransform)),S.attenuationDistance.value=v.attenuationDistance,S.attenuationColor.value.copy(v.attenuationColor)),v.anisotropy>0&&(S.anisotropyVector.value.set(v.anisotropy*Math.cos(v.anisotropyRotation),v.anisotropy*Math.sin(v.anisotropyRotation)),v.anisotropyMap&&(S.anisotropyMap.value=v.anisotropyMap,a(v.anisotropyMap,S.anisotropyMapTransform))),S.specularIntensity.value=v.specularIntensity,S.specularColor.value.copy(v.specularColor),v.specularColorMap&&(S.specularColorMap.value=v.specularColorMap,a(v.specularColorMap,S.specularColorMapTransform)),v.specularIntensityMap&&(S.specularIntensityMap.value=v.specularIntensityMap,a(v.specularIntensityMap,S.specularIntensityMapTransform))}function b(S,v){v.matcap&&(S.matcap.value=v.matcap)}function D(S,v){const L=e.get(v).light;S.referencePosition.value.setFromMatrixPosition(L.matrixWorld),S.nearDistance.value=L.shadow.camera.near,S.farDistance.value=L.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:c}}function Q2(o,e,a,r){let c={},f={},h=[];const d=o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS);function _(L,z){const N=z.program;r.uniformBlockBinding(L,N)}function m(L,z){let N=c[L.id];N===void 0&&(b(L),N=x(L),c[L.id]=N,L.addEventListener("dispose",S));const H=z.program;r.updateUBOMapping(L,H);const F=e.render.frame;f[L.id]!==F&&(y(L),f[L.id]=F)}function x(L){const z=p();L.__bindingPointIndex=z;const N=o.createBuffer(),H=L.__size,F=L.usage;return o.bindBuffer(o.UNIFORM_BUFFER,N),o.bufferData(o.UNIFORM_BUFFER,H,F),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,z,N),N}function p(){for(let L=0;L<d;L++)if(h.indexOf(L)===-1)return h.push(L),L;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function y(L){const z=c[L.id],N=L.uniforms,H=L.__cache;o.bindBuffer(o.UNIFORM_BUFFER,z);for(let F=0,P=N.length;F<P;F++){const k=Array.isArray(N[F])?N[F]:[N[F]];for(let C=0,w=k.length;C<w;C++){const G=k[C];if(M(G,F,C,H)===!0){const it=G.__offset,ct=Array.isArray(G.value)?G.value:[G.value];let gt=0;for(let ut=0;ut<ct.length;ut++){const W=ct[ut],rt=D(W);typeof W=="number"||typeof W=="boolean"?(G.__data[0]=W,o.bufferSubData(o.UNIFORM_BUFFER,it+gt,G.__data)):W.isMatrix3?(G.__data[0]=W.elements[0],G.__data[1]=W.elements[1],G.__data[2]=W.elements[2],G.__data[3]=0,G.__data[4]=W.elements[3],G.__data[5]=W.elements[4],G.__data[6]=W.elements[5],G.__data[7]=0,G.__data[8]=W.elements[6],G.__data[9]=W.elements[7],G.__data[10]=W.elements[8],G.__data[11]=0):(W.toArray(G.__data,gt),gt+=rt.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,it,G.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function M(L,z,N,H){const F=L.value,P=z+"_"+N;if(H[P]===void 0)return typeof F=="number"||typeof F=="boolean"?H[P]=F:H[P]=F.clone(),!0;{const k=H[P];if(typeof F=="number"||typeof F=="boolean"){if(k!==F)return H[P]=F,!0}else if(k.equals(F)===!1)return k.copy(F),!0}return!1}function b(L){const z=L.uniforms;let N=0;const H=16;for(let P=0,k=z.length;P<k;P++){const C=Array.isArray(z[P])?z[P]:[z[P]];for(let w=0,G=C.length;w<G;w++){const it=C[w],ct=Array.isArray(it.value)?it.value:[it.value];for(let gt=0,ut=ct.length;gt<ut;gt++){const W=ct[gt],rt=D(W),K=N%H,vt=K%rt.boundary,yt=K+vt;N+=vt,yt!==0&&H-yt<rt.storage&&(N+=H-yt),it.__data=new Float32Array(rt.storage/Float32Array.BYTES_PER_ELEMENT),it.__offset=N,N+=rt.storage}}}const F=N%H;return F>0&&(N+=H-F),L.__size=N,L.__cache={},this}function D(L){const z={boundary:0,storage:0};return typeof L=="number"||typeof L=="boolean"?(z.boundary=4,z.storage=4):L.isVector2?(z.boundary=8,z.storage=8):L.isVector3||L.isColor?(z.boundary=16,z.storage=12):L.isVector4?(z.boundary=16,z.storage=16):L.isMatrix3?(z.boundary=48,z.storage=48):L.isMatrix4?(z.boundary=64,z.storage=64):L.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",L),z}function S(L){const z=L.target;z.removeEventListener("dispose",S);const N=h.indexOf(z.__bindingPointIndex);h.splice(N,1),o.deleteBuffer(c[z.id]),delete c[z.id],delete f[z.id]}function v(){for(const L in c)o.deleteBuffer(c[L]);h=[],c={},f={}}return{bind:_,update:m,dispose:v}}class Wx{constructor(e={}){const{canvas:a=zE(),context:r=null,depth:c=!0,stencil:f=!1,alpha:h=!1,antialias:d=!1,premultipliedAlpha:_=!0,preserveDrawingBuffer:m=!1,powerPreference:x="default",failIfMajorPerformanceCaveat:p=!1,reversedDepthBuffer:y=!1}=e;this.isWebGLRenderer=!0;let M;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=r.getContextAttributes().alpha}else M=h;const b=new Uint32Array(4),D=new Int32Array(4);let S=null,v=null;const L=[],z=[];this.domElement=a,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=os,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const N=this;let H=!1;this._outputColorSpace=Mi;let F=0,P=0,k=null,C=-1,w=null;const G=new je,it=new je;let ct=null;const gt=new Te(0);let ut=0,W=a.width,rt=a.height,K=1,vt=null,yt=null;const Gt=new je(0,0,W,rt),re=new je(0,0,W,rt);let Ae=!1;const B=new Vp;let ft=!1,$=!1;const st=new sn,Mt=new et,Ut=new je,Rt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Et=!1;function qt(){return k===null?K:1}let I=r;function Ge(A,Z){return a.getContext(A,Z)}try{const A={alpha:!0,depth:c,stencil:f,antialias:d,premultipliedAlpha:_,preserveDrawingBuffer:m,powerPreference:x,failIfMajorPerformanceCaveat:p};if("setAttribute"in a&&a.setAttribute("data-engine",`three.js r${Lp}`),a.addEventListener("webglcontextlost",Dt,!1),a.addEventListener("webglcontextrestored",Vt,!1),a.addEventListener("webglcontextcreationerror",St,!1),I===null){const Z="webgl2";if(I=Ge(Z,A),I===null)throw Ge(Z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let se,Qt,Lt,ie,Ft,oe,qe,We,U,T,nt,pt,xt,ht,kt,Ct,Wt,Kt,bt,Ot,ne,Zt,zt,ue;function X(){se=new lA(I),se.init(),Zt=new X2(I,se),Qt=new eA(I,se,e,Zt),Lt=new V2(I,se),Qt.reversedDepthBuffer&&y&&Lt.buffers.depth.setReversed(!0),ie=new fA(I),Ft=new w2,oe=new k2(I,se,Lt,Ft,Qt,Zt,ie),qe=new iA(N),We=new oA(N),U=new _1(I),zt=new $b(I,U),T=new cA(I,U,ie,zt),nt=new dA(I,T,U,ie),bt=new hA(I,Qt,oe),Ct=new nA(Ft),pt=new C2(N,qe,We,se,Qt,zt,Ct),xt=new K2(N,Ft),ht=new N2,kt=new I2(se),Kt=new Jb(N,qe,We,Lt,nt,M,_),Wt=new H2(N,nt,Qt),ue=new Q2(I,ie,Qt,Lt),Ot=new tA(I,se,ie),ne=new uA(I,se,ie),ie.programs=pt.programs,N.capabilities=Qt,N.extensions=se,N.properties=Ft,N.renderLists=ht,N.shadowMap=Wt,N.state=Lt,N.info=ie}X();const At=new W2(N,I);this.xr=At,this.getContext=function(){return I},this.getContextAttributes=function(){return I.getContextAttributes()},this.forceContextLoss=function(){const A=se.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){const A=se.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return K},this.setPixelRatio=function(A){A!==void 0&&(K=A,this.setSize(W,rt,!1))},this.getSize=function(A){return A.set(W,rt)},this.setSize=function(A,Z,ot=!0){if(At.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}W=A,rt=Z,a.width=Math.floor(A*K),a.height=Math.floor(Z*K),ot===!0&&(a.style.width=A+"px",a.style.height=Z+"px"),this.setViewport(0,0,A,Z)},this.getDrawingBufferSize=function(A){return A.set(W*K,rt*K).floor()},this.setDrawingBufferSize=function(A,Z,ot){W=A,rt=Z,K=ot,a.width=Math.floor(A*ot),a.height=Math.floor(Z*ot),this.setViewport(0,0,A,Z)},this.getCurrentViewport=function(A){return A.copy(G)},this.getViewport=function(A){return A.copy(Gt)},this.setViewport=function(A,Z,ot,lt){A.isVector4?Gt.set(A.x,A.y,A.z,A.w):Gt.set(A,Z,ot,lt),Lt.viewport(G.copy(Gt).multiplyScalar(K).round())},this.getScissor=function(A){return A.copy(re)},this.setScissor=function(A,Z,ot,lt){A.isVector4?re.set(A.x,A.y,A.z,A.w):re.set(A,Z,ot,lt),Lt.scissor(it.copy(re).multiplyScalar(K).round())},this.getScissorTest=function(){return Ae},this.setScissorTest=function(A){Lt.setScissorTest(Ae=A)},this.setOpaqueSort=function(A){vt=A},this.setTransparentSort=function(A){yt=A},this.getClearColor=function(A){return A.copy(Kt.getClearColor())},this.setClearColor=function(){Kt.setClearColor(...arguments)},this.getClearAlpha=function(){return Kt.getClearAlpha()},this.setClearAlpha=function(){Kt.setClearAlpha(...arguments)},this.clear=function(A=!0,Z=!0,ot=!0){let lt=0;if(A){let Q=!1;if(k!==null){const Tt=k.texture.format;Q=Tt===Hp||Tt===Fp||Tt===Bp}if(Q){const Tt=k.texture.type,Pt=Tt===Ji||Tt===Zs||Tt===fl||Tt===hl||Tt===Pp||Tt===Ip,Bt=Kt.getClearColor(),wt=Kt.getClearAlpha(),Xt=Bt.r,ee=Bt.g,$t=Bt.b;Pt?(b[0]=Xt,b[1]=ee,b[2]=$t,b[3]=wt,I.clearBufferuiv(I.COLOR,0,b)):(D[0]=Xt,D[1]=ee,D[2]=$t,D[3]=wt,I.clearBufferiv(I.COLOR,0,D))}else lt|=I.COLOR_BUFFER_BIT}Z&&(lt|=I.DEPTH_BUFFER_BIT),ot&&(lt|=I.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),I.clear(lt)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){a.removeEventListener("webglcontextlost",Dt,!1),a.removeEventListener("webglcontextrestored",Vt,!1),a.removeEventListener("webglcontextcreationerror",St,!1),Kt.dispose(),ht.dispose(),kt.dispose(),Ft.dispose(),qe.dispose(),We.dispose(),nt.dispose(),zt.dispose(),ue.dispose(),pt.dispose(),At.dispose(),At.removeEventListener("sessionstart",gn),At.removeEventListener("sessionend",Un),ta.stop()};function Dt(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),H=!0}function Vt(){console.log("THREE.WebGLRenderer: Context Restored."),H=!1;const A=ie.autoReset,Z=Wt.enabled,ot=Wt.autoUpdate,lt=Wt.needsUpdate,Q=Wt.type;X(),ie.autoReset=A,Wt.enabled=Z,Wt.autoUpdate=ot,Wt.needsUpdate=lt,Wt.type=Q}function St(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function _t(A){const Z=A.target;Z.removeEventListener("dispose",_t),Yt(Z)}function Yt(A){ce(A),Ft.remove(A)}function ce(A){const Z=Ft.get(A).programs;Z!==void 0&&(Z.forEach(function(ot){pt.releaseProgram(ot)}),A.isShaderMaterial&&pt.releaseShaderCache(A))}this.renderBufferDirect=function(A,Z,ot,lt,Q,Tt){Z===null&&(Z=Rt);const Pt=Q.isMesh&&Q.matrixWorld.determinant()<0,Bt=Ml(A,Z,ot,lt,Q);Lt.setMaterial(lt,Pt);let wt=ot.index,Xt=1;if(lt.wireframe===!0){if(wt=T.getWireframeAttribute(ot),wt===void 0)return;Xt=2}const ee=ot.drawRange,$t=ot.attributes.position;let _e=ee.start*Xt,Pe=(ee.start+ee.count)*Xt;Tt!==null&&(_e=Math.max(_e,Tt.start*Xt),Pe=Math.min(Pe,(Tt.start+Tt.count)*Xt)),wt!==null?(_e=Math.max(_e,0),Pe=Math.min(Pe,wt.count)):$t!=null&&(_e=Math.max(_e,0),Pe=Math.min(Pe,$t.count));const Je=Pe-_e;if(Je<0||Je===1/0)return;zt.setup(Q,lt,Bt,ot,wt);let Le,Ce=Ot;if(wt!==null&&(Le=U.get(wt),Ce=ne,Ce.setIndex(Le)),Q.isMesh)lt.wireframe===!0?(Lt.setLineWidth(lt.wireframeLinewidth*qt()),Ce.setMode(I.LINES)):Ce.setMode(I.TRIANGLES);else if(Q.isLine){let te=lt.linewidth;te===void 0&&(te=1),Lt.setLineWidth(te*qt()),Q.isLineSegments?Ce.setMode(I.LINES):Q.isLineLoop?Ce.setMode(I.LINE_LOOP):Ce.setMode(I.LINE_STRIP)}else Q.isPoints?Ce.setMode(I.POINTS):Q.isSprite&&Ce.setMode(I.TRIANGLES);if(Q.isBatchedMesh)if(Q._multiDrawInstances!==null)ml("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),Ce.renderMultiDrawInstances(Q._multiDrawStarts,Q._multiDrawCounts,Q._multiDrawCount,Q._multiDrawInstances);else if(se.get("WEBGL_multi_draw"))Ce.renderMultiDraw(Q._multiDrawStarts,Q._multiDrawCounts,Q._multiDrawCount);else{const te=Q._multiDrawStarts,Oe=Q._multiDrawCounts,me=Q._multiDrawCount,_n=wt?U.get(wt).bytesPerElement:1,Jn=Ft.get(lt).currentProgram.getUniforms();for(let we=0;we<me;we++)Jn.setValue(I,"_gl_DrawID",we),Ce.render(te[we]/_n,Oe[we])}else if(Q.isInstancedMesh)Ce.renderInstances(_e,Je,Q.count);else if(ot.isInstancedBufferGeometry){const te=ot._maxInstanceCount!==void 0?ot._maxInstanceCount:1/0,Oe=Math.min(ot.instanceCount,te);Ce.renderInstances(_e,Je,Oe)}else Ce.render(_e,Je)};function Ve(A,Z,ot){A.transparent===!0&&A.side===Ma&&A.forceSinglePass===!1?(A.side=Kn,A.needsUpdate=!0,fi(A,Z,ot),A.side=cs,A.needsUpdate=!0,fi(A,Z,ot),A.side=Ma):fi(A,Z,ot)}this.compile=function(A,Z,ot=null){ot===null&&(ot=A),v=kt.get(ot),v.init(Z),z.push(v),ot.traverseVisible(function(Q){Q.isLight&&Q.layers.test(Z.layers)&&(v.pushLight(Q),Q.castShadow&&v.pushShadow(Q))}),A!==ot&&A.traverseVisible(function(Q){Q.isLight&&Q.layers.test(Z.layers)&&(v.pushLight(Q),Q.castShadow&&v.pushShadow(Q))}),v.setupLights();const lt=new Set;return A.traverse(function(Q){if(!(Q.isMesh||Q.isPoints||Q.isLine||Q.isSprite))return;const Tt=Q.material;if(Tt)if(Array.isArray(Tt))for(let Pt=0;Pt<Tt.length;Pt++){const Bt=Tt[Pt];Ve(Bt,ot,Q),lt.add(Bt)}else Ve(Tt,ot,Q),lt.add(Tt)}),v=z.pop(),lt},this.compileAsync=function(A,Z,ot=null){const lt=this.compile(A,Z,ot);return new Promise(Q=>{function Tt(){if(lt.forEach(function(Pt){Ft.get(Pt).currentProgram.isReady()&&lt.delete(Pt)}),lt.size===0){Q(A);return}setTimeout(Tt,10)}se.get("KHR_parallel_shader_compile")!==null?Tt():setTimeout(Tt,10)})};let Se=null;function en(A){Se&&Se(A)}function gn(){ta.stop()}function Un(){ta.start()}const ta=new kx;ta.setAnimationLoop(en),typeof self<"u"&&ta.setContext(self),this.setAnimationLoop=function(A){Se=A,At.setAnimationLoop(A),A===null?ta.stop():ta.start()},At.addEventListener("sessionstart",gn),At.addEventListener("sessionend",Un),this.render=function(A,Z){if(Z!==void 0&&Z.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(H===!0)return;if(A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),Z.parent===null&&Z.matrixWorldAutoUpdate===!0&&Z.updateMatrixWorld(),At.enabled===!0&&At.isPresenting===!0&&(At.cameraAutoUpdate===!0&&At.updateCamera(Z),Z=At.getCamera()),A.isScene===!0&&A.onBeforeRender(N,A,Z,k),v=kt.get(A,z.length),v.init(Z),z.push(v),st.multiplyMatrices(Z.projectionMatrix,Z.matrixWorldInverse),B.setFromProjectionMatrix(st,Qi,Z.reversedDepth),$=this.localClippingEnabled,ft=Ct.init(this.clippingPlanes,$),S=ht.get(A,L.length),S.init(),L.push(S),At.enabled===!0&&At.isPresenting===!0){const Tt=N.xr.getDepthSensingMesh();Tt!==null&&fo(Tt,Z,-1/0,N.sortObjects)}fo(A,Z,0,N.sortObjects),S.finish(),N.sortObjects===!0&&S.sort(vt,yt),Et=At.enabled===!1||At.isPresenting===!1||At.hasDepthSensing()===!1,Et&&Kt.addToRenderList(S,A),this.info.render.frame++,ft===!0&&Ct.beginShadows();const ot=v.state.shadowsArray;Wt.render(ot,A,Z),ft===!0&&Ct.endShadows(),this.info.autoReset===!0&&this.info.reset();const lt=S.opaque,Q=S.transmissive;if(v.setupLights(),Z.isArrayCamera){const Tt=Z.cameras;if(Q.length>0)for(let Pt=0,Bt=Tt.length;Pt<Bt;Pt++){const wt=Tt[Pt];fs(lt,Q,A,wt)}Et&&Kt.render(A);for(let Pt=0,Bt=Tt.length;Pt<Bt;Pt++){const wt=Tt[Pt];Sl(S,A,wt,wt.viewport)}}else Q.length>0&&fs(lt,Q,A,Z),Et&&Kt.render(A),Sl(S,A,Z);k!==null&&P===0&&(oe.updateMultisampleRenderTarget(k),oe.updateRenderTargetMipmap(k)),A.isScene===!0&&A.onAfterRender(N,A,Z),zt.resetDefaultState(),C=-1,w=null,z.pop(),z.length>0?(v=z[z.length-1],ft===!0&&Ct.setGlobalState(N.clippingPlanes,v.state.camera)):v=null,L.pop(),L.length>0?S=L[L.length-1]:S=null};function fo(A,Z,ot,lt){if(A.visible===!1)return;if(A.layers.test(Z.layers)){if(A.isGroup)ot=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(Z);else if(A.isLight)v.pushLight(A),A.castShadow&&v.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||B.intersectsSprite(A)){lt&&Ut.setFromMatrixPosition(A.matrixWorld).applyMatrix4(st);const Pt=nt.update(A),Bt=A.material;Bt.visible&&S.push(A,Pt,Bt,ot,Ut.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||B.intersectsObject(A))){const Pt=nt.update(A),Bt=A.material;if(lt&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),Ut.copy(A.boundingSphere.center)):(Pt.boundingSphere===null&&Pt.computeBoundingSphere(),Ut.copy(Pt.boundingSphere.center)),Ut.applyMatrix4(A.matrixWorld).applyMatrix4(st)),Array.isArray(Bt)){const wt=Pt.groups;for(let Xt=0,ee=wt.length;Xt<ee;Xt++){const $t=wt[Xt],_e=Bt[$t.materialIndex];_e&&_e.visible&&S.push(A,Pt,_e,ot,Ut.z,$t)}}else Bt.visible&&S.push(A,Pt,Bt,ot,Ut.z,null)}}const Tt=A.children;for(let Pt=0,Bt=Tt.length;Pt<Bt;Pt++)fo(Tt[Pt],Z,ot,lt)}function Sl(A,Z,ot,lt){const Q=A.opaque,Tt=A.transmissive,Pt=A.transparent;v.setupLightsView(ot),ft===!0&&Ct.setGlobalState(N.clippingPlanes,ot),lt&&Lt.viewport(G.copy(lt)),Q.length>0&&ea(Q,Z,ot),Tt.length>0&&ea(Tt,Z,ot),Pt.length>0&&ea(Pt,Z,ot),Lt.buffers.depth.setTest(!0),Lt.buffers.depth.setMask(!0),Lt.buffers.color.setMask(!0),Lt.setPolygonOffset(!1)}function fs(A,Z,ot,lt){if((ot.isScene===!0?ot.overrideMaterial:null)!==null)return;v.state.transmissionRenderTarget[lt.id]===void 0&&(v.state.transmissionRenderTarget[lt.id]=new Ks(1,1,{generateMipmaps:!0,type:se.has("EXT_color_buffer_half_float")||se.has("EXT_color_buffer_float")?_l:Ji,minFilter:qs,samples:4,stencilBuffer:f,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ne.workingColorSpace}));const Tt=v.state.transmissionRenderTarget[lt.id],Pt=lt.viewport||G;Tt.setSize(Pt.z*N.transmissionResolutionScale,Pt.w*N.transmissionResolutionScale);const Bt=N.getRenderTarget(),wt=N.getActiveCubeFace(),Xt=N.getActiveMipmapLevel();N.setRenderTarget(Tt),N.getClearColor(gt),ut=N.getClearAlpha(),ut<1&&N.setClearColor(16777215,.5),N.clear(),Et&&Kt.render(ot);const ee=N.toneMapping;N.toneMapping=os;const $t=lt.viewport;if(lt.viewport!==void 0&&(lt.viewport=void 0),v.setupLightsView(lt),ft===!0&&Ct.setGlobalState(N.clippingPlanes,lt),ea(A,ot,lt),oe.updateMultisampleRenderTarget(Tt),oe.updateRenderTargetMipmap(Tt),se.has("WEBGL_multisampled_render_to_texture")===!1){let _e=!1;for(let Pe=0,Je=Z.length;Pe<Je;Pe++){const Le=Z[Pe],Ce=Le.object,te=Le.geometry,Oe=Le.material,me=Le.group;if(Oe.side===Ma&&Ce.layers.test(lt.layers)){const _n=Oe.side;Oe.side=Kn,Oe.needsUpdate=!0,hs(Ce,ot,lt,te,Oe,me),Oe.side=_n,Oe.needsUpdate=!0,_e=!0}}_e===!0&&(oe.updateMultisampleRenderTarget(Tt),oe.updateRenderTargetMipmap(Tt))}N.setRenderTarget(Bt,wt,Xt),N.setClearColor(gt,ut),$t!==void 0&&(lt.viewport=$t),N.toneMapping=ee}function ea(A,Z,ot){const lt=Z.isScene===!0?Z.overrideMaterial:null;for(let Q=0,Tt=A.length;Q<Tt;Q++){const Pt=A[Q],Bt=Pt.object,wt=Pt.geometry,Xt=Pt.group;let ee=Pt.material;ee.allowOverride===!0&&lt!==null&&(ee=lt),Bt.layers.test(ot.layers)&&hs(Bt,Z,ot,wt,ee,Xt)}}function hs(A,Z,ot,lt,Q,Tt){A.onBeforeRender(N,Z,ot,lt,Q,Tt),A.modelViewMatrix.multiplyMatrices(ot.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),Q.onBeforeRender(N,Z,ot,lt,A,Tt),Q.transparent===!0&&Q.side===Ma&&Q.forceSinglePass===!1?(Q.side=Kn,Q.needsUpdate=!0,N.renderBufferDirect(ot,Z,lt,Q,A,Tt),Q.side=cs,Q.needsUpdate=!0,N.renderBufferDirect(ot,Z,lt,Q,A,Tt),Q.side=Ma):N.renderBufferDirect(ot,Z,lt,Q,A,Tt),A.onAfterRender(N,Z,ot,lt,Q,Tt)}function fi(A,Z,ot){Z.isScene!==!0&&(Z=Rt);const lt=Ft.get(A),Q=v.state.lights,Tt=v.state.shadowsArray,Pt=Q.state.version,Bt=pt.getParameters(A,Q.state,Tt,Z,ot),wt=pt.getProgramCacheKey(Bt);let Xt=lt.programs;lt.environment=A.isMeshStandardMaterial?Z.environment:null,lt.fog=Z.fog,lt.envMap=(A.isMeshStandardMaterial?We:qe).get(A.envMap||lt.environment),lt.envMapRotation=lt.environment!==null&&A.envMap===null?Z.environmentRotation:A.envMapRotation,Xt===void 0&&(A.addEventListener("dispose",_t),Xt=new Map,lt.programs=Xt);let ee=Xt.get(wt);if(ee!==void 0){if(lt.currentProgram===ee&&lt.lightsStateVersion===Pt)return ba(A,Bt),ee}else Bt.uniforms=pt.getUniforms(A),A.onBeforeCompile(Bt,N),ee=pt.acquireProgram(Bt,wt),Xt.set(wt,ee),lt.uniforms=Bt.uniforms;const $t=lt.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&($t.clippingPlanes=Ct.uniform),ba(A,Bt),lt.needsLights=El(A),lt.lightsStateVersion=Pt,lt.needsLights&&($t.ambientLightColor.value=Q.state.ambient,$t.lightProbe.value=Q.state.probe,$t.directionalLights.value=Q.state.directional,$t.directionalLightShadows.value=Q.state.directionalShadow,$t.spotLights.value=Q.state.spot,$t.spotLightShadows.value=Q.state.spotShadow,$t.rectAreaLights.value=Q.state.rectArea,$t.ltc_1.value=Q.state.rectAreaLTC1,$t.ltc_2.value=Q.state.rectAreaLTC2,$t.pointLights.value=Q.state.point,$t.pointLightShadows.value=Q.state.pointShadow,$t.hemisphereLights.value=Q.state.hemi,$t.directionalShadowMap.value=Q.state.directionalShadowMap,$t.directionalShadowMatrix.value=Q.state.directionalShadowMatrix,$t.spotShadowMap.value=Q.state.spotShadowMap,$t.spotLightMatrix.value=Q.state.spotLightMatrix,$t.spotLightMap.value=Q.state.spotLightMap,$t.pointShadowMap.value=Q.state.pointShadowMap,$t.pointShadowMatrix.value=Q.state.pointShadowMatrix),lt.currentProgram=ee,lt.uniformsList=null,ee}function ds(A){if(A.uniformsList===null){const Z=A.currentProgram.getUniforms();A.uniformsList=vu.seqWithValue(Z.seq,A.uniforms)}return A.uniformsList}function ba(A,Z){const ot=Ft.get(A);ot.outputColorSpace=Z.outputColorSpace,ot.batching=Z.batching,ot.batchingColor=Z.batchingColor,ot.instancing=Z.instancing,ot.instancingColor=Z.instancingColor,ot.instancingMorph=Z.instancingMorph,ot.skinning=Z.skinning,ot.morphTargets=Z.morphTargets,ot.morphNormals=Z.morphNormals,ot.morphColors=Z.morphColors,ot.morphTargetsCount=Z.morphTargetsCount,ot.numClippingPlanes=Z.numClippingPlanes,ot.numIntersection=Z.numClipIntersection,ot.vertexAlphas=Z.vertexAlphas,ot.vertexTangents=Z.vertexTangents,ot.toneMapping=Z.toneMapping}function Ml(A,Z,ot,lt,Q){Z.isScene!==!0&&(Z=Rt),oe.resetTextureUnits();const Tt=Z.fog,Pt=lt.isMeshStandardMaterial?Z.environment:null,Bt=k===null?N.outputColorSpace:k.isXRRenderTarget===!0?k.texture.colorSpace:so,wt=(lt.isMeshStandardMaterial?We:qe).get(lt.envMap||Pt),Xt=lt.vertexColors===!0&&!!ot.attributes.color&&ot.attributes.color.itemSize===4,ee=!!ot.attributes.tangent&&(!!lt.normalMap||lt.anisotropy>0),$t=!!ot.morphAttributes.position,_e=!!ot.morphAttributes.normal,Pe=!!ot.morphAttributes.color;let Je=os;lt.toneMapped&&(k===null||k.isXRRenderTarget===!0)&&(Je=N.toneMapping);const Le=ot.morphAttributes.position||ot.morphAttributes.normal||ot.morphAttributes.color,Ce=Le!==void 0?Le.length:0,te=Ft.get(lt),Oe=v.state.lights;if(ft===!0&&($===!0||A!==w)){const rn=A===w&&lt.id===C;Ct.setState(lt,A,rn)}let me=!1;lt.version===te.__version?(te.needsLights&&te.lightsStateVersion!==Oe.state.version||te.outputColorSpace!==Bt||Q.isBatchedMesh&&te.batching===!1||!Q.isBatchedMesh&&te.batching===!0||Q.isBatchedMesh&&te.batchingColor===!0&&Q.colorTexture===null||Q.isBatchedMesh&&te.batchingColor===!1&&Q.colorTexture!==null||Q.isInstancedMesh&&te.instancing===!1||!Q.isInstancedMesh&&te.instancing===!0||Q.isSkinnedMesh&&te.skinning===!1||!Q.isSkinnedMesh&&te.skinning===!0||Q.isInstancedMesh&&te.instancingColor===!0&&Q.instanceColor===null||Q.isInstancedMesh&&te.instancingColor===!1&&Q.instanceColor!==null||Q.isInstancedMesh&&te.instancingMorph===!0&&Q.morphTexture===null||Q.isInstancedMesh&&te.instancingMorph===!1&&Q.morphTexture!==null||te.envMap!==wt||lt.fog===!0&&te.fog!==Tt||te.numClippingPlanes!==void 0&&(te.numClippingPlanes!==Ct.numPlanes||te.numIntersection!==Ct.numIntersection)||te.vertexAlphas!==Xt||te.vertexTangents!==ee||te.morphTargets!==$t||te.morphNormals!==_e||te.morphColors!==Pe||te.toneMapping!==Je||te.morphTargetsCount!==Ce)&&(me=!0):(me=!0,te.__version=lt.version);let _n=te.currentProgram;me===!0&&(_n=fi(lt,Z,Q));let Jn=!1,we=!1,Aa=!1;const Ze=_n.getUniforms(),In=te.uniforms;if(Lt.useProgram(_n.program)&&(Jn=!0,we=!0,Aa=!0),lt.id!==C&&(C=lt.id,we=!0),Jn||w!==A){Lt.buffers.depth.getReversed()&&A.reversedDepth!==!0&&(A._reversedDepth=!0,A.updateProjectionMatrix()),Ze.setValue(I,"projectionMatrix",A.projectionMatrix),Ze.setValue(I,"viewMatrix",A.matrixWorldInverse);const Ln=Ze.map.cameraPosition;Ln!==void 0&&Ln.setValue(I,Mt.setFromMatrixPosition(A.matrixWorld)),Qt.logarithmicDepthBuffer&&Ze.setValue(I,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(lt.isMeshPhongMaterial||lt.isMeshToonMaterial||lt.isMeshLambertMaterial||lt.isMeshBasicMaterial||lt.isMeshStandardMaterial||lt.isShaderMaterial)&&Ze.setValue(I,"isOrthographic",A.isOrthographicCamera===!0),w!==A&&(w=A,we=!0,Aa=!0)}if(Q.isSkinnedMesh){Ze.setOptional(I,Q,"bindMatrix"),Ze.setOptional(I,Q,"bindMatrixInverse");const rn=Q.skeleton;rn&&(rn.boneTexture===null&&rn.computeBoneTexture(),Ze.setValue(I,"boneTexture",rn.boneTexture,oe))}Q.isBatchedMesh&&(Ze.setOptional(I,Q,"batchingTexture"),Ze.setValue(I,"batchingTexture",Q._matricesTexture,oe),Ze.setOptional(I,Q,"batchingIdTexture"),Ze.setValue(I,"batchingIdTexture",Q._indirectTexture,oe),Ze.setOptional(I,Q,"batchingColorTexture"),Q._colorsTexture!==null&&Ze.setValue(I,"batchingColorTexture",Q._colorsTexture,oe));const un=ot.morphAttributes;if((un.position!==void 0||un.normal!==void 0||un.color!==void 0)&&bt.update(Q,ot,_n),(we||te.receiveShadow!==Q.receiveShadow)&&(te.receiveShadow=Q.receiveShadow,Ze.setValue(I,"receiveShadow",Q.receiveShadow)),lt.isMeshGouraudMaterial&&lt.envMap!==null&&(In.envMap.value=wt,In.flipEnvMap.value=wt.isCubeTexture&&wt.isRenderTargetTexture===!1?-1:1),lt.isMeshStandardMaterial&&lt.envMap===null&&Z.environment!==null&&(In.envMapIntensity.value=Z.environmentIntensity),we&&(Ze.setValue(I,"toneMappingExposure",N.toneMappingExposure),te.needsLights&&wu(In,Aa),Tt&&lt.fog===!0&&xt.refreshFogUniforms(In,Tt),xt.refreshMaterialUniforms(In,lt,K,rt,v.state.transmissionRenderTarget[A.id]),vu.upload(I,ds(te),In,oe)),lt.isShaderMaterial&&lt.uniformsNeedUpdate===!0&&(vu.upload(I,ds(te),In,oe),lt.uniformsNeedUpdate=!1),lt.isSpriteMaterial&&Ze.setValue(I,"center",Q.center),Ze.setValue(I,"modelViewMatrix",Q.modelViewMatrix),Ze.setValue(I,"normalMatrix",Q.normalMatrix),Ze.setValue(I,"modelMatrix",Q.matrixWorld),lt.isShaderMaterial||lt.isRawShaderMaterial){const rn=lt.uniformsGroups;for(let Ln=0,Js=rn.length;Ln<Js;Ln++){const Ii=rn[Ln];ue.update(Ii,_n),ue.bind(Ii,_n)}}return _n}function wu(A,Z){A.ambientLightColor.needsUpdate=Z,A.lightProbe.needsUpdate=Z,A.directionalLights.needsUpdate=Z,A.directionalLightShadows.needsUpdate=Z,A.pointLights.needsUpdate=Z,A.pointLightShadows.needsUpdate=Z,A.spotLights.needsUpdate=Z,A.spotLightShadows.needsUpdate=Z,A.rectAreaLights.needsUpdate=Z,A.hemisphereLights.needsUpdate=Z}function El(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return F},this.getActiveMipmapLevel=function(){return P},this.getRenderTarget=function(){return k},this.setRenderTargetTextures=function(A,Z,ot){const lt=Ft.get(A);lt.__autoAllocateDepthBuffer=A.resolveDepthBuffer===!1,lt.__autoAllocateDepthBuffer===!1&&(lt.__useRenderToTexture=!1),Ft.get(A.texture).__webglTexture=Z,Ft.get(A.depthTexture).__webglTexture=lt.__autoAllocateDepthBuffer?void 0:ot,lt.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(A,Z){const ot=Ft.get(A);ot.__webglFramebuffer=Z,ot.__useDefaultFramebuffer=Z===void 0};const ho=I.createFramebuffer();this.setRenderTarget=function(A,Z=0,ot=0){k=A,F=Z,P=ot;let lt=!0,Q=null,Tt=!1,Pt=!1;if(A){const wt=Ft.get(A);if(wt.__useDefaultFramebuffer!==void 0)Lt.bindFramebuffer(I.FRAMEBUFFER,null),lt=!1;else if(wt.__webglFramebuffer===void 0)oe.setupRenderTarget(A);else if(wt.__hasExternalTextures)oe.rebindTextures(A,Ft.get(A.texture).__webglTexture,Ft.get(A.depthTexture).__webglTexture);else if(A.depthBuffer){const $t=A.depthTexture;if(wt.__boundDepthTexture!==$t){if($t!==null&&Ft.has($t)&&(A.width!==$t.image.width||A.height!==$t.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");oe.setupDepthRenderbuffer(A)}}const Xt=A.texture;(Xt.isData3DTexture||Xt.isDataArrayTexture||Xt.isCompressedArrayTexture)&&(Pt=!0);const ee=Ft.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(ee[Z])?Q=ee[Z][ot]:Q=ee[Z],Tt=!0):A.samples>0&&oe.useMultisampledRTT(A)===!1?Q=Ft.get(A).__webglMultisampledFramebuffer:Array.isArray(ee)?Q=ee[ot]:Q=ee,G.copy(A.viewport),it.copy(A.scissor),ct=A.scissorTest}else G.copy(Gt).multiplyScalar(K).floor(),it.copy(re).multiplyScalar(K).floor(),ct=Ae;if(ot!==0&&(Q=ho),Lt.bindFramebuffer(I.FRAMEBUFFER,Q)&&lt&&Lt.drawBuffers(A,Q),Lt.viewport(G),Lt.scissor(it),Lt.setScissorTest(ct),Tt){const wt=Ft.get(A.texture);I.framebufferTexture2D(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_CUBE_MAP_POSITIVE_X+Z,wt.__webglTexture,ot)}else if(Pt){const wt=Z;for(let Xt=0;Xt<A.textures.length;Xt++){const ee=Ft.get(A.textures[Xt]);I.framebufferTextureLayer(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0+Xt,ee.__webglTexture,ot,wt)}}else if(A!==null&&ot!==0){const wt=Ft.get(A.texture);I.framebufferTexture2D(I.FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,wt.__webglTexture,ot)}C=-1},this.readRenderTargetPixels=function(A,Z,ot,lt,Q,Tt,Pt,Bt=0){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let wt=Ft.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Pt!==void 0&&(wt=wt[Pt]),wt){Lt.bindFramebuffer(I.FRAMEBUFFER,wt);try{const Xt=A.textures[Bt],ee=Xt.format,$t=Xt.type;if(!Qt.textureFormatReadable(ee)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Qt.textureTypeReadable($t)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Z>=0&&Z<=A.width-lt&&ot>=0&&ot<=A.height-Q&&(A.textures.length>1&&I.readBuffer(I.COLOR_ATTACHMENT0+Bt),I.readPixels(Z,ot,lt,Q,Zt.convert(ee),Zt.convert($t),Tt))}finally{const Xt=k!==null?Ft.get(k).__webglFramebuffer:null;Lt.bindFramebuffer(I.FRAMEBUFFER,Xt)}}},this.readRenderTargetPixelsAsync=async function(A,Z,ot,lt,Q,Tt,Pt,Bt=0){if(!(A&&A.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let wt=Ft.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Pt!==void 0&&(wt=wt[Pt]),wt)if(Z>=0&&Z<=A.width-lt&&ot>=0&&ot<=A.height-Q){Lt.bindFramebuffer(I.FRAMEBUFFER,wt);const Xt=A.textures[Bt],ee=Xt.format,$t=Xt.type;if(!Qt.textureFormatReadable(ee))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Qt.textureTypeReadable($t))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const _e=I.createBuffer();I.bindBuffer(I.PIXEL_PACK_BUFFER,_e),I.bufferData(I.PIXEL_PACK_BUFFER,Tt.byteLength,I.STREAM_READ),A.textures.length>1&&I.readBuffer(I.COLOR_ATTACHMENT0+Bt),I.readPixels(Z,ot,lt,Q,Zt.convert(ee),Zt.convert($t),0);const Pe=k!==null?Ft.get(k).__webglFramebuffer:null;Lt.bindFramebuffer(I.FRAMEBUFFER,Pe);const Je=I.fenceSync(I.SYNC_GPU_COMMANDS_COMPLETE,0);return I.flush(),await PE(I,Je,4),I.bindBuffer(I.PIXEL_PACK_BUFFER,_e),I.getBufferSubData(I.PIXEL_PACK_BUFFER,0,Tt),I.deleteBuffer(_e),I.deleteSync(Je),Tt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(A,Z=null,ot=0){const lt=Math.pow(2,-ot),Q=Math.floor(A.image.width*lt),Tt=Math.floor(A.image.height*lt),Pt=Z!==null?Z.x:0,Bt=Z!==null?Z.y:0;oe.setTexture2D(A,0),I.copyTexSubImage2D(I.TEXTURE_2D,ot,0,0,Pt,Bt,Q,Tt),Lt.unbindTexture()};const ps=I.createFramebuffer(),Du=I.createFramebuffer();this.copyTextureToTexture=function(A,Z,ot=null,lt=null,Q=0,Tt=null){Tt===null&&(Q!==0?(ml("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),Tt=Q,Q=0):Tt=0);let Pt,Bt,wt,Xt,ee,$t,_e,Pe,Je;const Le=A.isCompressedTexture?A.mipmaps[Tt]:A.image;if(ot!==null)Pt=ot.max.x-ot.min.x,Bt=ot.max.y-ot.min.y,wt=ot.isBox3?ot.max.z-ot.min.z:1,Xt=ot.min.x,ee=ot.min.y,$t=ot.isBox3?ot.min.z:0;else{const un=Math.pow(2,-Q);Pt=Math.floor(Le.width*un),Bt=Math.floor(Le.height*un),A.isDataArrayTexture?wt=Le.depth:A.isData3DTexture?wt=Math.floor(Le.depth*un):wt=1,Xt=0,ee=0,$t=0}lt!==null?(_e=lt.x,Pe=lt.y,Je=lt.z):(_e=0,Pe=0,Je=0);const Ce=Zt.convert(Z.format),te=Zt.convert(Z.type);let Oe;Z.isData3DTexture?(oe.setTexture3D(Z,0),Oe=I.TEXTURE_3D):Z.isDataArrayTexture||Z.isCompressedArrayTexture?(oe.setTexture2DArray(Z,0),Oe=I.TEXTURE_2D_ARRAY):(oe.setTexture2D(Z,0),Oe=I.TEXTURE_2D),I.pixelStorei(I.UNPACK_FLIP_Y_WEBGL,Z.flipY),I.pixelStorei(I.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Z.premultiplyAlpha),I.pixelStorei(I.UNPACK_ALIGNMENT,Z.unpackAlignment);const me=I.getParameter(I.UNPACK_ROW_LENGTH),_n=I.getParameter(I.UNPACK_IMAGE_HEIGHT),Jn=I.getParameter(I.UNPACK_SKIP_PIXELS),we=I.getParameter(I.UNPACK_SKIP_ROWS),Aa=I.getParameter(I.UNPACK_SKIP_IMAGES);I.pixelStorei(I.UNPACK_ROW_LENGTH,Le.width),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,Le.height),I.pixelStorei(I.UNPACK_SKIP_PIXELS,Xt),I.pixelStorei(I.UNPACK_SKIP_ROWS,ee),I.pixelStorei(I.UNPACK_SKIP_IMAGES,$t);const Ze=A.isDataArrayTexture||A.isData3DTexture,In=Z.isDataArrayTexture||Z.isData3DTexture;if(A.isDepthTexture){const un=Ft.get(A),rn=Ft.get(Z),Ln=Ft.get(un.__renderTarget),Js=Ft.get(rn.__renderTarget);Lt.bindFramebuffer(I.READ_FRAMEBUFFER,Ln.__webglFramebuffer),Lt.bindFramebuffer(I.DRAW_FRAMEBUFFER,Js.__webglFramebuffer);for(let Ii=0;Ii<wt;Ii++)Ze&&(I.framebufferTextureLayer(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,Ft.get(A).__webglTexture,Q,$t+Ii),I.framebufferTextureLayer(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,Ft.get(Z).__webglTexture,Tt,Je+Ii)),I.blitFramebuffer(Xt,ee,Pt,Bt,_e,Pe,Pt,Bt,I.DEPTH_BUFFER_BIT,I.NEAREST);Lt.bindFramebuffer(I.READ_FRAMEBUFFER,null),Lt.bindFramebuffer(I.DRAW_FRAMEBUFFER,null)}else if(Q!==0||A.isRenderTargetTexture||Ft.has(A)){const un=Ft.get(A),rn=Ft.get(Z);Lt.bindFramebuffer(I.READ_FRAMEBUFFER,ps),Lt.bindFramebuffer(I.DRAW_FRAMEBUFFER,Du);for(let Ln=0;Ln<wt;Ln++)Ze?I.framebufferTextureLayer(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,un.__webglTexture,Q,$t+Ln):I.framebufferTexture2D(I.READ_FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,un.__webglTexture,Q),In?I.framebufferTextureLayer(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,rn.__webglTexture,Tt,Je+Ln):I.framebufferTexture2D(I.DRAW_FRAMEBUFFER,I.COLOR_ATTACHMENT0,I.TEXTURE_2D,rn.__webglTexture,Tt),Q!==0?I.blitFramebuffer(Xt,ee,Pt,Bt,_e,Pe,Pt,Bt,I.COLOR_BUFFER_BIT,I.NEAREST):In?I.copyTexSubImage3D(Oe,Tt,_e,Pe,Je+Ln,Xt,ee,Pt,Bt):I.copyTexSubImage2D(Oe,Tt,_e,Pe,Xt,ee,Pt,Bt);Lt.bindFramebuffer(I.READ_FRAMEBUFFER,null),Lt.bindFramebuffer(I.DRAW_FRAMEBUFFER,null)}else In?A.isDataTexture||A.isData3DTexture?I.texSubImage3D(Oe,Tt,_e,Pe,Je,Pt,Bt,wt,Ce,te,Le.data):Z.isCompressedArrayTexture?I.compressedTexSubImage3D(Oe,Tt,_e,Pe,Je,Pt,Bt,wt,Ce,Le.data):I.texSubImage3D(Oe,Tt,_e,Pe,Je,Pt,Bt,wt,Ce,te,Le):A.isDataTexture?I.texSubImage2D(I.TEXTURE_2D,Tt,_e,Pe,Pt,Bt,Ce,te,Le.data):A.isCompressedTexture?I.compressedTexSubImage2D(I.TEXTURE_2D,Tt,_e,Pe,Le.width,Le.height,Ce,Le.data):I.texSubImage2D(I.TEXTURE_2D,Tt,_e,Pe,Pt,Bt,Ce,te,Le);I.pixelStorei(I.UNPACK_ROW_LENGTH,me),I.pixelStorei(I.UNPACK_IMAGE_HEIGHT,_n),I.pixelStorei(I.UNPACK_SKIP_PIXELS,Jn),I.pixelStorei(I.UNPACK_SKIP_ROWS,we),I.pixelStorei(I.UNPACK_SKIP_IMAGES,Aa),Tt===0&&Z.generateMipmaps&&I.generateMipmap(Oe),Lt.unbindTexture()},this.initRenderTarget=function(A){Ft.get(A).__webglFramebuffer===void 0&&oe.setupRenderTarget(A)},this.initTexture=function(A){A.isCubeTexture?oe.setTextureCube(A,0):A.isData3DTexture?oe.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?oe.setTexture2DArray(A,0):oe.setTexture2D(A,0),Lt.unbindTexture()},this.resetState=function(){F=0,P=0,k=null,Lt.reset(),zt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Qi}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const a=this.getContext();a.drawingBufferColorSpace=Ne._getDrawingBufferColorSpace(e),a.unpackColorSpace=Ne._getUnpackColorSpace()}}const J2=o=>o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),$2=o=>o.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,a,r)=>r?r.toUpperCase():a.toLowerCase()),lx=o=>{const e=$2(o);return e.charAt(0).toUpperCase()+e.slice(1)},Zx=(...o)=>o.filter((e,a,r)=>!!e&&e.trim()!==""&&r.indexOf(e)===a).join(" ").trim(),tR=o=>{for(const e in o)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};var eR={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const nR=an.forwardRef(({color:o="currentColor",size:e=24,strokeWidth:a=2,absoluteStrokeWidth:r,className:c="",children:f,iconNode:h,...d},_)=>an.createElement("svg",{ref:_,...eR,width:e,height:e,stroke:o,strokeWidth:r?Number(a)*24/Number(e):a,className:Zx("lucide",c),...!f&&!tR(d)&&{"aria-hidden":"true"},...d},[...h.map(([m,x])=>an.createElement(m,x)),...Array.isArray(f)?f:[f]]));const ve=(o,e)=>{const a=an.forwardRef(({className:r,...c},f)=>an.createElement(nR,{ref:f,iconNode:e,className:Zx(`lucide-${J2(lx(o))}`,`lucide-${o}`,r),...c}));return a.displayName=lx(o),a};const iR=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],aR=ve("activity",iR);const sR=[["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",key:"hh9hay"}],["path",{d:"m3.3 7 8.7 5 8.7-5",key:"g66t2b"}],["path",{d:"M12 22V12",key:"d0xqtd"}]],Eu=ve("box",sR);const rR=[["path",{d:"M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",key:"18u6gg"}],["circle",{cx:"12",cy:"13",r:"3",key:"1vg3eu"}]],cx=ve("camera",rR);const oR=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],jp=ve("chevron-right",oR);const lR=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],cR=ve("circle-check",lR);const uR=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}]],fR=ve("circle-dot",uR);const hR=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}],["path",{d:"M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662",key:"154egf"}]],Kx=ve("circle-user",hR);const dR=[["path",{d:"M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3Z",key:"1tn4o7"}],["path",{d:"m6.2 5.3 3.1 3.9",key:"iuk76l"}],["path",{d:"m12.4 3.4 3.1 4",key:"6hsd6n"}],["path",{d:"M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z",key:"ltgou9"}]],pR=ve("clapperboard",dR);const mR=[["path",{d:"M12 6v6h4",key:"135r8i"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],gR=ve("clock-3",mR);const _R=[["path",{d:"M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",key:"p7xjir"}]],vR=ve("cloud",_R);const xR=[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]],yR=ve("code-xml",xR);const SR=[["ellipse",{cx:"12",cy:"5",rx:"9",ry:"3",key:"msslwz"}],["path",{d:"M3 5V19A9 3 0 0 0 21 19V5",key:"1wlel7"}],["path",{d:"M3 12A9 3 0 0 0 21 12",key:"mv7ke4"}]],Qx=ve("database",SR);const MR=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ER=ve("eye",MR);const TR=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M7 3v18",key:"bbkbws"}],["path",{d:"M3 7.5h4",key:"zfgn84"}],["path",{d:"M3 12h18",key:"1i2n21"}],["path",{d:"M3 16.5h4",key:"1230mu"}],["path",{d:"M17 3v18",key:"in4fa5"}],["path",{d:"M17 7.5h4",key:"myr1c1"}],["path",{d:"M17 16.5h4",key:"go4c1d"}]],gl=ve("film",TR);const bR=[["path",{d:"M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",key:"1fr9dc"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M12 10v2",key:"hh53o1"}],["path",{d:"M16 10v6",key:"1d6xys"}]],AR=ve("folder-kanban",bR);const RR=[["path",{d:"M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",key:"1dudjm"}],["path",{d:"M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",key:"l2t8xc"}],["path",{d:"M16 17h4",key:"1dejxt"}],["path",{d:"M4 13h4",key:"1bwh8b"}]],CR=ve("footprints",RR);const wR=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],DR=ve("key-round",wR);const NR=[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]],Jx=ve("layers",NR);const UR=[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]],ux=ve("lightbulb",UR);const LR=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],OR=ve("log-out",LR);const zR=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],PR=ve("menu",zR);const IR=[["path",{d:"M5 3v16h16",key:"1mqmf9"}],["path",{d:"m5 19 6-6",key:"jh6hbb"}],["path",{d:"m2 6 3-3 3 3",key:"tkyvxa"}],["path",{d:"m18 16 3 3-3 3",key:"1d4glt"}]],fx=ve("move-3d",IR);const BR=[["path",{d:"M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",key:"e79jfc"}],["circle",{cx:"13.5",cy:"6.5",r:".5",fill:"currentColor",key:"1okk4w"}],["circle",{cx:"17.5",cy:"10.5",r:".5",fill:"currentColor",key:"f64h9f"}],["circle",{cx:"6.5",cy:"12.5",r:".5",fill:"currentColor",key:"qy21gx"}],["circle",{cx:"8.5",cy:"7.5",r:".5",fill:"currentColor",key:"fotxhn"}]],FR=ve("palette",BR);const HR=[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]],$x=ve("play",HR);const GR=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],Ru=ve("plus",GR);const VR=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],kR=ve("rotate-ccw",VR);const XR=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],jR=ve("save",XR);const qR=[["path",{d:"M3 7V5a2 2 0 0 1 2-2h2",key:"aa7l1z"}],["path",{d:"M17 3h2a2 2 0 0 1 2 2v2",key:"4qcy5o"}],["path",{d:"M21 17v2a2 2 0 0 1-2 2h-2",key:"6vwrx8"}],["path",{d:"M7 21H5a2 2 0 0 1-2-2v-2",key:"ioqczr"}],["path",{d:"M8 14s1.5 2 4 2 4-2 4-2",key:"1y1vjs"}],["path",{d:"M9 9h.01",key:"1q5me6"}],["path",{d:"M15 9h.01",key:"x1ddxp"}]],YR=ve("scan-face",qR);const WR=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ZR=ve("settings",WR);const KR=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],QR=ve("shield",KR);const JR=[["path",{d:"M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z",key:"1wgbhj"}]],$R=ve("shirt",JR);const tC=[["path",{d:"M10 5H3",key:"1qgfaw"}],["path",{d:"M12 19H3",key:"yhmn1j"}],["path",{d:"M14 3v4",key:"1sua03"}],["path",{d:"M16 17v4",key:"1q0r14"}],["path",{d:"M21 12h-9",key:"1o4lsq"}],["path",{d:"M21 19h-5",key:"1rlt1p"}],["path",{d:"M21 5h-7",key:"1oszz2"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M8 12H3",key:"a7s4jb"}]],eC=ve("sliders-horizontal",tC);const nC=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],ty=ve("sparkles",nC);const iC=[["path",{d:"m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z",key:"cpyugq"}],["path",{d:"M12 22v-3",key:"kmzjlo"}]],aC=ve("tree-pine",iC);const sC=[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]],ey=ve("users",sC);const rC=[["path",{d:"m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",key:"ul74o6"}],["path",{d:"m14 7 3 3",key:"1r5n42"}],["path",{d:"M5 6v4",key:"ilb8ba"}],["path",{d:"M19 14v4",key:"blhpug"}],["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M7 8H3",key:"zfb6yr"}],["path",{d:"M21 16h-4",key:"1cnmox"}],["path",{d:"M11 3H9",key:"1obp7u"}]],ny=ve("wand-sparkles",rC);const oC=[["path",{d:"M12.8 19.6A2 2 0 1 0 14 16H2",key:"148xed"}],["path",{d:"M17.5 8a2.5 2.5 0 1 1 2 4H2",key:"1u4tom"}],["path",{d:"M9.8 4.4A2 2 0 1 1 11 8H2",key:"75valh"}]],lC=ve("wind",oC);const cC=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],uC=ve("x",cC),fC=null,Ws=()=>crypto.randomUUID(),du={skin:"#b97852",hair:"#17191f",cloth:"#1c2638",accent:"#d78b4c"},Cu={id:Ws(),name:"Astra",role:"Bosh qahramon",height:1.72,skin:du.skin,hair:du.hair,cloth:du.cloth,accent:du.accent,face:"heroic",accessories:!0},qp=[{id:Ws(),title:"01 — Neon ko‘cha",duration:8,camera:"35mm · dolly-in · DOF",lighting:"Neon key · blue rim · fog",environment:"Cyber city · rain · wet asphalt",action:"Walk forward, look left, breathing, coat motion",characterIds:[]},{id:Ws(),title:"02 — Yuz close-up",duration:5,camera:"85mm · portrait · slow orbit",lighting:"Soft key · eye catchlight · rim",environment:"Night street · bokeh",action:"Look toward skyline, blink, subtle emotion",characterIds:[]},{id:Ws(),title:"03 — Establishing",duration:7,camera:"24mm · crane-up · wide",lighting:"Moon · practicals · volumetric",environment:"Futuristic district · rain particles",action:"Traffic movement, environmental motion",characterIds:[]}];qp[0].characterIds=[Cu.id];qp[1].characterIds=[Cu.id];const hC={id:Ws(),title:"Untitled Cinematic Film",style:"Photorealistic Cinematic",status:"draft",characters:[Cu],shots:qp,createdAt:new Date().toISOString()};function dC(){const[o,e]=an.useState("home"),[a,r]=an.useState(!1),[c,f]=an.useState(null),[h,d]=an.useState(hC),[_,m]=an.useState(""),[x,p]=an.useState(!1),[y,M]=an.useState("idle"),[b,D]=an.useState("login"),[S,v]=an.useState(""),[L,z]=an.useState(""),[N,H]=an.useState("");an.useEffect(()=>{const C=localStorage.getItem("kino_ai_studio_project");if(C)try{d(JSON.parse(C))}catch{}const w=localStorage.getItem("kino_ai_script");w&&m(w)},[]);const F=async()=>{localStorage.setItem("kino_ai_studio_project",JSON.stringify(h)),localStorage.setItem("kino_ai_script",_),p(!0),setTimeout(()=>p(!1),1400)},P=async()=>{{H("Supabase ulanmagan. .env orqali VITE_SUPABASE_URL va VITE_SUPABASE_ANON_KEY kiriting.");return}},k=[["home","Bosh sahifa",pR],["create","Kino yaratish",gl],["script","AI ssenariy",ty],["characters","Personajlar",ey],["projects","Loyihalar",AR],["studio","Cinema Engine",Eu],["profile","Profil",Kx],["settings","Sozlamalar",ZR]];return R.jsxs("div",{className:"app",children:[R.jsxs("aside",{className:"side "+(a?"open":""),children:[R.jsxs("div",{className:"brand",children:[R.jsx("div",{className:"logo",children:R.jsx(gl,{})}),R.jsxs("b",{children:["KINO AI",R.jsx("small",{children:"STUDIO · PRIVATE ENGINE"})]}),R.jsx("button",{className:"icon mobileX",onClick:()=>r(!1),children:R.jsx(uC,{})})]}),R.jsx("div",{className:"label",children:"WORKSPACE"}),k.map(([C,w,G])=>R.jsxs("button",{className:"nav "+(o===C?"sel":""),onClick:()=>{e(C),r(!1)},children:[R.jsx(G,{size:18}),R.jsx("span",{children:w}),o===C&&R.jsx(jp,{size:14})]},C)),R.jsxs("div",{className:"bottom",children:[R.jsxs("div",{className:"online",children:[R.jsx("i",{}),"ENGINE ONLINE",R.jsx("small",{children:"Private 3D asset core"})]}),c&&R.jsxs("button",{className:"nav",onClick:()=>fC?.auth.signOut(),children:[R.jsx(OR,{size:18}),R.jsx("span",{children:"Chiqish"})]})]})]}),R.jsxs("main",{children:[R.jsxs("header",{children:[R.jsx("button",{className:"icon menu",onClick:()=>r(!0),children:R.jsx(PR,{})}),R.jsxs("span",{children:["KINO AI STUDIO / ",k.find(C=>C[0]===o)?.[1]]}),R.jsxs("div",{children:[c?R.jsx("em",{children:"● Cloud online"}):R.jsx("button",{className:"ghost",onClick:()=>e("profile"),children:"Kirish"}),R.jsxs("button",{className:"primary sm",onClick:()=>e("create"),children:[R.jsx(Ru,{size:15})," Yangi kino"]})]})]}),o==="home"&&R.jsx(pC,{go:e,project:h})," ",o==="create"&&R.jsx(mC,{project:h,setProject:d,script:_,setScript:m,save:F,saved:x,render:y,setRender:M})," ",o==="script"&&R.jsx(gC,{script:_,setScript:m,project:h,setProject:d})," ",o==="characters"&&R.jsx(_C,{project:h,setProject:d})," ",o==="projects"&&R.jsx(yC,{project:h,go:e})," ",o==="studio"&&R.jsx(SC,{project:h,setProject:d})," ",o==="profile"&&R.jsx(EC,{session:c,mode:b,setMode:D,email:S,setEmail:v,pass:L,setPass:z,msg:N,auth:P})," ",o==="settings"&&R.jsx(TC,{})]})]})}function pC({go:o,project:e}){return R.jsxs("div",{className:"page",children:[R.jsxs("section",{className:"hero",children:[R.jsxs("div",{className:"heroText",children:[R.jsx("div",{className:"eyebrow",children:"● PRIVATE CINEMA ENGINE · V4"}),R.jsxs("h1",{children:["G‘oyangizni",R.jsx("br",{}),R.jsx("span",{children:"kinoga aylantiring."})]}),R.jsx("p",{children:"Script → Scene Graph → Character Identity → Motion → Camera → Lighting → Environment → Timeline → Render."}),R.jsxs("button",{className:"primary",onClick:()=>o("create"),children:[R.jsx($x,{size:17})," Kino yaratishni boshlash"]}),R.jsxs("button",{className:"ghost",onClick:()=>o("studio"),children:[R.jsx(Eu,{size:17})," 3D Engine"]})]}),R.jsxs("div",{className:"reel",children:[R.jsx(gl,{size:64}),R.jsxs("b",{children:["PRIVATE",R.jsx("br",{}),"3D CORE"]})]})]}),R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"WORKSPACE"}),R.jsx("h2",{children:"Studio paneli"})]}),R.jsxs("small",{children:[e.shots.length," shots · ",e.characters.length," characters"]})]}),R.jsx("div",{className:"cards",children:[[gl,"Kino yaratish","Ssenariyni scene va shot pipeline ga aylantirish","create"],[ty,"AI ssenariy","Structured screenplay va continuity","script"],[ey,"Personajlar","Identity lock, kiyim va asset generator","characters"],[Eu,"Cinema Engine","Ichki 3D scene graph va cinematic controls","studio"]].map(([a,r,c,f])=>R.jsxs("button",{className:"card",onClick:()=>o(f),children:[R.jsx(a,{}),R.jsx("b",{children:r}),R.jsx("p",{children:c}),R.jsx(jp,{})]},r))}),R.jsxs("div",{className:"stats",children:[R.jsxs("div",{children:[R.jsx("b",{children:e.shots.length}),R.jsx("small",{children:"SHOTS"})]}),R.jsxs("div",{children:[R.jsxs("b",{children:[e.shots.reduce((a,r)=>a+r.duration,0),"s"]}),R.jsx("small",{children:"TIMELINE"})]}),R.jsxs("div",{children:[R.jsx("b",{children:e.characters.length}),R.jsx("small",{children:"CHARACTERS"})]}),R.jsxs("div",{children:[R.jsx("b",{children:"PRIVATE"}),R.jsx("small",{children:"3D ASSET CORE"})]})]})]})}function mC({project:o,setProject:e,script:a,setScript:r,save:c,saved:f,render:h,setRender:d}){return R.jsxs("div",{className:"page",children:[R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"FILM BUILDER"}),R.jsx("h2",{children:"Kino yaratish"})]}),R.jsxs("button",{className:"ghost",onClick:c,children:[R.jsx(jR,{size:15}),f?"Saqlandi":"Saqlash"]})]}),R.jsxs("div",{className:"grid",children:[R.jsxs("section",{className:"panel",children:[R.jsx("label",{children:"LOYIHA NOMI"}),R.jsx("input",{value:o.title,onChange:_=>e({...o,title:_.target.value})}),R.jsx("label",{children:"SSENARIY"}),R.jsx("textarea",{value:a,onChange:_=>r(_.target.value),placeholder:"Film voqeasini yozing..."}),R.jsxs("div",{className:"row",children:[R.jsxs("button",{className:"ghost",onClick:()=>{e({...o,status:"analyzed"}),r(a||"Yomg‘irli tungi shaharda qahramon kelajakdagi sirni izlaydi.")},children:[R.jsx(ny,{})," Auto Analyze"]}),R.jsxs("button",{className:"ghost",onClick:c,children:[R.jsx(Qx,{})," Cloud Draft"]})]}),R.jsx("label",{children:"VIZUAL USLUB"}),R.jsxs("select",{value:o.style,onChange:_=>e({...o,style:_.target.value}),children:[R.jsx("option",{children:"Photorealistic Cinematic"}),R.jsx("option",{children:"Dark Cinematic"}),R.jsx("option",{children:"Cyberpunk Cinematic"}),R.jsx("option",{children:"Epic Fantasy"}),R.jsx("option",{children:"Stylized 3D Film"})]}),R.jsxs("div",{className:"pipeline",children:[R.jsx("span",{children:"1 SCRIPT"}),R.jsx("i",{children:"→"}),R.jsx("span",{children:"2 SCENE"}),R.jsx("i",{children:"→"}),R.jsx("span",{children:"3 SHOT"}),R.jsx("i",{children:"→"}),R.jsx("span",{children:"4 3D"}),R.jsx("i",{children:"→"}),R.jsx("span",{children:"5 RENDER"})]})]}),R.jsxs("section",{className:"panel",children:[R.jsxs("div",{className:"pt",children:["SHOT TIMELINE ",R.jsx("button",{className:"icon",onClick:()=>e({...o,shots:[...o.shots,{id:Ws(),title:`${String(o.shots.length+1).padStart(2,"0")} — New Shot`,duration:5,camera:"35mm · tracking",lighting:"Key + rim",environment:"",action:"",characterIds:o.characters.slice(0,1).map(_=>_.id)}]}),children:R.jsx(Ru,{size:15})})]}),o.shots.map((_,m)=>R.jsxs("div",{className:"shot",children:[R.jsx("span",{children:String(m+1).padStart(2,"0")}),R.jsxs("div",{children:[R.jsx("b",{children:_.title}),R.jsxs("small",{children:[_.camera," · ",_.duration,"s"]})]}),R.jsx("i",{children:"SCENE READY"})]},_.id)),R.jsxs("div",{className:"render",children:[R.jsxs("div",{children:[R.jsx("b",{children:"REAL RENDER GATE"}),R.jsx("small",{children:h==="queued"?"Queue tekshirilmoqda…":h==="unavailable"?"RENDERER_UNAVAILABLE — fake MP4 yaratilmaydi.":"Real renderer/model mavjudligi tekshiriladi."})]}),R.jsxs("button",{className:"primary",onClick:()=>{d("queued"),setTimeout(()=>d("unavailable"),900)},children:[R.jsx($x,{size:15})," Render"]})]})]})]})]})}function gC({script:o,setScript:e,project:a,setProject:r}){return R.jsxs("div",{className:"page",children:[R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"SCRIPT ENGINE"}),R.jsx("h2",{children:"AI ssenariy"})]}),R.jsxs("button",{className:"primary sm",onClick:()=>r({...a,status:"analyzed"}),children:[R.jsx(ny,{size:15})," Tahlil qilish"]})]}),R.jsxs("div",{className:"grid",children:[R.jsxs("section",{className:"panel",children:[R.jsx("label",{children:"SCREENPLAY"}),R.jsx("textarea",{className:"large",value:o,onChange:c=>e(c.target.value),placeholder:"Characters, locations, scenes, actions, dialogue, camera, weather va continuity..."}),R.jsx("div",{className:"notice",children:"Bu UI tahlil strukturasi. Haqiqiy LLM inference keyin server-side adapter orqali ulanadi; fake AI natija ko‘rsatilmaydi."})]}),R.jsxs("section",{className:"panel",children:[R.jsx("div",{className:"pt",children:"STRUCTURED ANALYZER"}),["Characters","Locations / Environments","Scenes / Shots","Camera opportunities","Actions / Dialogue","Continuity rules","Audio / Timing"].map(c=>R.jsxs("div",{className:"out",children:[R.jsx(Jx,{size:17}),R.jsxs("div",{children:[R.jsx("b",{children:c}),R.jsx("small",{children:a.status==="analyzed"?"READY FOR GRAPH":"Waiting for analysis"})]}),R.jsx(cR,{})]},c))]})]})]})}function _C({project:o,setProject:e}){const[a,r]=an.useState(0),c=o.characters[a],f=()=>{const d={id:Ws(),name:`Personaj ${o.characters.length+1}`,role:"Supporting",height:1.7,skin:"#a96f4d",hair:"#202229",cloth:"#26324a",accent:"#d78b4c",face:"natural",accessories:!0};e({...o,characters:[...o.characters,d]}),r(o.characters.length)},h=(d,_)=>e({...o,characters:o.characters.map((m,x)=>x===a?{...m,[d]:_}:m)});return R.jsxs("div",{className:"page",children:[R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"PRIVATE CHARACTER ASSET SYSTEM"}),R.jsx("h2",{children:"Personajlar"})]}),R.jsxs("button",{className:"primary sm",onClick:f,children:[R.jsx(Ru,{size:15})," Personaj yaratish"]})]}),R.jsxs("div",{className:"charLayout",children:[R.jsx("div",{className:"panel charList",children:o.characters.map((d,_)=>R.jsxs("button",{className:"charRow "+(_===a?"active":""),onClick:()=>r(_),children:[R.jsx("div",{className:"miniHead",style:{background:d.skin},children:R.jsx(ER,{size:14})}),R.jsxs("div",{children:[R.jsx("b",{children:d.name}),R.jsx("small",{children:d.role})]}),R.jsx(jp,{size:14})]},d.id))}),c&&R.jsx(vC,{c,update:h})]})]})}function vC({c:o,update:e}){return R.jsxs("div",{className:"panel characterEditor",children:[R.jsxs("div",{className:"editorTop",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"IDENTITY LOCK"}),R.jsx("h3",{children:o.name})]}),R.jsx("span",{className:"lock",children:"● CONTINUITY LOCKED"})]}),R.jsxs("div",{className:"characterStage",children:[R.jsx(xC,{c:o}),R.jsxs("div",{className:"assetInfo",children:[R.jsxs("div",{className:"assetTag",children:[R.jsx(YR,{})," Face identity"]}),R.jsxs("div",{className:"assetTag",children:[R.jsx($R,{})," Clothing asset"]}),R.jsxs("div",{className:"assetTag",children:[R.jsx(fR,{})," Material profile"]}),R.jsxs("div",{className:"assetTag",children:[R.jsx(CR,{})," Rig / motion ready"]})]})]}),R.jsxs("div",{className:"formGrid",children:[R.jsxs("label",{children:["NAME",R.jsx("input",{value:o.name,onChange:a=>e("name",a.target.value)})]}),R.jsxs("label",{children:["ROLE",R.jsx("input",{value:o.role,onChange:a=>e("role",a.target.value)})]}),R.jsxs("label",{children:["HEIGHT",R.jsx("input",{type:"number",step:"0.01",value:o.height,onChange:a=>e("height",Number(a.target.value))})]}),R.jsxs("label",{children:["FACE",R.jsxs("select",{value:o.face,onChange:a=>e("face",a.target.value),children:[R.jsx("option",{children:"heroic"}),R.jsx("option",{children:"natural"}),R.jsx("option",{children:"sharp"}),R.jsx("option",{children:"soft"})]})]}),R.jsxs("label",{children:["SKIN",R.jsx("input",{type:"color",value:o.skin,onChange:a=>e("skin",a.target.value)})]}),R.jsxs("label",{children:["HAIR",R.jsx("input",{type:"color",value:o.hair,onChange:a=>e("hair",a.target.value)})]}),R.jsxs("label",{children:["CLOTHING",R.jsx("input",{type:"color",value:o.cloth,onChange:a=>e("cloth",a.target.value)})]}),R.jsxs("label",{children:["ACCENT",R.jsx("input",{type:"color",value:o.accent,onChange:a=>e("accent",a.target.value)})]})]}),R.jsxs("div",{className:"continuity",children:[R.jsx("b",{children:"CONTINUITY PROFILE"}),R.jsx("span",{children:"face · hair · eyes · body · clothing · accessories · emotional state"})]})]})}function xC({c:o}){const e=an.useRef(null);return an.useEffect(()=>{if(!e.current)return;const a=e.current;a.innerHTML="";const r=new zx;r.background=new Te("#080b11");const c=new Zn(35,1,.1,100);c.position.set(2.8,1.7,5),c.lookAt(0,1.1,0);const f=new Wx({antialias:!0});f.setPixelRatio(Math.min(devicePixelRatio,2)),f.setSize(360,300),f.shadowMap.enabled=!0,f.toneMapping=Op,a.appendChild(f.domElement);const h=new Fx(10467327,1708048,2);r.add(h);const d=new Vx(16765088,3);d.position.set(2,4,4),d.castShadow=!0,r.add(d);const _=new Dp(new Te(o.accent),8,10);_.position.set(-2,2,1),r.add(_);const m=new Jr;m.name="KINO_PRIVATE_CHARACTER";const x=new tn(new Ys(.42,.72,8,16),new ci({color:o.cloth,roughness:.52,metalness:.08}));x.position.y=1.05,x.scale.y=1.12,x.castShadow=!0,m.add(x);const p=new tn(new ls(.34,24,16),new ci({color:o.skin,roughness:.7}));p.position.y=1.82,p.scale.set(1,.98,.92),p.castShadow=!0,m.add(p);const y=new tn(new ls(.36,20,12,0,Math.PI*2,0,Math.PI*.55),new ci({color:o.hair,roughness:.85}));y.position.y=1.91,m.add(y);for(const v of[-.13,.13]){const L=new tn(new ls(.035,10,10),new ci({color:"#101217",roughness:.2}));L.position.set(v,1.84,.31),m.add(L)}for(const v of[-.24,.24]){const L=new tn(new Ys(.09,.65,6,10),new ci({color:o.cloth,roughness:.5}));L.position.set(v,.98,0),L.rotation.z=v<0?-.12:.12,m.add(L)}for(const v of[-.13,.13]){const L=new tn(new Ys(.12,.72,6,10),new ci({color:o.cloth,roughness:.55}));L.position.set(v,.35,0),m.add(L)}r.add(m);const M=new tn(new co(20,20),new ci({color:"#0d1118",roughness:.9,metalness:.05}));M.rotation.x=-Math.PI/2,M.receiveShadow=!0,r.add(M);let b=0,D=0;const S=()=>{b+=.008,m.rotation.y=Math.sin(b*.7)*.12,f.render(r,c),D=requestAnimationFrame(S)};return S(),()=>{cancelAnimationFrame(D),f.dispose(),a.innerHTML=""}},[o]),R.jsx("div",{className:"charPreview",ref:e})}function yC({project:o,go:e}){return R.jsxs("div",{className:"page",children:[R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"PROJECT LIBRARY"}),R.jsx("h2",{children:"Loyihalar"})]}),R.jsxs("button",{className:"ghost",onClick:()=>e("create"),children:[R.jsx(Ru,{})," Yangi"]})]}),R.jsxs("div",{className:"panel project",children:[R.jsx("div",{className:"thumb",children:R.jsx(gl,{})}),R.jsxs("div",{children:[R.jsx("b",{children:o.title}),R.jsxs("p",{children:[o.shots.length," shots · ",o.characters.length," characters · ",o.style]}),R.jsxs("span",{className:"status",children:["● ",o.status.toUpperCase()]})]}),R.jsx("button",{className:"primary sm",onClick:()=>e("create"),children:"Ochish"})]})]})}function SC({project:o,setProject:e}){const[a,r]=an.useState(0),c=o.shots[a]||o.shots[0];return R.jsxs("div",{className:"page",children:[R.jsxs("div",{className:"head",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"PRIVATE 3D CINEMA ENGINE"}),R.jsx("h2",{children:"Scene Graph"})]}),R.jsx("small",{className:"green",children:"● Procedural engine online"})]}),R.jsxs("div",{className:"engine",children:[R.jsx(MC,{shot:c,project:o}),R.jsxs("div",{className:"panel inspect",children:[R.jsx("div",{className:"pt",children:"SHOT INSPECTOR"}),R.jsx("label",{children:"CAMERA"}),R.jsxs("select",{value:c.camera,onChange:f=>e({...o,shots:o.shots.map((h,d)=>d===a?{...h,camera:f.target.value}:h)}),children:[R.jsx("option",{children:"24mm · crane-up · wide"}),R.jsx("option",{children:"35mm · dolly-in · DOF"}),R.jsx("option",{children:"50mm · tracking"}),R.jsx("option",{children:"85mm · portrait · slow orbit"})]}),R.jsx("label",{children:"LENS / FOCUS"}),R.jsx("input",{value:c.camera,onChange:f=>e({...o,shots:o.shots.map((h,d)=>d===a?{...h,camera:f.target.value}:h)})}),R.jsx("label",{children:"LIGHTING"}),R.jsx("input",{value:c.lighting,onChange:f=>e({...o,shots:o.shots.map((h,d)=>d===a?{...h,lighting:f.target.value}:h)})}),R.jsx("label",{children:"ENVIRONMENT"}),R.jsx("input",{value:c.environment,onChange:f=>e({...o,shots:o.shots.map((h,d)=>d===a?{...h,environment:f.target.value}:h)})}),R.jsx("label",{children:"ACTION / MOTION"}),R.jsx("textarea",{value:c.action,onChange:f=>e({...o,shots:o.shots.map((h,d)=>d===a?{...h,action:f.target.value}:h)})}),R.jsxs("div",{className:"inspectorGrid",children:[R.jsxs("div",{children:[R.jsx(cx,{}),R.jsx("small",{children:"CAMERA"}),R.jsx("b",{children:"ACTIVE"})]}),R.jsxs("div",{children:[R.jsx(ux,{}),R.jsx("small",{children:"LIGHT"}),R.jsx("b",{children:"ACTIVE"})]}),R.jsxs("div",{children:[R.jsx(fx,{}),R.jsx("small",{children:"MOTION"}),R.jsx("b",{children:"RIGGED"})]}),R.jsxs("div",{children:[R.jsx(aC,{}),R.jsx("small",{children:"WORLD"}),R.jsx("b",{children:"PROCEDURAL"})]})]})]})]}),R.jsx("div",{className:"tabs",children:o.shots.map((f,h)=>R.jsxs("button",{className:h===a?"active":"",onClick:()=>r(h),children:[h+1,". ",f.title,R.jsxs("small",{children:[f.duration,"s"]})]},f.id))}),R.jsx("div",{className:"modules",children:[[Eu,"Character Asset","Procedural mesh · named rig · materials"],[fx,"Motion Solver","Idle · walk · look · secondary motion"],[Jx,"Scene Graph","Character · prop · environment nodes"],[cx,"Camera System","Lens · tracking · crane · orbit · DOF"],[ux,"Lighting","Key · fill · rim · practical · fog"],[lC,"Physics Layer","Rain · cloth/hair adapter · particles"],[FR,"Material System","PBR roughness · metalness · normal"],[aR,"Render Pipeline","Segments · progress · retry · audit"]].map(([f,h,d])=>R.jsxs("div",{className:"panel mod",children:[R.jsx(f,{}),R.jsx("b",{children:h}),R.jsx("small",{children:d})]},h))})]})}function MC({shot:o,project:e}){const a=an.useRef(null);return an.useEffect(()=>{if(!a.current)return;const r=a.current;r.innerHTML="";const c=new zx;c.background=new Te("#060a10");const f=new Zn(38,1,.1,100);f.position.set(4,3,7);const h=new Wx({antialias:!0});h.setPixelRatio(Math.min(devicePixelRatio,1.7)),h.setSize(r.clientWidth||700,450),h.shadowMap.enabled=!0,h.toneMapping=Op,h.toneMappingExposure=1.15,r.appendChild(h.domElement);const d=new Fx(9283273,1052950,1.6);c.add(d);const _=new Vx(16764842,4);_.position.set(3,6,4),_.castShadow=!0,c.add(_);const m=new Dp(3633151,12,18);m.position.set(-4,2,-1),c.add(m);const x=new Dp(16723611,14,15);x.position.set(2,3,-4),c.add(x);const p=new tn(new co(40,40),new ci({color:"#0a1017",roughness:.72,metalness:.18}));p.rotation.x=-Math.PI/2,p.receiveShadow=!0,c.add(p);for(let k=0;k<10;k++){const C=1+Math.random()*4,w=.7+Math.random()*1.4,G=new tn(new Qs(w,C,w),new ci({color:k%2?"#101827":"#171321",roughness:.8,metalness:.15}));G.position.set((k-5)*1.7,C/2,-2.5-k%3*2),G.castShadow=!0,c.add(G);for(let it=0;it<3;it++){const ct=new tn(new Qs(.08,.12,.02),new Mu({color:it%2?"#4f83ff":"#e5a04c"}));ct.position.set(G.position.x-.25+it*.25,C*.6,-2.5-k%3*2-.37),c.add(ct)}}const y=new Jr;y.position.y=0;const M=e.characters[0]||Cu,b=new tn(new Ys(.4,.75,8,16),new ci({color:M.cloth,roughness:.48,metalness:.08}));b.position.y=1.1,b.castShadow=!0,y.add(b);const D=new tn(new ls(.33,20,14),new ci({color:M.skin,roughness:.7}));D.position.y=1.88,D.castShadow=!0,y.add(D);const S=new tn(new ls(.35,18,10,0,Math.PI*2,0,Math.PI*.55),new ci({color:M.hair,roughness:.9}));S.position.y=1.97,y.add(S);for(const k of[-.13,.13]){const C=new tn(new ls(.035,8,8),new Mu({color:"#e8f2ff"}));C.position.set(k,1.9,.31),y.add(C)}for(const k of[-.23,.23]){const C=new tn(new Ys(.085,.65,6,9),new ci({color:M.cloth,roughness:.5}));C.position.set(k,1.05,0),C.rotation.z=k<0?-.08:.08,y.add(C)}c.add(y);const v=new Pi,L=450,z=new Float32Array(L*3);for(let k=0;k<L;k++)z[k*3]=(Math.random()-.5)*14,z[k*3+1]=Math.random()*8,z[k*3+2]=(Math.random()-.5)*12;v.setAttribute("position",new zi(z,3));const N=new u1(v,new Px({color:"#8bbcff",size:.025,transparent:!0,opacity:.55}));c.add(N),f.lookAt(0,1.3,0);let H=0,F=0;const P=()=>{H+=.012,y.position.x=Math.sin(H*.6)*.28,y.rotation.y=Math.sin(H*.4)*.18,N.position.y=-(H*2%2),o.camera.includes("85mm")?f.position.set(2.2,2.1,5):o.camera.includes("24mm")?f.position.set(5,4,8):f.position.set(3.7,2.7,6.6),f.lookAt(0,1.35,0),h.render(c,f),F=requestAnimationFrame(P)};return P(),()=>{cancelAnimationFrame(F),h.dispose(),r.innerHTML=""}},[o,e]),R.jsxs("div",{className:"viewport",children:[R.jsxs("div",{className:"hud",children:[R.jsx("b",{children:"SCENE GRAPH / LIVE PREVIEW"}),R.jsxs("small",{children:[" ",o.title," · ",o.camera]})]}),R.jsxs("div",{className:"engineBadge",children:[R.jsx("span",{children:"●"})," PRIVATE 3D CORE"]}),R.jsx("div",{className:"sceneCanvas",ref:a})]})}function EC({session:o,mode:e,setMode:a,email:r,setEmail:c,pass:f,setPass:h,msg:d,auth:_}){return o?R.jsxs("div",{className:"page",children:[R.jsx("div",{className:"head",children:R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"ACCOUNT"}),R.jsx("h2",{children:"Profil"})]})}),R.jsxs("div",{className:"panel profile",children:[R.jsx(Kx,{}),R.jsx("h3",{children:o.user.email}),R.jsx("p",{children:"Cloud session faol."})]})]}):R.jsxs("div",{className:"auth",children:[R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"KINO AI STUDIO"}),R.jsx("h2",{children:e==="login"?"Studio’ga kirish":"Yangi akkaunt"}),R.jsx("p",{children:"Supabase Auth orqali xavfsiz session. Local draft ham ishlaydi."})]}),R.jsxs("div",{className:"panel authbox",children:[R.jsx("label",{children:"EMAIL"}),R.jsx("input",{value:r,onChange:m=>c(m.target.value)}),R.jsx("label",{children:"PAROL"}),R.jsx("input",{type:"password",value:f,onChange:m=>h(m.target.value)}),R.jsx("button",{className:"primary full",onClick:_,children:e==="login"?"Kirish":"Ro‘yxatdan o‘tish"}),d&&R.jsx("div",{className:"notice",children:d}),R.jsx("button",{className:"text",onClick:()=>a(e==="login"?"register":"login"),children:e==="login"?"Akkaunt yo‘qmi?":"Kirish"})]})]})}function TC(){return R.jsxs("div",{className:"page",children:[R.jsx("div",{className:"head",children:R.jsxs("div",{children:[R.jsx("div",{className:"eyebrow",children:"SYSTEM ARCHITECTURE"}),R.jsx("h2",{children:"Sozlamalar"})]})}),R.jsx("div",{className:"settings",children:[[vR,"Cloud Storage","Katta media telefon xotirasida emas; object storage adapter orqali."],[QR,"Security","Auth · RLS · RBAC · API keys · audit logs."],[DR,"Universal API","Projects · scripts · characters · generate · jobs · webhooks."],[yR,"Private Model Layer","Video/3D model providerga majburiy bog‘lanmagan adapter arxitekturasi."],[Qx,"Data Model","Project → scene → shot → asset → motion → render job."],[gR,"Render Gate","Renderer bo‘lmasa RENDERER_UNAVAILABLE; fake MP4 yo‘q."],[eC,"Asset Registry","Versioned character, material, rig, motion va environment metadata."],[kR,"Recovery","Checkpoint · retry · audit · failure state."]].map(([o,e,a])=>R.jsxs("div",{className:"panel set",children:[R.jsx(o,{}),R.jsxs("div",{children:[R.jsx("b",{children:e}),R.jsx("p",{children:a})]})]},e))}),R.jsxs("div",{className:"panel roadmap",children:[R.jsx("h3",{children:"Keyingi ichki bosqichlar"}),R.jsxs("div",{className:"road",children:[R.jsx("span",{children:"01"})," Private Character Generator → ",R.jsx("span",{children:"02"})," Motion Solver → ",R.jsx("span",{children:"03"})," Scene/Prop Generator → ",R.jsx("span",{children:"04"})," Neural Model Training → ",R.jsx("span",{children:"05"})," Real Render Worker"]})]})]})}YM.createRoot(document.getElementById("root")).render(R.jsx(dC,{}));
